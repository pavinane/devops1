import React, { Suspense, lazy } from "react";
import { BrowserRouter } from "react-router-dom";

import MainRouter from "./router/MainRouter";
import ScrollToTop from "./components/commonComponents/ScrollToTop";

function Routes(props) {
    return (
        <BrowserRouter>
            <ScrollToTop />
            <Suspense fallback={null}>
                <MainRouter />
            </Suspense>
        </BrowserRouter>
    );
}

export default Routes;