import axios from "axios";

export const queryHandler = async ({ queryKey }) => {
    const [endPoint, data] = queryKey;
    try {
        const response = await axios.get(`/${endPoint}`, {
            ...("params" in data && {
                params: {
                    ...data.params,
                },
            }),
            withCredentials: true,
            headers: {
                "Content-Type": "multipart/form-data",
            },
        });

        if (endPoint === "is-valid") {
            return response.data;
        }
        return response.data;
    } catch (error) {
        throw error; // Re-throw the error to be caught by the caller
    }
};

export const mutationHandler = async ({ endPoint, payload = null, method = "post", token = null, contentType,responseType = "json" }) => {
    try {
        const requestOptions = {
            // withCredentials: true,
            headers: {
                "Content-Type": "multipart/form-data",
            },
            responseType,
            method,
            ...(token && {
                headers: {
                    Authorization: `Bearer ${token}`,
                    "Content-Type": contentType ? contentType : "multipart/form-data",
                },
            }),
        };

        if (method.toLowerCase() === "post" && payload) {
            requestOptions.data = payload;
        } else if (method.toLowerCase() !== "post" && payload) {
            requestOptions.params = payload;
        }

        const response = await axios(`/${endPoint}`, requestOptions);

        if (!(response.status >= 200 && response.status < 300)) {
            throw new Error(
                `Request failed with status code ${response.status}`
            );
        }
        return response.data;
    } catch (error) {
        if (
            error?.response?.data?.message === "Your account is not activated" ||
            error?.response?.data?.message === "Unauthorized"
        ) {
            const authData = { accstatus: "deactivated" };
            localStorage.setItem("authUserD", JSON.stringify(authData));
            window.dispatchEvent(
                new StorageEvent("storage", {
                    key: "authUserD",
                    newValue: JSON.stringify(authData),
                })
            );
        }
        throw error;
    }
};

export const validateToken = async (token) => {
    try {
        const response = await axios.get(`/is-valid/`, {
            params: {
                token,
            },
        });
        if (response.status !== 200) {
            throw new Error(
                `Request failed with status code ${response.status}`
            );
        }
        return response.data.data;
    } catch (error) {
        throw error; // Re-throw the error to be caught by the caller
    }
};

export const fileUpload = async ({ formData, endPoint, token }) => {
    try {
        const response = await axios.post(`/${endPoint}`, formData, {
            "Content-Type": "multipart/form-data",

            headers: {
                Authorization: `Bearer ${token}`,
            },
        });
        return response;
    } catch (error) {
        throw error; // Re-throw the error to be caught by the caller
    }
};
