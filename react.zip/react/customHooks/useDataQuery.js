import { useSelector } from "react-redux";
import { useQuery, useMutation } from "@tanstack/react-query";
import { mutationHandler, queryHandler, fileUpload } from "./queryFunctions";

export const useReusableMutation = (options) => {
    const mutation = useMutation({
        mutationFn: options?.formData ? fileUpload : mutationHandler,
        refetchOnWindowFocus: false,
        retryOnMount: false,
        retry: false,
        ...options,
    });
    return mutation;
};

export const useResuableQuery = ({ endpoint, params = null, withToken = false, dependency = null, options = null, }) => {
    const token = withToken ? useSelector((state) => state.user).token : null;
    const data = {
        ...(params && { params }),
        ...(token && { token }),
    };
    const queryResponse = useQuery({
        queryKey: [endpoint, data, dependency],
        queryFn: queryHandler,
        retry: false,
        retryOnMount: false,
        refetchOnWindowFocus: false,
        ...(options && options),
    });
    const { isError, error } = queryResponse;
    if (isError) {

    }
    return queryResponse;
};
