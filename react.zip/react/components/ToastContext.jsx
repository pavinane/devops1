import { createContext, useContext, useState, useCallback, useRef, useMemo } from "react";
import "../toast.css";

const ToastContext = createContext();

export const ToastProvider = ({ children }) => {
  const [toast, setToast] = useState({ message: "", type: "success", visible: false, closing: false });
  const timerRef = useRef(null);
  const exitTimerRef = useRef(null);

  const showToast = useCallback((message, type = "success") => {
    // Clear existing timers if any
    if (timerRef.current) clearTimeout(timerRef.current);
    if (exitTimerRef.current) clearTimeout(exitTimerRef.current);

    setToast({ message, type, visible: true, closing: false });

    // Wait 3.4s total (approx 0.4s arrival + 3s visible) before starting exit animation
    timerRef.current = setTimeout(() => {
      setToast((prev) => ({ ...prev, closing: true }));

      // Wait 0.5s for the exit animation to finish before removing from DOM
      exitTimerRef.current = setTimeout(() => {
        setToast((prev) => ({ ...prev, visible: false, closing: false }));
      }, 500);
    }, 3400);
  }, []);

  const contextValue = useMemo(() => ({
    showToast,
    success: (message) => showToast(message, "success"),
    error: (message) => showToast(message, "error"),
    warning: (message) => showToast(message, "warning"),
    info: (message) => showToast(message, "info"),
  }), [showToast]);

  return (
    <ToastContext.Provider value={contextValue}>
      {children}
      <Toast
        message={toast.message}
        type={toast.type}
        visible={toast.visible}
        closing={toast.closing}
      />
    </ToastContext.Provider>
  );
};

export const useToast = () => {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error("useToast must be used within a ToastProvider");
  }
  return context;
};

// Toast UI Component
const Toast = ({ message, type, visible, closing }) => {
  if (!visible) return null;

  return (
    <div
      className={`toast ${type} ${closing ? "closing" : ""} shadow-box`}
      role="alert"
      aria-live="polite"
    >
      <div className="toast-icon">
        {type === "success" && (
          <svg width="35px" height="35px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="none">
            <circle cx="12" cy="12" r="12" fill="#0CC600" />
            <path d="M7 12.5l3 3 7-7" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        )}
        {type === "error" && (
          <svg width="35px" height="35px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="none">
            <circle cx="12" cy="12" r="12" fill="#ff4b4b" />
            <path d="M8 8l8 8M16 8l-8 8" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
          </svg>
        )}
        {type === "warning" && (
          <svg width="35px" height="35px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="none">
            <path d="M12 2l10 18H2L12 2z" fill="#f57c00" />
            <path d="M12 8v6" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
            <circle cx="12" cy="17" r="1.2" fill="#fff" />
          </svg>
        )}
        {type === "info" && (
          <svg width="35px" height="35px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="none">
            <circle cx="12" cy="12" r="12" fill="#1976d2" />
            <circle cx="12" cy="7" r="1.5" fill="#fff" />
            <path d="M11 10h2v8h-2z" fill="#fff" />
          </svg>
        )}
      </div>
      <span className="toast-message">{message}</span>
    </div>
  );
};

export default ToastProvider;
