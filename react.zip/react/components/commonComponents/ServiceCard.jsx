import React from "react";

const ServiceCard = ({
  title,
  count,
  badgeBg = "#FEE2E2",
  badgeColor = "#DC2626",
  countColor = "#0F766E",
}) => {
  return (
    <div className="bg-white  border-gray-300 rounded-2xl p-6 flex flex-col items-center justify-center h-28 shadow-sm">
      <span
        className="px-3 py-1 rounded-full text-xs font-medium"
        style={{
          backgroundColor: badgeBg,
          color: badgeColor,
        }}
      >
        {title}
      </span>

      <h1
        className="text-5xl font-bold mt-2"
        style={{ color: countColor }}
      >
        {count}
      </h1>
    </div>
  );
};

export default ServiceCard;