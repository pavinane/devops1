import React from "react";

const metrics = [
  {
    label: "Total Profit",
    value: "$1,619",
    percent: 8.6,
    color: "bg-green-500",
    track: "bg-green-100",
  },
  {
    label: "Total Income",
    value: "$3,571",
    percent: 86.4,
    color: "bg-blue-500",
    track: "bg-blue-100",
  },
  {
    label: "Total Expenses",
    value: "$3,430",
    percent: 74.5,
    color: "bg-red-500",
    track: "bg-red-100",
  },
];

const SalesOverview = () => {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 w-full">
      <h2 className="text-lg font-semibold text-gray-800 mb-5">
        Sales Overview
      </h2>

      <div className="space-y-5">
        {metrics.map(({ label, value, percent, color, track }) => (
          <div key={label}>
            <div className="flex justify-between items-center mb-1.5">
              <span className="text-sm font-medium text-gray-700">
                {label}
              </span>
              <span className="text-sm text-gray-500">
                {value} <span className="text-gray-400">({percent}%)</span>
              </span>
            </div>

            <div className={`w-full h-2 rounded-full ${track}`}>
              <div
                className={`h-2 rounded-full ${color} transition-all duration-700`}
                style={{ width: `${percent}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SalesOverview;