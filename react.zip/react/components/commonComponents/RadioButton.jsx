import React from "react";

const RadioButton = ({
    options = [],
    name,
    errors,
    selectedOption,
    onSelect,
    label,
    fontClass,
    textSize,
    width,
    height,
    required = false,
    disabled = false,
    marginBottom = "mb-5",
    gapBtwn = false,
    fromReport
}) => {
    return (
        <>
            <div className={`${width} ${height} ${marginBottom}`}>
                <label
                    className={`
            block mb-2
            ${textSize || ""}
            ${fontClass || "font-medium"}
            ${disabled ? "cursor-normal" : ""}
          `}
                >
                    {label}
                    {required && <span className="text-red-500"> *</span>}
                </label>

                <div className={`flex ml-2 gap-10 sm:gap-3 ${gapBtwn ? "lg:gap-16" : ""} flex-wrap md:flex-nowrap`}>
                    {options.map((option) => {
                        const id = `${name}-${option.value}`;

                        return (
                            <label
                                key={option.value}
                                htmlFor={id}
                                className={`flex items-center gap-2 ${disabled ? "cursor-normal" : "cursor-pointer"
                                    }`}
                            >
                                <input
                                    id={id}
                                    type="radio"
                                    name={name}
                                    value={option.value}
                                    checked={selectedOption === option.value}
                                    onChange={() => onSelect(option.value, name)}
                                    disabled={disabled}
                                    className="accent-[var(--fc-btn-bg)] scale-150 cursor-pointer "
                                />
                                <span className={`text-black  font-medium md:text-base text-[14px]  ${fromReport && 'w-[71px]'}`}>
                                    {option.label}
                                </span>
                            </label>
                        );
                    })}
                </div>
            </div>

            {errors && (
                <p className="text-red-500 text-xs sm:text-sm pl-3 mt-1 font-medium">
                    {errors}
                </p>
            )}
        </>
    );
};

export default RadioButton;
