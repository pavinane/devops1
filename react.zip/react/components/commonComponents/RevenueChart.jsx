import { useState, useEffect } from "react";
import { useReusableMutation } from "../../customHooks/useDataQuery";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { useSelector } from "react-redux";

// ─── Tab config ────────────────────────────────────────────────────────────────
const TAB_CONFIG = [
  { label: "Weekly",  key: "weekly" },
  { label: "Monthly", key: "monthly" },
  { label: "Yearly",  key: "yearly" },
];

// ─── Transform API response to chart data ─────────────────────────────────────
// API shape: { labels: [...], datasets: [{ name: "Veg", data: [...] }, { name: "Non-Veg", data: [...] }] }
// Chart shape: [{ month: "Mon", income: 30000, expense: 78000 }, ...]
const transformTrend = (trend) => {
  if (!trend?.labels?.length || !trend?.datasets?.length) return [];
  // datasets[0] = Veg (income), datasets[1] = Non-Veg (expense)
  const vegDataset    = trend.datasets[0] || {};
  const nonVegDataset = trend.datasets[1] || {};
  return trend.labels.map((label, i) => ({
    month:   label,
    income:  Number(vegDataset.data?.[i])    || 0,
    expense: Number(nonVegDataset.data?.[i]) || 0,
  }));
};

// ─── Helpers ───────────────────────────────────────────────────────────────────
const formatYAxis = (value) => (value >= 1000 ? `${value / 1000}k` : value);

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div style={{ background: "#fff", border: "1px solid #e5e7eb", borderRadius: "10px", padding: "10px 16px", boxShadow: "0 4px 16px rgba(0,0,0,0.08)", fontFamily: "'DM Sans', sans-serif" }}>
        <p style={{ margin: 0, fontWeight: 600, color: "#374151", marginBottom: 6 }}>{label}</p>
        {payload.map((entry) => (
          <p key={entry.name} style={{ margin: "2px 0", color: entry.color, fontWeight: 500, fontSize: 13 }}>
            {entry.name === "income" ? "Veg" : "Non-Veg"}:{" "}
            <span style={{ color: "#111827" }}>{entry.value.toLocaleString()}</span>
          </p>
        ))}
      </div>
    );
  }
  return null;
};

const CustomLegend = () => (
  <div style={{ display: "flex", justifyContent: "center", gap: "24px", marginBottom: "8px", fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: "#6b7280" }}>
    <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
      <span style={{ width: 10, height: 10, borderRadius: "50%", background: "#4ade80", display: "inline-block" }} />
      Veg
    </span>
    <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
      <span style={{ width: 10, height: 10, borderRadius: "50%", background: "#facc15", display: "inline-block" }} />
      Non-veg
    </span>
  </div>
);

const Skeleton = () => (
  <div style={{ padding: "24px 28px" }}>
    <div style={{ width: 120, height: 20, borderRadius: 6, background: "#f3f4f6", marginBottom: 8, animation: "pulse 1.4s ease-in-out infinite" }} />
    <div style={{ width: 160, height: 14, borderRadius: 6, background: "#f3f4f6", marginBottom: 24, animation: "pulse 1.4s ease-in-out infinite" }} />
    <div style={{ width: "100%", height: 280, borderRadius: 8, background: "#f9fafb", animation: "pulse 1.4s ease-in-out infinite" }} />
    <style>{`@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }`}</style>
  </div>
);

// ─── Main Component ────────────────────────────────────────────────────────────
export default function RevenueChart() {
  const { token } = useSelector((state) => state.user);

  const [selectedTab, setSelectedTab]   = useState(TAB_CONFIG[0]);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [chartDataMap, setChartDataMap] = useState({});
  const [percentageChange, setPercentageChange] = useState(null);

  // ─── API mutation (same pattern as InterviewMeetingChart) ─────────────────
  const { mutate: fetchDashboardStats, isPending } = useReusableMutation({
    onSuccess: (data) => {
      const responseData = data?.data || {};

      setPercentageChange(responseData?.percentage_change ?? null);

      // Transform and cache all three trend keys at once
      const mapped = {};
      TAB_CONFIG.forEach(({ key }) => {
        // Use the key if it exists (even if data values are 0)
        mapped[key] = transformTrend(responseData[key] ?? {});
      });
      setChartDataMap(mapped);
    },
    onError: () => {},
  });

  // ─── Fetch on mount ──────────────────────────────────────────────────────
  useEffect(() => {
    fetchDashboardStats({
      endPoint: "api/admin/dashboard",
      method: "GET",
      token,
    });
  }, []);

  const chartData = chartDataMap[selectedTab.key] || [];
  const hasData   = Object.keys(chartDataMap).length > 0;

  // ─── Loading skeleton ────────────────────────────────────────────────────
  if (isPending && !hasData) {
    return (
      <div style={{ background: "#fff", borderRadius: "16px", boxShadow: "0 2px 16px rgba(0,0,0,0.07)", maxWidth: 760, width: "100%" }}>
        <Skeleton />
      </div>
    );
  }

  return (
    <div style={{ background: "#fff", borderRadius: "16px", padding: "24px 28px", boxShadow: "0 2px 16px rgba(0,0,0,0.07)", fontFamily: "'DM Sans', sans-serif", maxWidth: 1200, width: "100%" }}>

      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "4px" }}>
        <div>
          <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: "#111827", letterSpacing: "-0.3px" }}>Food Orders</h2>
          {percentageChange !== null && (
            <p style={{ margin: "2px 0 0", fontSize: 12.5, color: "#6b7280" }}>
              <span style={{ color: "#22c55e", fontWeight: 600 }}>(+{percentageChange}%)</span> than last year
            </p>
          )}
        </div>

        {/* Dropdown */}
        <div style={{ position: "relative" }}>
          <button
            onClick={() => setDropdownOpen((v) => !v)}
            style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 14px", border: "1.5px solid #e5e7eb", borderRadius: "10px", background: "#fff", cursor: "pointer", fontSize: 14, fontWeight: 600, color: "#374151", fontFamily: "'DM Sans', sans-serif", outline: "none" }}
          >
            {selectedTab.label}
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
              style={{ transform: dropdownOpen ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 0.2s" }}>
              <polyline points="6 9 12 15 18 9" />
            </svg>
          </button>

          {dropdownOpen && (
            <div style={{ position: "absolute", top: "calc(100% + 6px)", right: 0, background: "#fff", border: "1.5px solid #e5e7eb", borderRadius: "10px", boxShadow: "0 8px 24px rgba(0,0,0,0.1)", overflow: "hidden", zIndex: 10, minWidth: "100%" }}>
              {TAB_CONFIG.map((tab) => (
                <div
                  key={tab.key}
                  onClick={() => { setSelectedTab(tab); setDropdownOpen(false); }}
                  style={{ padding: "8px 16px", cursor: "pointer", fontSize: 14, fontWeight: tab.key === selectedTab.key ? 700 : 500, color: tab.key === selectedTab.key ? "#22c55e" : "#374151", background: tab.key === selectedTab.key ? "#f0fdf4" : "transparent" }}
                  onMouseEnter={(e) => { if (tab.key !== selectedTab.key) e.currentTarget.style.background = "#f9fafb"; }}
                  onMouseLeave={(e) => { if (tab.key !== selectedTab.key) e.currentTarget.style.background = "transparent"; }}
                >
                  {tab.label}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Legend */}
      <div style={{ marginTop: 16 }}>
        <CustomLegend />
      </div>

      {/* Chart */}
      {chartData.length === 0 ? (
        <ResponsiveContainer width="100%" height={280}>
          <AreaChart
            data={[
              { month: "Mon", income: 0, expense: 0 },
              { month: "Tue", income: 0, expense: 0 },
              { month: "Wed", income: 0, expense: 0 },
              { month: "Thu", income: 0, expense: 0 },
              { month: "Fri", income: 0, expense: 0 },
              { month: "Sat", income: 0, expense: 0 },
              { month: "Sun", income: 0, expense: 0 },
            ]}
            margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
          >
            <defs>
              <linearGradient id="emptyGradient1" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%"  stopColor="#4ade80" stopOpacity={0.15} />
                <stop offset="95%" stopColor="#4ade80" stopOpacity={0.01} />
              </linearGradient>
              <linearGradient id="emptyGradient2" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%"  stopColor="#facc15" stopOpacity={0.15} />
                <stop offset="95%" stopColor="#facc15" stopOpacity={0.01} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="5 5" stroke="#f3f4f6" vertical={false} />
            <XAxis dataKey="month" axisLine={false} tickLine={false}
              tick={{ fontSize: 12, fill: "#d1d5db", fontFamily: "'DM Sans', sans-serif" }} dy={8} />
            <YAxis tickFormatter={formatYAxis} axisLine={false} tickLine={false}
              tick={{ fontSize: 12, fill: "#d1d5db", fontFamily: "'DM Sans', sans-serif" }}
              dx={-4} domain={[0, 50]} ticks={[0, 10, 20, 30, 40, 50]} />
            <Area type="monotone" dataKey="income"  stroke="#4ade80" strokeWidth={2} strokeOpacity={0.3} fill="url(#emptyGradient1)" dot={false} />
            <Area type="monotone" dataKey="expense" stroke="#facc15" strokeWidth={2} strokeOpacity={0.3} fill="url(#emptyGradient2)" dot={false} />
          </AreaChart>
        </ResponsiveContainer>
      ) : (
      <ResponsiveContainer width="100%" height={280}>
        <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="incomeGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%"  stopColor="#4ade80" stopOpacity={0.35} />
              <stop offset="95%" stopColor="#4ade80" stopOpacity={0.02} />
            </linearGradient>
            <linearGradient id="expenseGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%"  stopColor="#facc15" stopOpacity={0.45} />
              <stop offset="95%" stopColor="#facc15" stopOpacity={0.02} />
            </linearGradient>
          </defs>

          <CartesianGrid strokeDasharray="" stroke="#f3f4f6" vertical={false} />

          <XAxis dataKey="month" axisLine={false} tickLine={false}
            tick={{ fontSize: 12, fill: "#9ca3af", fontFamily: "'DM Sans', sans-serif" }} dy={8} />

          <YAxis tickFormatter={formatYAxis} axisLine={false} tickLine={false}
            tick={{ fontSize: 12, fill: "#9ca3af", fontFamily: "'DM Sans', sans-serif" }}
            dx={-4} domain={([dataMin, dataMax]) => [0, dataMax === 0 ? 10 : Math.ceil(dataMax * 1.2)]} />

          <Tooltip content={<CustomTooltip />} cursor={false} />

          <Area type="monotone" dataKey="expense" stroke="#facc15" strokeWidth={2.5}
            fill="url(#expenseGradient)"
            dot={{ r: 4, fill: "#facc15", strokeWidth: 0 }}
            activeDot={{ r: 6, fill: "#facc15", strokeWidth: 0 }} />

          <Area type="monotone" dataKey="income" stroke="#22c55e" strokeWidth={2.5}
            fill="url(#incomeGradient)"
            dot={{ r: 4, fill: "#4ade80", strokeWidth: 0 }}
            activeDot={{ r: 6, fill: "#22c55e", strokeWidth: 0 }} />
        </AreaChart>
      </ResponsiveContainer>
      )}
    </div>
  );
}