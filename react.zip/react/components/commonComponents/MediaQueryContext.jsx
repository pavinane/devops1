import React, { createContext, useContext } from "react";
import { useMediaQuery } from "react-responsive";

// Create a Context
const MediaQueryContext = createContext();

// Provider component
export const MediaQueryProvider = ({ children }) => {
  const isPortrait = useMediaQuery({ orientation: "portrait" });
  const isLandscape = useMediaQuery({ orientation: "landscape" });
  const isDesktop = useMediaQuery({ minWidth: 1024 });

  const isMobile = useMediaQuery({ minWidth: 0, maxWidth: 601 });
  const isTablet = useMediaQuery({ minWidth: 601, maxWidth: 1023 });

  const values = {
    isDesktop,
    isTablet,
    isMobile,
    isPortrait,
    isLandscape
  };

  return (
    <MediaQueryContext.Provider value={values}>
      {children}
    </MediaQueryContext.Provider>
  );
};

// Custom Hook to use context values
export const useMediaQueryValues = () => {
  return useContext(MediaQueryContext);
};
