import React from "react";

const PrimaryButton = ({ 
    title, onClick, width = "w-auto",icon,
    bgColor = "bg-[#099309] ", btnBorder = "border border-black", textColor = "text-white", customClass = "", disable, type = "button", textSize = "text-base"


}) => {

    return (
        <button
            onClick={onClick}
            disabled={disable}
            type={type}
            className={
                ` cursor-pointer
        flex items-center justify-center
        rounded-full
        gap-[10px]
        px-[20px] py-[12px]
        disabled:opacity-50 disabled:cursor-not-allowed
        ${width} 
        ${bgColor} 
        ${btnBorder}
        ${textColor}
        ${customClass}
          `}
        >
              {icon}
            <span className={` font-inter font-medium leading-none ${textSize}`}>
                {title}
            </span>
        </button>
    );
};

export default PrimaryButton;
