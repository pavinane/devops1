import React from "react";
// import { Mail, Phone, Pencil, Trash2 } from "lucide-react";

const UserCard = ({
    name,
    email,
    phone,
    role,
    building,
    room,
    status = "Active",
    onEdit,
    onDelete,
    showRoomBuilding = true,
    trucate = true,
    onClick,
    row
}) => {
    return (
        <div className="bg-white border border-gray-200 rounded-3xl p-5 shadow-sm" onClick={() => onClick?.(row)}>
            {/* Header */}
            <div className="flex justify-between items-start mb-3">
                <h3
                    className={`text-[15px] font-semibold text-gray-900 ${trucate && "tracking-tight truncate"} max-w-20`}
                >
                    {name}
                </h3>

                <span
                    className={`px-3 py-1 rounded-full text-xs font-medium ${status?.toLowerCase() === "active"
                        ? "bg-green-100 text-green-700"
                        : "bg-red-100 text-red-700"
                        }`}
                >
                    {status}
                </span>
            </div>

            {/* Details */}
            <div className="space-y-2 text-[13px] text-text-grey1 font-poppins-medium tracking-wide">
                {
                    email && <div className="flex items-center gap-2">
                        {/* <Mail size={16} /> */}
                        <span className="truncate max-w-40">{email}</span>
                    </div>
                }

                {
                    phone && <div className="flex items-center gap-2">
                        {/* <Phone size={16} /> */}
                        <span>{phone}</span>
                    </div>
                }
                {
                    role && <div className="flex items-center gap-2">
                        <span>{role}</span>
                    </div>
                }
            </div>

            {/* Tags */}
            {showRoomBuilding && (
                <div className="flex gap-2 mt-4 flex-wrap">
                    <span className="px-3 py-1 truncate max-w-20 text-xs font-medium  rounded-full bg-gray-200 text-gray-700">
                        {building}
                    </span>

                    <span className="px-3 py-1 text-xs font-medium truncate max-w-20 rounded-full bg-blue-100 text-blue-700">
                        Room {room}
                    </span>

                </div>
            )}

            {/* Actions */}
            <div className="grid grid-cols-2 gap-3 mt-5">
                <button
                    onClick={(e) => {
                        e.stopPropagation();
                        onEdit?.(e);
                    }}
                    className="border border-teal-600 text-teal-600 text-[11px] rounded-xl py-2 flex items-center justify-center gap-2 hover:bg-teal-50 transition"
                >
                    Edit
                </button>

                <button
                    onClick={(e) => {
                        e.stopPropagation();
                        onDelete?.(e);
                    }}
                    className="border border-red-500 text-red-500 text-[11px] rounded-xl py-2 flex items-center justify-center gap-2 hover:bg-red-50 transition"
                >
                    Delete
                </button>
            </div>
        </div>
    );
};

export default UserCard;