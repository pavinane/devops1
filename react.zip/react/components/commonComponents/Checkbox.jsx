import React from "react";

const Checkbox = ({
    id,
    label,
    checked = false,
    onChange,
    disabled = false,
    className = "",
}) => {
    const checkboxId = id || `checkbox-${label?.replace(/\s+/g, "-")}`;

    return (
        <label
            htmlFor={checkboxId}
            className={`flex items-center gap-2 select-none
        ${disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}
        ${className}`}
        >

            <input
                id={checkboxId}
                type="checkbox"
                checked={checked}
                disabled={disabled}
                onChange={(e) => onChange?.(e.target.checked)}
                className="sr-only peer"
            />


            <span
                className={`
          w-4 h-4 rounded flex items-center justify-center
          border border-black
          transition-all duration-150
          peer-focus-visible:ring-2 peer-focus-visible:ring-black
          ${checked
                        ? "bg-yellow-400 border-yellow-400"
                        : "bg-transparent"
                    }
        `}
            >
                {checked && (
                    <svg
                        viewBox="0 0 24 24"
                        className="w-3 h-3 text-black"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="3"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                    >
                        <polyline points="20 6 9 17 4 12" />
                    </svg>
                )}
            </span>

            {label && (
                <span className="text-sm text-gray-700">
                    {label}
                </span>
            )}
        </label>
    );
};

export default Checkbox;
