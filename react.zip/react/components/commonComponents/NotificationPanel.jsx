import React from "react";
import { BsBellFill } from "react-icons/bs";
import { HiOutlineLightBulb } from "react-icons/hi";

const NotificationPanel = () => {
  return (
    <div className="flex flex-col gap-6 w-full">
      {/* Notification Card */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 px-6 py-5 flex items-center gap-5">
        <BsBellFill className="text-yellow-400 text-3xl flex-shrink-0" />

        <div>
          <h3 className="text-xl font-semibold text-gray-800">
            Start your day with New Notification.
          </h3>

          <p className="text-gray-500 mt-1">
            You have{" "}
            <span className="text-blue-500 font-medium cursor-pointer">
              2 new notification
            </span>
          </p>
        </div>
      </div>

      {/* Sales Monitor Card */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 px-6 py-5 flex items-center gap-5">
        <HiOutlineLightBulb className="text-green-500 text-3xl flex-shrink-0" />

        <div>
          <h3 className="text-xl font-semibold text-gray-800">
            Monitor your Sales and Profitability
          </h3>

          <p className="text-blue-500 font-medium mt-1 cursor-pointer">
            View Performance
          </p>
        </div>
      </div>
    </div>
  );
};

export default NotificationPanel;