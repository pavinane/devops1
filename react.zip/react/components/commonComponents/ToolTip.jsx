import React from 'react';
import { Tooltip } from "react-tooltip";

const TooltipContainer = ({ id, maxWidth }) => {
    return (
        <div className="tooltip-container">
            <Tooltip
                id={id}
                className={`tooltip-diff-arrow whitespace-pre-wrap! wrap-break-word! ${maxWidth && maxWidth}`}
            />
        </div>
    );
};

export default TooltipContainer;
