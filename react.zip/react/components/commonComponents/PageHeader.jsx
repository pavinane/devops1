import React from "react";
import TextInput from "./TextInput";

function PageHeader({ title }) {
    return (
        <div className="row mb-4">
            <div className="col-md-12">
                <div className="flex items-center justify-between">
                    <div>
                        <h2 className="text-lg md:text-xl lg:text-2xl font-bold">
                            {title}
                        </h2>
                    </div>

                    <div>
                        <TextInput
                            name="date"
                            value={new Date().toLocaleDateString("en-GB")}
                            readOnly
                            showErrors={false}
                            width="w-full max-w-[120px] md:max-w-[140px] lg:max-w-[160px] !mb-0"
                        />
                    </div>
                </div>
            </div>
        </div>
    );
}

export default PageHeader;