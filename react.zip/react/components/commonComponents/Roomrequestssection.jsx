import React from "react";
import SectionCard from "../../pages/buildings/SectionCard"


function RoomRequestsSection({ requests }) {
    const requestsIcon = (
        <svg
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            className="text-gray-600"
        >
            <path d="M9 11l3 3L22 4" />
            <path d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
    );

    const getStatusColor = (status) => {
        switch (status) {
            case "pending":
                return "text-[#B56A2A] bg-[#EFD1B1]";
            case "approved":
                return "bg-green-100 text-green-700";
            case "rejected":
                return "bg-red-100 text-red-600";
            default:
                return "bg-gray-100 text-gray-600";
        }
    };

    return (
        <SectionCard icon={requestsIcon} title="Room requests">
            {requests && requests.length > 0 ? (
                <div className="space-y-3">
                    {requests.map((request) => (
                        <div
                            key={request.id}
                            className="border border-gray-300 rounded-lg p-4 hover:bg-gray-50 transition"
                        >
                            <div className="flex items-center justify-between mb-2">
                                <div className="flex items-center gap-2">
                                    <span className="text-sm font-semibold text-gray-900">
                                        {request.category}
                                    </span>
                                    <span className="text-[10px] font-medium text-gray-600 bg-blue-50 px-2 py-1 rounded-2xl">
                                        Qty : {request.quantity}
                                    </span>
                                </div>
                                <span
                                    className={`text-xs px-3 py-1 rounded-full ${getStatusColor(
                                        request.status
                                    )}`}
                                >
                                    {request.status === "pending"
                                        ? "Pending"
                                        : request.status === "approved"
                                        ? "Approved"
                                        : "Rejected"}
                                </span>
                            </div>

                            <p className="text-xs text-gray-600">
                                {request.employee_name || "Unknown"} · {request.employee_id} · {request.requested_date}
                            </p>
                        </div>
                    ))}
                </div>
            ) : (
                <p className="text-sm text-gray-400">No requests yet</p>
            )}
        </SectionCard>
    );
}

export default RoomRequestsSection;