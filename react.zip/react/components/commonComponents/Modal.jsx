import React, { useEffect, useRef } from "react";
import ReactDOM from "react-dom";
import closeIcon from "../../assets/Buttons/CloseIcon.svg";

const Modal = ({
    isOpen,
    onClose,
    outSideClick = false,
    children,
    size = "medium",
    status,
    title,
    showCloseButton,
    titleClass = "",
    zIndex = "z-50",
    animation = "",
    customClass = "",
    position,
    width = "w-[300px]",
    height = "auto",
    tabs,
    activeTab,
    onTabChange,
}) => {
    const modalRef = useRef(null);


    // 🔹 ESC + TAB handling
    const handleKeyDown = (event) => {
        if (event.key === "Escape") {
            onClose && onClose();
        }

        if (event.key === "Tab" && modalRef.current) {
            const focusableElements = modalRef.current.querySelectorAll(
                'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
            );

            if (focusableElements.length === 0) return;

            const firstElement = focusableElements[0];
            const lastElement = focusableElements[focusableElements.length - 1];

            if (event.shiftKey) {
                if (document.activeElement === firstElement) {
                    event.preventDefault();
                    lastElement.focus();
                }
            } else {
                if (document.activeElement === lastElement) {
                    event.preventDefault();
                    firstElement.focus();
                }
            }
        }
    };
    useEffect(() => {
        if (isOpen) {
            document.body.style.overflow = "hidden";
        } else {
            document.body.style.overflow = "unset";
        }

        return () => {
            document.body.style.overflow = "unset";
        };
    }, [isOpen]);
    useEffect(() => {
        if (!isOpen) return;

        const handleOutsideClick = (event) => {
            if (
                outSideClick &&
                modalRef.current &&
                !modalRef.current.contains(event.target)
            ) {
                onClose();
            }
        };

        document.addEventListener("mousedown", handleOutsideClick);
        document.addEventListener("keydown", handleKeyDown);

        return () => {
            document.removeEventListener("mousedown", handleOutsideClick);
            document.removeEventListener("keydown", handleKeyDown);
        };
    }, [isOpen, outSideClick, onClose]);

    if (!isOpen) return null;

    return ReactDOM.createPortal(
        <div
            className={`${animation} fixed inset-0 bg-black/30 flex items-center 
      ${position === "end" ? "justify-end" : "justify-center"} ${zIndex}`}

            // 🔹 Overlay click
            onClick={() => {
                if (outSideClick) onClose();
            }}
        >
            <div
                ref={modalRef}
                className={`${customClass}  bg-white relative rounded-[20px] p-6
          ${size === "medium"
                        ? `${width} ${height}`
                        : size === "small"
                            ? "w-[350px] h-auto"
                            : size === "large"
                                ? "w-full h-full"
                                : ""
                    }
          ${status ? "rounded-[20px]" : ""}
        `}
                // 🔹 Prevent inside click from closing modal
                onClick={(e) => e.stopPropagation()}
            >
                {(title || showCloseButton) && (
                    <div className="flex items-center justify-between">
                        <h2
                            className={`text-md whitespace-nowrap xsxl:text-xl font-medium  text-text-black1  ${titleClass}`}
                        >
                            {title}
                        </h2>


                        {showCloseButton && (

                            <button
                                onClick={onClose}
                                className="text-black text-xl cursor-pointer  w-[30px] h-[30px] flex items-center justify-center transition-transform duration-200 hover:scale-125"
                            >
                                ✕
                            </button>
                        )}
                    </div>
                )}

                {children}
            </div>
        </div>,
        document.body,
    );
};

export default Modal;
