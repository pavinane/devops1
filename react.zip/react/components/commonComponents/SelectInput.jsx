import React, { useEffect, useRef, useState } from "react";
import DownArrow from "../../assets/images/downArrow.svg";

export default function SelectInput({
    width = "w-full",
    height = "min-h-[46px]",
    options = [],
    multivalueheight = "max-h-[100px]",
    value,
    label,
    required,
    onChange,
    name,
    errors,
    placeholder = "Select",
    multiSelect = false,
    disabled = false,
}) {
    const [open, setOpen] = useState(false);
    const dropdownRef = useRef(null);

    const hasValue = multiSelect
        ? Array.isArray(value) && value.length > 0
        : Boolean(value?.label);

    const isSelected = (option) => {
        if (multiSelect && Array.isArray(value)) {
            return value.some((v) => v.value === option.value);
        }
        return value?.value === option.value;
    };

    const removeChip = (opt) => {
        const updated = value.filter((item) => item.value !== opt.value);
        onChange(updated, name);
    };

    const handleOptionClick = (option) => {
        if (option?.value === undefined || !option?.label) return;

        if (multiSelect) {
            let updated = Array.isArray(value) ? [...value] : [];
            const exists = updated.some((item) => item.value === option.value);

            updated = exists
                ? updated.filter((item) => item.value !== option.value)
                : [...updated, option];

            onChange(updated, name);
        } else {
            onChange(option, name);
            setOpen(false);
        }
    };

    /* Outside click */
    useEffect(() => {
        const handleClickOutside = (e) => {
            if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
                setOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () =>
            document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    return (
        <>

            <div className="w-full">
                {label && (
                    <label className="block mb-2 font-medium text-text-black1 text-[16px]">
                        {label}
                        {required && <span className="text-red-500"> *</span>}
                    </label>
                )}
                <div
                    className={`mb-4 font-medium ${width}`}

                >




                    <div className="relative" ref={dropdownRef}>
                        <div
                            onClick={() => !disabled && setOpen((p) => !p)}
                            className={`flex items-center justify-between ${height}
            border rounded-lg px-3 cursor-pointer
            ${errors ? "border-red-500" : "border-gray-300"}
            ${disabled ? "bg-input-bgColor  text-text-black1" : "bg-white"}`}
                        >
                            {multiSelect ? (
                                <div
                                    className={`flex flex-wrap gap-1 ${multivalueheight} overflow-y-auto`}
                                >
                                    {hasValue ? (
                                        value.map((opt, i) => (
                                            <div
                                                key={i}
                                                className="bg-black text-white px-2 py-1 rounded-2xl flex items-center gap-1 text-[16px] mt-1.5 mb-1.5 max-w-full"
                                            >
                                                <span className="truncate">{opt.label}</span>
                                                {!disabled && (
                                                    <span
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            removeChip(opt);
                                                        }}
                                                        className="cursor-pointer text-white flex-shrink-0"
                                                    >
                                                        ✕
                                                    </span>
                                                )}
                                            </div>
                                        ))
                                    ) : (
                                        <span className="text-placeholder text-gray-400   text-[14px] font-medium">
                                            {placeholder}
                                        </span>
                                    )}
                                </div>
                            ) : (
                                <span
                                    className={`text-sm truncate ${hasValue
                                        ? "text-black"
                                        : "text-placeholder text-gray-400 text-[14px] font-medium"
                                        }`}
                                >
                                    {hasValue ? value.label : placeholder}
                                </span>
                            )}


                            <img
                                src={DownArrow}
                                alt="toggle"
                                className={`w-4 h-4 ml-2 transition-transform ${open ? "rotate-180" : ""
                                    }`}
                            />
                        </div>

                        {open && (
                            <div
                                className="absolute top-full left-0 w-full mt-2
            max-h-48 overflow-y-auto bg-white
            shadow-lg rounded-lg border border-gray-300 z-50 pb-2"
                            >
                                {options.length > 0 ? (
                                    options.map((opt, i) => (
                                        <div
                                            key={i}
                                            onClick={() => handleOptionClick(opt)}
                                            className={`flex items-center gap-2 px-4 py-3 text-sm cursor-pointer
                  ${isSelected(opt)
                                                    ? "bg-dashbordLayoutBG"
                                                    : "hover:bg-dashbordLayoutBG"
                                                }`}
                                        >
                                            {multiSelect && (
                                                <input
                                                    type="checkbox"
                                                    checked={isSelected(opt)}
                                                    readOnly
                                                    className="w-3 h-3 accent-yellow-400 cursor-pointer rounded-lg"
                                                />
                                            )}
                                            {opt.label}
                                        </div>
                                    ))
                                ) : (
                                    <div className="p-2.5 text-center text-sm">
                                        No data available
                                    </div>
                                )}
                            </div>
                        )}
                    </div>

                    <p className="text-xs text-red-500 min-h-4 mt-1">{errors}</p>
                </div>
            </div>
        </>
    );
}
