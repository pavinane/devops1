import React from "react";

const CommonDatePicker = ({
  label,
  name,
  value,
  onChange,
  min
}) => {
  return (
    <div>
      {label && (
        <label className="block text-sm font-semibold mb-2">
          {label}
        </label>
      )}

      <input
        type="date"
        name={name}
        value={value}
        onChange={onChange}
         min={min}
        className="w-full border border-gray-300 rounded-lg px-3 py-[11px]"
      />
    </div>
  );
};

export default CommonDatePicker;