import React from "react";
import Chart from "react-apexcharts";

const DEFAULT_SPARKLINE_DATA = [
  8, 14, 10, 24, 16, 32, 20, 38, 18, 30, 17, 34,
];

const Sparkline = ({
  color,
  data = DEFAULT_SPARKLINE_DATA,
  categories = [],
  seriesName = "Value",
}) => {
  const chartData = data.length ? data.map((value) => Number(value) || 0) : [0];
  const options = {
    chart: {
      type: "area",
      sparkline: { enabled: true },
      animations: { enabled: true, speed: 500 },
      toolbar: { show: false },
    },
    colors: [color],
    dataLabels: { enabled: false },
    stroke: {
      curve: "monotoneCubic",
      width: 1.5,
    },
    fill: {
      type: "solid",
      opacity: 0.72,
    },
    markers: { size: 0 },
    grid: {
      show: false,
      padding: {
        top: 2,
        right: 0,
        bottom: 0,
        left: 0,
      },
    },
    xaxis: {
      categories,
      labels: { show: false },
      axisBorder: { show: false },
      axisTicks: { show: false },
      crosshairs: { width: 1 },
      tooltip: { enabled: false },
    },
    yaxis: {
      min: 0,
      show: false,
      labels: { show: false },
    },
    tooltip: {
      enabled: true,
      fixed: { enabled: false },
      x: { show: categories.length > 0 },
      y: {
        title: {
          formatter: () => `${seriesName}: `,
        },
        formatter: (value) => Math.round(value).toLocaleString(),
      },
      marker: { show: false },
    },
  };

  return (
    <Chart
      options={options}
      series={[{ name: seriesName, data: chartData }]}
      type="area"
      width="100%"
      height={48}
    />
  );
};

const Commonstatcard = ({
  title,
  value,
  growth,
  chart,
  growthColor = "text-orange-500",
  subtitle
}) => {
  return (
    <div className="bg-white border border-gray-200 rounded-lg p-5 shadow-sm">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-gray-500 text-sm">{title}</p>
          <h2 className="text-2xl font-bold text-gray-900 mt-1">{value}</h2>
        </div>

        {chart && (
          <div className="w-24 h-12 overflow-visible">
            {chart}
          </div>
        )}
      </div>

      <hr className="my-4 border-gray-200" />

      <div className="text-sm">
        <span className={`font-medium ${growthColor}`}>
          {/* ↗  */}
          {growth}
        </span>
        <span className="text-gray-500 ml-1">
        {subtitle}
        </span>
      </div>
    </div>
  );
};

export { Sparkline };
export default Commonstatcard;
