import { useState, useEffect } from "react";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";

// ─── Replace with your real API call ─────────────────────────────────────────
// Expected API response shape:
// {
//   totalSales: 9600,
//   breakdown: [
//     { name: "Shippings", value: 2, amount: 32.98, color: "#22c55e" },
//     { name: "Refunds",   value: 11, amount: 11,   color: "#facc15" },
//     { name: "Order",     value: 1,  amount: 14.87, color: "#ef4444" },
//     { name: "Income",    value: 86, amount: 3271,  color: "#3b82f6" },
//   ]
// }
const fetchTotalSales = async () => {
  // const res = await fetch("/api/total-sales");
  // return res.json();

  // ── Fallback mock (remove once your API is ready) ──
  await new Promise((r) => setTimeout(r, 800));
  return {
    totalSales: 9600,
    breakdown: [
      { name: "Shippings", value: 2,  amount: 32.98, color: "#22c55e" },
      { name: "Refunds",   value: 11, amount: 11,    color: "#facc15" },
      { name: "Order",     value: 1,  amount: 14.87, color: "#ef4444" },
      { name: "Income",    value: 86, amount: 3271,  color: "#3b82f6" },
    ],
  };
};
// ─────────────────────────────────────────────────────────────────────────────

const CustomTooltip = ({ active, payload }) => {
  if (active && payload && payload.length) {
    const d = payload[0].payload;
    return (
      <div style={{
        background: "#fff", border: "1px solid #e5e7eb", borderRadius: 8,
        padding: "8px 12px", fontSize: 13, fontFamily: "'DM Sans', sans-serif",
        boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
      }}>
        <span style={{ color: d.color, fontWeight: 600 }}>{d.name}</span>
        <span style={{ color: "#374151" }}> ${d.amount} ({d.value}%)</span>
      </div>
    );
  }
  return null;
};

const Skeleton = () => (
  <div style={{ padding: "24px" }}>
    <div style={{ width: 100, height: 18, borderRadius: 6, background: "#f3f4f6", marginBottom: 20, animation: "pulse 1.4s ease-in-out infinite" }} />
    <div style={{ width: 220, height: 220, borderRadius: "50%", background: "#f9fafb", margin: "0 auto 24px", animation: "pulse 1.4s ease-in-out infinite" }} />
    {[1,2,3,4].map(i => (
      <div key={i} style={{ width: "70%", height: 13, borderRadius: 6, background: "#f3f4f6", marginBottom: 10, animation: "pulse 1.4s ease-in-out infinite" }} />
    ))}
    <style>{`@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.4}}`}</style>
  </div>
);

const TotalSalesChart = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeIndex, setActiveIndex] = useState(null);

  useEffect(() => {
    fetchTotalSales()
      .then(setData)
      .catch((e) => setError(e.message || "Failed to load"))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div style={{ background: "#fff", borderRadius: 16, boxShadow: "0 2px 16px rgba(0,0,0,0.07)", maxWidth: 340, width: "100%" }}>
      <Skeleton />
    </div>
  );

  if (error) return (
    <div style={{ background: "#fff", borderRadius: 16, padding: 24, boxShadow: "0 2px 16px rgba(0,0,0,0.07)", maxWidth: 340, textAlign: "center" }}>
      <p style={{ color: "#ef4444", fontSize: 14, fontFamily: "'DM Sans', sans-serif" }}>⚠️ {error}</p>
      <button onClick={() => window.location.reload()} style={{ marginTop: 10, padding: "7px 16px", borderRadius: 8, border: "1px solid #e5e7eb", background: "#fff", cursor: "pointer", fontSize: 13 }}>Retry</button>
    </div>
  );

  const { totalSales, breakdown } = data;
  const activeSlice = activeIndex !== null ? breakdown[activeIndex] : null;

  return (
    <div style={{
      background: "#fff",
      borderRadius: 16,
      padding: "15px",
      boxShadow: "0 2px 16px rgba(0,0,0,0.07)",
      fontFamily: "'DM Sans', sans-serif",
      maxWidth: 840,
      width: "100%",
    }}>
      {/* Title */}
      <h2 style={{ margin: "0 0 16px", fontSize: 17, fontWeight: 700, color: "#111827" }}>
        Total Sales
      </h2>

      {/* Donut Chart */}
      <div style={{ position: "relative", width: "100%", height: 230 }}>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={breakdown}
              cx="50%"
              cy="50%"
              innerRadius={88}
              outerRadius={108}
              dataKey="value"
              strokeWidth={3}
              stroke="#fff"
              onMouseEnter={(_, index) => setActiveIndex(index)}
              onMouseLeave={() => setActiveIndex(null)}
            >
              {breakdown.map((entry, index) => (
                <Cell
                  key={entry.name}
                  fill={entry.color}
                  opacity={activeIndex === null || activeIndex === index ? 1 : 0.55}
                  style={{ cursor: "pointer", transition: "opacity 0.2s" }}
                />
              ))}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
          </PieChart>
        </ResponsiveContainer>

        {/* Center label */}
        <div style={{
          position: "absolute", top: "50%", left: "50%",
          transform: "translate(-50%, -50%)",
          textAlign: "center", pointerEvents: "none",
        }}>
          <p style={{ margin: 0, fontSize: 12, color: "#ef4444", fontWeight: 600 }}>
            {activeSlice ? activeSlice.name : "Total Sales"}
          </p>

          <p style={{ margin: 0, fontSize: 26, fontWeight: 700, color: "#111827", lineHeight: 1.2 }}>
            {activeSlice ? `$${activeSlice.amount}` : totalSales.toLocaleString()}
          </p>
        </div>


      </div>

      {/* Legend */}
      <div style={{ marginTop: 16, display: "flex", flexDirection: "column", gap: 8 }}>
        {breakdown.map((item, i) => (
          <div
            key={item.name}
            onMouseEnter={() => setActiveIndex(i)}
            onMouseLeave={() => setActiveIndex(null)}
            style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", opacity: activeIndex === null || activeIndex === i ? 1 : 0.5, transition: "opacity 0.2s" }}
          >
            <span style={{ width: 10, height: 10, borderRadius: "50%", background: item.color, flexShrink: 0 }} />
            <span style={{ fontSize: 13, color: "#374151" }}>
              {item.name} <strong>${item.amount}</strong>{" "}
              <span style={{ color: "#9ca3af" }}>({item.value}%)</span>
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TotalSalesChart;