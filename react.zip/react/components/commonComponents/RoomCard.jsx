import React from "react";
import Edit from "../../assets/images/Edit.svg";
import Delete from "../../assets/images/Delete.svg";
import View from "../../assets/icons/view.svg";

const RoomCard = ({ row, onClick, onView, onEdit, onDelete }) => {
    return (
        <div
            className="bg-white border border-gray-200 rounded-3xl p-5 shadow-sm cursor-pointer"
            onClick={() => onClick?.(row)}
        >
            <div className="flex justify-between items-start mb-3">
                <h3 className="text-[15px] font-semibold text-gray-900 tracking-tight">
                    Room {row.room}
                </h3>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    row.status === "Active"
                        ? "bg-green-100 text-green-700"
                        : "bg-red-100 text-red-600"
                }`}>
                    {row.status}
                </span>
            </div>

            <div className="space-y-1 text-[13px] text-gray-500">
                <div className="flex items-center gap-2">
                    <span className="text-gray-400">Code:</span>
                    <span>{row.code}</span>
                </div>
                <div className="flex items-center gap-2">
                    <span className="text-gray-400">Floor:</span>
                    <span>{row.floor ?? "—"}</span>
                </div>
                <div className="flex items-center gap-2">
                    <span className="text-gray-400">Members:</span>
                    <span>{row.members}</span>
                </div>
                <div className="flex items-center gap-2">
                    <span className="text-gray-400">Capacity:</span>
                    <span>{row.capacity}</span>
                </div>
            </div>

            <div className="grid grid-cols-3 gap-2 mt-5">
                <button
                    onClick={(e) => { e.stopPropagation(); onView?.(e, row); }}
                    className="border border-gray-300 rounded-xl py-2 flex items-center justify-center hover:bg-gray-50 transition"
                >
                    <span className="text-[11px]">View</span>
                </button>
                <button
                    onClick={(e) => { e.stopPropagation(); onEdit?.(e, row); }}
                    className="border border-[#0aad0a] rounded-xl py-2 flex items-center justify-center hover:bg-teal-50 transition"
                >
                    <span className="text-[11px] text-[#0aad0a]">Edit</span>
                </button>
                <button
                    onClick={(e) => { e.stopPropagation(); onDelete?.(e, row); }}
                    className="border border-red-500 rounded-xl py-2 flex items-center justify-center hover:bg-red-50 transition"
                >
                    <span className="text-[11px] text-red-500">Delete</span>
                </button>
            </div>
        </div>
    );
};

export default RoomCard;
