import React from "react";

const MobileTableCard = ({
  fields = [],
  status,
  actions,
  customContent
}) => {
  return (
    <div className="bg-white border border-gray-200 rounded-2xl p-4 shadow-sm">
      <div className="space-y-3">
        {fields.map((field, index) => (
          <div
            key={index}
            className="flex justify-between items-start border-b border-gray-100 pb-2"
          >
            <span className="text-xs font-semibold text-gray-500 uppercase">
              {field.label}
            </span>

            <span className="text-sm text-gray-800 text-right max-w-[60%] break-words">
              {field.value || "-"}
            </span>
          </div>
        ))}

       {status && (
  <div className="flex justify-between items-center border-b border-gray-100 pb-2">
    <span className="text-xs font-semibold text-gray-500 uppercase">
      Status
    </span>
    {status}
  </div>
)}

{actions && (
  <div className="flex justify-between items-center border-b border-gray-100 pb-2">
    <span className="text-xs font-semibold text-gray-500 uppercase">
      Actions
    </span>
    {actions}
  </div>
)}

{customContent && (
  <div className="flex justify-between items-center border-b border-gray-100 pb-2">
    <span className="text-xs font-semibold text-gray-500 uppercase">
      Attachments
    </span>
    {customContent}
  </div>
)}

      </div>
    </div>
  );
};

export default MobileTableCard;