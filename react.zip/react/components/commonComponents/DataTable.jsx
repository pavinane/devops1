import { useState, useMemo, useRef, useEffect } from "react";
import TooltipContainer from "./ToolTip";

/**
 * DataTable
 *
 * Props
 * ─────
 * columns            – array of { key, label, render? }
 * data               – array of row objects (current page's data when pagination=true)
 * pageSize           – initial page size (ignored when pagination=true; use paginationData.pageSize)
 * searchable         – show search bar (client-side filter; only applies when pagination=false)
 * searchPlaceholder  – placeholder text
 * pageSizeOptions    – options shown in the entries dropdown
 * tableHeight        – max-height of the table body area
 * onRowClick         – (row) => void
 * showCheckbox       – show row selection checkboxes
 *
 * Dynamic pagination (server-driven) props
 * ──────────────────────────────────────────
 * pagination         – boolean; enable external pagination mode
 * paginationData     – { pageIndex, pageSize, totalData, totalPages }
 * setPaginationData  – setState setter for paginationData
 */
export default function DataTable({
  columns = [],
  data = [],
  pageSize: initialPageSize = 10,
  searchable = true,
  searchPlaceholder = "Search...",
  pageSizeOptions = [10, 30, 50],
  tableHeight = 480,
  onRowClick,
  showCheckbox = true,
  showMenu = false,

  // Dynamic pagination
  pagination = false,
  paginationData,
  setPaginationData,
}) {


  const TooltipCell = ({ children }) => {
    const cellRef = useRef(null);

    useEffect(() => {
      if (cellRef.current) {
        cellRef.current.setAttribute(
          "data-tooltip-content",
          cellRef.current.innerText
        );
      }
    }, [children]);

    return (
      <div
        ref={cellRef}
        className="max-w-40 truncate whitespace-nowrap overflow-hidden text-ellipsis"
      >
        {children}
      </div>
    );
  };




  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(new Set());
  const [localPage, setLocalPage] = useState(1);
  const [localPageSize, setLocalPageSize] = useState(initialPageSize);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const handler = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target))
        setDropdownOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const isDynamic = pagination && paginationData && setPaginationData;

  const currentPage = isDynamic ? (paginationData.pageIndex ?? 0) + 1 : localPage;
  const currentPageSize = isDynamic ? (paginationData.pageSize ?? 10) : localPageSize;
  const totalData = isDynamic ? (paginationData.totalData ?? data.length) : undefined;

  const filtered = useMemo(() => {
    if (isDynamic) return data;
    if (!query.trim()) return data;
    const q = query.toLowerCase();
    return data.filter((row) =>
      columns.some((col) =>
        String(row[col.key] ?? "").toLowerCase().includes(q)
      )
    );
  }, [data, query, columns, isDynamic]);

  const totalPages = isDynamic
    ? (paginationData.totalPages ?? 1)
    : Math.max(1, Math.ceil((filtered?.length ?? 0) / currentPageSize));

  const safePage = isDynamic ? currentPage : Math.min(localPage, totalPages);
  const slice = isDynamic
    ? data
    : filtered.slice((safePage - 1) * currentPageSize, safePage * currentPageSize);

  const displayTotalPages = isDynamic ? totalPages : Math.max(1, Math.ceil(filtered.length / currentPageSize));

  if (!data || data.length === 0) {
    return (
      <div style={styles.wrapper}>
        <div style={styles.emptyState}>
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#d1d5db" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" style={{ marginBottom: 12 }}>
            <rect x="3" y="3" width="18" height="18" rx="2" /><line x1="3" y1="9" x2="21" y2="9" /><line x1="9" y1="21" x2="9" y2="9" />
          </svg>
          <p style={styles.emptyStateText}>No data found.</p>
        </div>
      </div>
    );
  }

  const allOnPageSelected =
    slice.length > 0 && slice.every((_, i) => selected.has((safePage - 1) * currentPageSize + i));

  const toggleAll = () => {
    const indices = slice.map((_, i) => (safePage - 1) * currentPageSize + i);
    setSelected((prev) => {
      const next = new Set(prev);
      if (allOnPageSelected) indices.forEach((idx) => next.delete(idx));
      else indices.forEach((idx) => next.add(idx));
      return next;
    });
  };

  const toggleRow = (idx) =>
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(idx) ? next.delete(idx) : next.add(idx);
      return next;
    });

  const handlePageSizeChange = (size) => {
    if (isDynamic) {
      setPaginationData((prev) => ({ ...prev, pageSize: size, pageIndex: 0 }));
    } else {
      setLocalPageSize(size);
      setLocalPage(1);
    }
    setDropdownOpen(false);
  };

  const goToPage = (n) => {
    if (isDynamic) {
      setPaginationData((prev) => ({ ...prev, pageIndex: n - 1 }));
    } else {
      setLocalPage(n);
    }
  };

  const entriesCount = isDynamic ? (totalData ?? data.length) : filtered.length;

  return (
    <div style={styles.wrapper}>
      {/* Search (client-side only) */}
      {searchable && !isDynamic && (
        <div style={styles.searchWrap}>
          <span style={styles.searchIcon}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
          </span>
          <input
            style={styles.searchInput}
            placeholder={searchPlaceholder}
            value={query}
            onChange={(e) => { setQuery(e.target.value); setLocalPage(1); }}
          />
        </div>
      )}

      {/* Table */}
      <div style={{ ...styles.tableWrap, maxHeight: tableHeight, overflowY: "auto" }}>
        <table style={styles.table}>
          <thead className="cursor-default">
            <tr style={styles.headerRow}>
              {showCheckbox && (
                <th style={{ ...styles.th, width: 44 }}>
                  <input
                    type="checkbox"
                    style={styles.checkbox}
                    checked={allOnPageSelected}
                    onChange={toggleAll}
                  />
                </th>
              )}
              {columns.map((col) => (
                <th key={col.key} style={styles.th}>{col.label}</th>
              ))}
              {showMenu && <th style={{ ...styles.th, width: 44 }} />}
            </tr>
          </thead>
          <tbody>
            {slice.length === 0 ? (
              <tr>
                <td colSpan={columns.length + (showCheckbox ? 1 : 0) + (showMenu ? 1 : 0)} style={styles.empty}>
                  No results found.
                </td>
              </tr>
            ) : (
              slice.map((row, i) => {
                const absIdx = (safePage - 1) * currentPageSize + i;
                const isSelected = selected.has(absIdx);
                const defaultBg = isSelected ? "#f8f9fa" : "#fff";
                return (
                  <tr
                    key={absIdx}
                    style={{ ...styles.row, background: defaultBg }}
                    onClick={() => {
                      const selection = window.getSelection()?.toString();

                      if (selection) return;

                      onRowClick?.(row);
                    }}
                    className={onRowClick ? "cursor-pointer" : "cursor-default"}
                    onMouseEnter={e => { if (!isSelected) e.currentTarget.style.background = "#fafafa"; }}
                    onMouseLeave={e => { e.currentTarget.style.background = defaultBg; }}
                  >
                    {showCheckbox && (
                      <td style={styles.td}>
                        <input
                          type="checkbox"
                          style={styles.checkbox}
                          checked={isSelected}
                          onChange={() => toggleRow(absIdx)}
                        />
                      </td>
                    )}
                    {columns.map((col) => (
                      <td key={col.key} style={styles.td}>
                        <TooltipCell>
                          {col.render
                            ? col.render(row[col.key], row)
                            : row[col.key] ?? "—"}
                        </TooltipCell>
                      </td>
                    ))}
                    {showMenu && (
                      <td style={styles.td}>
                        <button style={styles.menuBtn} title="More actions">
                          <svg width="16" height="16" viewBox="0 0 24 24" fill="#9ca3af">
                            <circle cx="12" cy="5" r="1.5" />
                            <circle cx="12" cy="12" r="1.5" />
                            <circle cx="12" cy="19" r="1.5" />
                          </svg>
                        </button>
                      </td>
                    )}
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Footer */}
      <div style={styles.footer}>
        <div style={styles.entriesWrap} ref={dropdownRef}>
          <span style={styles.footerText}>Entries</span>
          <div style={{ position: "relative" }}>
            <button style={styles.entriesBtn} onClick={() => setDropdownOpen((o) => !o)}>
              {currentPageSize}
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#6b7280" strokeWidth="2" strokeLinecap="round"
                style={{ marginLeft: 4, transform: dropdownOpen ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 0.2s" }}>
                <polyline points="6 9 12 15 18 9" />
              </svg>
            </button>
            {dropdownOpen && (
              <div style={styles.dropdown}>
                {pageSizeOptions.map((size) => (
                  <div
                    key={size}
                    style={{
                      ...styles.dropdownItem,
                      background: size === currentPageSize ? "#f3f4f6" : "#fff",
                      fontWeight: size === currentPageSize ? 600 : 400,
                    }}
                    onClick={() => handlePageSizeChange(size)}
                  >
                    {size}
                  </div>
                ))}
              </div>
            )}
          </div>
          <span style={styles.footerText}>of {entriesCount}</span>
        </div>

        <div style={styles.pagination}>
          <button
            style={{ ...styles.pageBtn, ...(safePage === 1 ? styles.pageBtnDisabled : {}) }}
            onClick={() => goToPage(Math.max(1, safePage - 1))}
            disabled={safePage === 1}
          >
            Previous
          </button>

          {Array.from({ length: displayTotalPages }, (_, i) => i + 1).map((n) => (
            <button
              key={n}
              style={{ ...styles.pageBtn, ...(n === safePage ? styles.pageBtnActive : {}) }}
              onClick={() => goToPage(n)}
            >
              {n}
            </button>
          ))}

          <button
            style={{ ...styles.pageBtn, ...(safePage === displayTotalPages ? styles.pageBtnDisabled : {}) }}
            onClick={() => goToPage(Math.min(displayTotalPages, safePage + 1))}
            disabled={safePage === displayTotalPages}
          >
            Next
          </button>
        </div>
      </div>
      <TooltipContainer id={"my-tooltip"} maxWidth="!max-w-80" />
    </div >
  );
}

const styles = {
  wrapper: {
    fontFamily: "'DM Sans', 'Segoe UI', sans-serif",
    background: "#fff",
    borderRadius: 12,
    boxShadow: "0 1px 4px rgba(0,0,0,0.08)",
    overflow: "hidden",
    border: "1px solid #e5e7eb",
  },
  emptyState: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    padding: "60px 20px",
    color: "#9ca3af",
  },
  emptyStateText: {
    fontSize: 15,
    color: "#9ca3af",
    margin: 0,
    fontWeight: 500,
  },
  searchWrap: {
    position: "relative",
    padding: "16px 20px",
    borderBottom: "1px solid #f3f4f6",
  },
  searchIcon: {
    position: "absolute",
    left: 34,
    top: "50%",
    transform: "translateY(-50%)",
    display: "flex",
    alignItems: "center",
  },
  searchInput: {
    width: "100%",
    maxWidth: 320,
    padding: "9px 12px 9px 36px",
    border: "1px solid #e5e7eb",
    borderRadius: 8,
    fontSize: 14,
    color: "#374151",
    outline: "none",
    background: "#f9fafb",
    boxSizing: "border-box",
  },
  tableWrap: { overflowX: "auto" },
  table: { width: "100%", borderCollapse: "collapse", fontSize: 14 },
  headerRow: {
    background: "#f9fafb",
    borderBottom: "1px solid #e5e7eb",
    position: "sticky",
    top: 0,
    zIndex: 1,
  },
  th: {
    padding: "11px 16px",
    textAlign: "left",
    fontWeight: 600,
    color: "#6b7280",
    fontSize: 13,
    whiteSpace: "nowrap",
  },
  row: { borderBottom: "1px solid #f3f4f6", transition: "background 0.15s" },
  td: { padding: "11px 16px", color: "#374151", verticalAlign: "middle" },
  checkbox: { width: 15, height: 15, cursor: "pointer", accentColor: "#22c55e" },
  menuBtn: {
    background: "none",
    border: "none",
    cursor: "pointer",
    padding: 4,
    borderRadius: 4,
    display: "flex",
    alignItems: "center",
  },
  empty: { textAlign: "center", padding: "40px 0", color: "#9ca3af" },
  footer: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "14px 20px",
    borderTop: "1px solid #f3f4f6",
    flexWrap: "wrap",
    gap: 8,
  },
  entriesWrap: {
    display: "flex",
    alignItems: "center",
    gap: 8,
    position: "relative",
  },
  footerText: { fontSize: 13, color: "#6b7280" },
  entriesBtn: {
    display: "flex",
    alignItems: "center",
    padding: "5px 10px",
    border: "1px solid #e5e7eb",
    borderRadius: 6,
    background: "#fff",
    color: "#374151",
    fontSize: 13,
    cursor: "pointer",
    fontWeight: 500,
    gap: 2,
  },
  dropdown: {
    position: "absolute",
    bottom: "110%",
    left: 0,
    background: "#fff",
    border: "1px solid #e5e7eb",
    borderRadius: 8,
    boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
    minWidth: 80,
    zIndex: 100,
    overflow: "hidden",
  },
  dropdownItem: {
    padding: "9px 16px",
    fontSize: 13,
    color: "#374151",
    cursor: "pointer",
    transition: "background 0.12s",
  },
  pagination: { display: "flex", gap: 4, alignItems: "center" },
  pageBtn: {
    padding: "6px 12px",
    border: "1px solid #e5e7eb",
    borderRadius: 6,
    background: "#fff",
    color: "#374151",
    fontSize: 13,
    cursor: "pointer",
    fontWeight: 500,
  },
  pageBtnActive: {
    background: "#22c55e",
    color: "#fff",
    border: "1px solid #22c55e",
  },
  pageBtnDisabled: { color: "#d1d5db", cursor: "not-allowed" },
};