import React from "react";
import SectionCard from "../../pages/buildings/SectionCard"


function EmployeesSection({ members }) {
    const employeesIcon = (
        <svg
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            className="text-gray-600"
        >
            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
            <circle cx="9" cy="7" r="4" />
            <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
            <path d="M16 3.13a4 4 0 0 1 0 7.75" />
        </svg>
    );

    return (
        <SectionCard icon={employeesIcon} title="Employees in this room">
            {members && members.length > 0 ? (
                <div className="overflow-x-auto">
                    <table className="w-full">
                        <thead>
                            <tr className="border-b border-gray-200 bg-gray-50">
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">
                                    Name
                                </th>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">
                                    Employee ID
                                </th>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">
                                    Stay
                                </th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {members.map((member) => (
                                <tr key={member.id} className="hover:bg-gray-50 transition">
                                    <td className="px-4 py-4">
                                        <p className="text-sm font-semibold text-gray-900">
                                            {member.name}
                                        </p>
                                    </td>
                                    <td className="px-4 py-4">
                                        <p className="text-sm text-gray-600">
                                            {member.employee_id}
                                        </p>
                                    </td>
                                    <td className="px-4 py-4">
                                        <div className="flex flex-col gap-1">
                                            <p className="text-sm text-gray-600">
                                                {member.phone}
                                            </p>
                                            <p className="text-xs text-gray-500">
                                                {member.start_date}
                                            </p>
                                           
                                            <span
                                                className={`inline-block w-fit text-xs font-medium px-2 py-1 rounded-full ${
                                                    member.status === "active"
                                                        ? "bg-green-100 text-green-700"
                                                        : "bg-red-100 text-red-600"
                                                }`}
                                            >
                                                {member.status === "active"
                                                    ? "Active"
                                                    : "Inactive"}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            ) : (
                <p className="text-sm text-gray-400">No employees assigned yet</p>
            )}
        </SectionCard>
    );
}

export default EmployeesSection;