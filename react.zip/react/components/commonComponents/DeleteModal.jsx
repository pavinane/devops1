import React from "react";
// import icons3d from "../../assets/icons/icons3d";
import icons3d from "../../assets/icons/3dicon/Help.png";
const DeleteModal = ({
    onCancel,
    onConfirm,
    onCancelText = "Cancel",
    onConfirmText = "Delete",
    text = "Are you sure you want to remove this company details ?",
    disabled = false,
    showDeleteIcon = false,
    showButtons = false
}) => {
    return (
        <div className="flex flex-col items-center  gap-2 pt-2 w-full">
            {
                showDeleteIcon &&
                <div className="w-[120px]">
                    <img
                        src={icons3d}
                        className="w-full h-full"
                    />
                </div>
            }

            <p className=" font-poppins-normal text-center xs:text-[18px] desk-lg:text-xl">{text}</p>
            {
                showButtons &&
                <div className="flex gap-3 w-full font-poppins-medium xs:text-[14px] desk-lg:text-[16px] justify-between">
                    <button
                        onClick={onCancel}
                        className="border  bg-none w-[200px] hover:bg-[#cbf5cb]  hover:text-black transition-colors duration-500   py-[12px] text-red   rounded-[40px]  cursor-pointer"
                    >
                        {onCancelText}
                    </button>
                    <button
                        onClick={onConfirm}
                        disabled={disabled}
                        className={`border text-white    w-[200px]  hover:bg-[#077c07]    transition-colors duration-500 py-[12px] bg-[#099309] rounded-[40px] ${disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}`}
                    >
                        {onConfirmText}
                    </button>
                </div>
            }
        </div>
    );
    // text-black hover:text-gray-500 text-xl bg-[#EAEAEA]
};

export default DeleteModal;

