import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { setActiveMenuSlice } from "../../redux/slice/sideMenuSlice";
import { useMediaQueryValues } from "./MediaQueryContext";

import {
  DashboardIcon,
  BuildingsIcon,
  FoodReportIcon,
  AccommodationIcon,
  UserManagementIcon,
  MealSettingsIcon,
  ReportsIcon,
  SupportTicketIcon,
  HelpCenterIcon,
} from "../SidebarIcon";



const Sidebar = () => {
  const { isMobile } = useMediaQueryValues();
  const [activeMenu, setActiveMenu] = useState("Dashboard");
  const [expandedItems, setExpandedItems] = useState({});
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const path = location.pathname;


  const NAV_SECTIONS = [
    {
      section: null,
      items: [
        {
          label: "Dashboard", navigate: "/dashboard",
          icon: <DashboardIcon />,
        },
        {
          label: "Buildings", navigate: "/building",
          icon: <BuildingsIcon />,
        },
        {
          label: "Food Report", navigate: "/food-report",
          icon: <FoodReportIcon />,
        },
        {
          label: "Accommodation",
          navigate: !isMobile ? "/service-request" : "/accommodation",
          icon: <AccommodationIcon />,
          ...(isMobile
            ? {}
            : {
              hasChildren: true,
              children: [
                {
                  label: "Order & Requests",
                  navigate: "/service-request",
                },
                {
                  label: "Service Categories",
                  navigate: "/service-categories",
                },
              ],
            }),
        },

        {
          label: "Meal Settings", navigate: "/meal-setting",
          icon: <MealSettingsIcon />,
        },
        {
          label: "Meal Selection", navigate: "/meal-selection",
          icon: <MealSettingsIcon />,
        },
        {
          label: "Room Group", navigate: "/room-group",
          icon: <UserManagementIcon />,
        },
        {
          label: "User Management", navigate: "/user-management",
          icon: <UserManagementIcon />,
        },
      ],
    },
  ];



  const { roles } = useSelector((state) => state.user);

  const filteredNavSections = NAV_SECTIONS.map((section) => ({
    ...section,
    items: section.items.filter((item) => {
      const restrictedMenus = ["Meal Selection", "Room Group"];

      if (roles === "office_admin") {

        return !restrictedMenus.includes(item.label);
      }

      return restrictedMenus.includes(item.label);
    }),
  }));


  useEffect(() => {
    filteredNavSections.forEach(({ items }) =>
      items.forEach((item) => {
        if (location.pathname.startsWith(item.navigate)) setActiveMenu(item.label);
        item.children?.forEach((child) => {
          if (location.pathname.startsWith(child.navigate)) setActiveMenu(item.label);
        });
      })
    );
  }, [location.pathname]);



  const handleClick = (item) => {
    if (item.disabled) return;
    if (item.hasChildren) {
      if (isMobile) {
        navigate(item.navigate);
        return;
      }

      setExpandedItems((prev) => {
        const newState = {};

        newState[item.label] = !prev[item.label];
        return newState;
      });
      return;
    }
    setActiveMenu(item.label);
    setExpandedItems({});
    dispatch(setActiveMenuSlice({ sideMenuActiveText: item.navigate?.replace("/", "") }));
    navigate(item.navigate);
  };

  const handleChildClick = (parent, child) => {
    setActiveMenu(parent.label);
    setExpandedItems({ [parent.label]: true }); // Keep only parent expanded
    dispatch(setActiveMenuSlice({ sideMenuActiveText: child.navigate?.replace("/", "") }));
    navigate(child.navigate);
  };

  const allItems = filteredNavSections.flatMap((s) => s.items);

  useEffect(() => {
    if (location.pathname === "/profile") {
      setActiveMenu("");
      return;
    }

    filteredNavSections.forEach(({ items }) =>
      items.forEach((item) => {
        if (location.pathname.startsWith(item.navigate)) {
          setActiveMenu(item.label);
        }

        item.children?.forEach((child) => {
          if (location.pathname.startsWith(child.navigate)) {
            setActiveMenu(item.label);
          }
        });
      })
    );
  }, [location.pathname]);


  const onhandleNavigate = () => {
    if (roles == "member") {
      navigate("/meal-selection")
    } else {
      navigate("/dashboard")
    }
  }


  if (isMobile) {
    return (
      <div className="fixed bottom-0 left-0 right-0 h-16 bg-white border-t border-gray-200 flex items-center justify-around px-2 z-50">
        {allItems.slice(0, 5).map((item) => (
          <button
            key={item.label}
            onClick={() => handleClick(item)}
            className={`flex flex-col items-center gap-0.5 px-2 py-1 rounded-lg transition-colors ${activeMenu === item.label ? "text-green-600" : "text-gray-400"
              }`}
          >
            {item.icon}
            <span className="text-[10px] font-medium">{item.label.split(" ")[0]}</span>
          </button>
        ))}
      </div>
    );
  }



  return (
    <aside className="hidden md:flex flex-col md:w-[220px] lg:w-[230px] min-h-screen bg-white border-r border-gray-100 overflow-y-auto scrollbar-hide">
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-5 py-5 border-b border-gray-100 cursor-pointer"
        onClick={onhandleNavigate}
      >
        <div className="w-7 h-7 bg-green-500 rounded-md flex items-center justify-center flex-shrink-0">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
          </svg>
        </div>
        <span className="text-[17px] font-bold text-gray-900 tracking-tight">CloudGate</span>
      </div>

      <nav className="flex-1 py-4 px-3 space-y-4">
        {filteredNavSections.map(({ section, sectionBadge, items }, si) => (
          <div key={si}>
            {section && (
              <div className="flex items-center gap-2 px-2 mb-1.5">
                <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-widest">{section}</span>
                {sectionBadge && (
                  <span className="text-[10px] font-semibold bg-orange-100 text-orange-500 px-1.5 py-0.5 rounded-full leading-none">
                    {sectionBadge}
                  </span>
                )}
              </div>
            )}
            <div className="space-y-4">
              {items.map((item) => {
                const isActive = activeMenu === item.label;
                const isExpanded = expandedItems[item.label];
                return (
                  <div key={item.label}>
                    <button
                      onClick={() => handleClick(item)}
                      disabled={item.disabled}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 group
                        ${isActive ? "bg-green-50 text-green-700" : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"}
                        ${item.disabled ? "opacity-40 cursor-not-allowed" : "cursor-pointer"}`}
                    >
                      <span className={`flex-shrink-0 transition-colors ${isActive ? "text-green-600" : "text-gray-400 group-hover:text-gray-600"}`}>
                        {item.icon}
                      </span>
                      <span className="flex-1 text-left">{item.label}</span>
                      {item.badge && (
                        <span className="text-[10px] font-semibold bg-green-100 text-green-700 px-1.5 py-0.5 rounded-full leading-none">
                          {item.badge}
                        </span>
                      )}
                      {item.hasChildren && (
                        <svg
                          width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
                          className={`text-gray-400 transition-transform duration-200 ${isExpanded ? "rotate-180" : ""}`}
                        >
                          <path d="M19 9l-7 7-7-7" />
                        </svg>
                      )}
                    </button>

                    {item.hasChildren && isExpanded && (
                      <div className="ml-9 mt-0.5 space-y-0.5">
                        {item.children?.map((child) => (
                          <button
                            key={child.label}
                            onClick={() => handleChildClick(item, child)}
                            className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors cursor-pointer
                              ${location.pathname.startsWith(child.navigate)
                                ? "text-green-700 font-medium bg-green-50"
                                : "text-gray-500 hover:text-gray-800 hover:bg-gray-50"
                              }`}
                          >
                            {child.label}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </nav>
    </aside>
  );
};

export default Sidebar;