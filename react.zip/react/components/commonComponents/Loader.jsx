import React from 'react';
import "../../loader.css";

function Loader() {
    return (
        <section className="w-full min-h-screen flex items-center justify-center">
            <div className="flex flex-col items-center gap-2">
                <div className="loader"></div>
            </div>
        </section>
    )
}

export default Loader;