import React from 'react';
import Modal from './Modal';
import Success from '../../assets/icons/3dicon/Success.png'

const SuccessModal = ({ isOpen, title, handleCloseModal, message }) => {
    return (
        <Modal
            isOpen={isOpen}
            // title={title }
            onClose={handleCloseModal}
            size="medium"
            width="w-76"

            showCloseButton={true}
            height="h-4xl"

        >
            <div className="flex items-center flex-col gap-6">

                <div className="w-20 ">
                    <img src={Success} alt="" srcset="" />
                </div>
                <div className='flex flex-col text-center items-center'>
                    <h1>{title}</h1>
                    {
                        message && <p className='text-text-grey1 '>{message}</p>
                    }
                </div>
            </div>

        </Modal>
    )

}

export default SuccessModal