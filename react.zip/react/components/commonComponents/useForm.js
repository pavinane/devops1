import { useState } from "react";
import { validateFields } from "../../validation/validateField";

const useForm = (initialValues, schemaDefinition, onSubmitCallback) => {
    const [errors, setErrors] = useState({});
    const [formData, setFormData] = useState(initialValues);

    const updateFieldData = async (fieldValue, fieldName) => {
        setFormData((prev) => ({ ...prev, [fieldName]: fieldValue }));
        await handleValidation(fieldValue, fieldName);
    };

    const handleValidation = async (fieldValue, fieldName) => {
        const updatedFormData = { ...formData, [fieldName]: fieldValue };

        const { errorData } = await validateFields(
            updatedFormData,
            { [fieldName]: fieldValue },
            { [fieldName]: schemaDefinition[fieldName] },
        );

        const fieldError = errorData?.find((err) => err.path === fieldName);
        const requiredError = errorData?.find(
            (err) => err.path === fieldName && err.type === "required",
        );

        if (
            "confirmPassword" === fieldName &&
            fieldValue === formData.password
        ) {
            setErrors((prev) => ({
                ...prev,
                confirmPassword: "",
            }));
        } else if (
            "confirmPass" === fieldName &&
            fieldValue === updatedFormData.newPass
        ) {
            setErrors((prev) => ({
                ...prev,
                confirmPass: "",
            }));
        } else {
            setErrors((prev) => ({
                ...prev,
                [fieldName]: requiredError
                    ? requiredError.message
                    : fieldError?.message || "",
            }));
        }
    };

    const handleSubmit = async (event, extraData) => {
        if (event) event?.preventDefault();

        const { isValid, errorData } = await validateFields(
            formData,
            formData,
            schemaDefinition,
        );

        if (isValid) {
            onSubmitCallback(formData, extraData);
        } else {
            const updatedErrors = errorData?.reduce((acc, error) => {
                if (!acc[error.path] || error.type === "required") {
                    acc[error.path] = error.message;
                }
                return acc;
            }, {});

            setErrors(updatedErrors);
        }
    };

    const handleReset = () => {
        setFormData(initialValues);
        setErrors({});
    };

    return {
        formData,
        errors,
        updateFieldData,
        handleValidation,
        handleSubmit,
        handleReset,
        setFormData,
        setErrors,
    };
};

export default useForm;
