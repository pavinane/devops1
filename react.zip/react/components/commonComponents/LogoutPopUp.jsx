import React from 'react'
import logoOut from '../../assets/icons/3dicon/Logout.png'

const LogoutPopUp = ({
    text = "Are You Sure You Want to Logout?",
    onConfirm,
    onCancel,
    onConfirmText = "Logout",
    onCancelText = "Go, Back",
    showDeleteIcon = true,
    showButtons = true,
    isPending = false
}) => {
    return (
        <div className="flex flex-col items-center gap-[15px]  w-full">
            {showDeleteIcon && (
                <img src={logoOut} alt="Logout" className="w-20 h-18" />
            )}

            <p className="w-full max-w-[350px] h-[64px] font-inter font-medium text-[20px] leading-[32px] text-center text-gray-800">
                {text}
            </p>

            {showButtons && (
                <div className="flex gap-2 sm:gap-4 w-full justify-center flex-wrap">
                    <button
                        onClick={onCancel}
                        className={`flex-1 min-w-[120px] sm:w-[180px] h-[48px] px-2 sm:px-5 py-3 border border-gray-800 text-gray-800  rounded-full font-medium text-xs sm:text-sm hover:bg-green-600 hover:text-white hover:border-[#FED75D80] transition cursor-pointer ${isPending ? "opacity-50 cursor-not-allowed" : ""}`}
                    >
                        {onCancelText}
                    </button>
                    <button
                        onClick={onConfirm}
                        disabled={isPending}
                        className={`flex-1 min-w-[120px] sm:w-[180px] h-[48px] px-2 sm:px-5 py-3 border border-red-500 text-red-500 rounded-full font-medium text-xs sm:text-sm hover:bg-red-600 hover:text-white hover:border-[#FF0000] transition cursor-pointer ${isPending ? "opacity-50 cursor-not-allowed" : ""}`}
                    >
                        {onConfirmText}
                    </button>
                </div>
            )}
        </div>
    )
}

export default LogoutPopUp
