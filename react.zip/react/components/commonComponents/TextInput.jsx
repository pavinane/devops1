import React, { useRef, useState } from "react";

function TextInput({
    label,
    placeholder,
    name,
    value = "",
    onChange,
    type = "text",
    required = false,
    error,
    icon = null,
    onIconClick,
    disabled = false,
    disabled_profile = false,
    readOnly = false,
    maxLength,
    toUppercase = false,
    toLowercase = false,
    fileUpload = false,
    onFileSelect,
    showErrors = true,
    width = "w-full",
    border = "rounded-lg",
    isIconOnly = false,
    pointer = false,
    regexValidation = null,
    autoComplete = "off",
}) {
    const fileInputRef = useRef(null);


    const handleChange = (e) => {
        let val = e.target.value;

        if (regexValidation && val !== "" && !regexValidation.test(val)) return;

        // PHONE NUMBER RESTRICTION
        if (name === "phone_number") {
            // allow only digits and +
            if (!/^\+?\d*$/.test(val)) return;

            // only one + and only at start
            if ((val.match(/\+/g) || []).length > 1) return;
            if (val.includes("+") && !val.startsWith("+")) return;
        }

        if (toUppercase) val = val.toUpperCase();
        if (toLowercase) val = val.toLowerCase();
        if (maxLength) val = val.slice(0, maxLength);

        onChange?.(val, e.target.name);
    };

    const handleKeyDown = (e) => {
        if (type === "number") {
            if (["e", "E", "+", "-", ".", "ArrowUp", "ArrowDown"].includes(e.key)) {
                e.preventDefault();
            }
        }
    };

    const handleFileChange = (e) => {
        const files = Array.from(e.target.files || []);
        files.forEach((file) => onFileSelect?.(file));
        e.target.value = "";
    };

    const triggerFileUpload = () => {
        fileInputRef.current?.click();
        onIconClick?.();
    };

    //External Particpants Chipset
    const [chipInput, setChipInput] = useState("");
    const handleChipKeyDown = (e) => {
        if (name !== "external_participants") return;

        if (e.key === "Enter" && chipInput.trim()) {
            e.preventDefault();

            const newChip = chipInput.trim();
            const current =
                typeof value === "string"
                    ? value.split(",").map((v) => v.trim()).filter(Boolean)
                    : [];

            if (!current.includes(newChip)) {
                const updated = [...current, newChip];
                onChange?.(updated.join(", "), name);
            }
            setChipInput("");
        }
    };
    const handleChipBlur = () => {
        if (name !== "external_participants") return;

        if (!chipInput.trim()) return;

        const current =
            typeof value === "string"
                ? value.split(",").map((v) => v.trim()).filter(Boolean)
                : [];

        const updated = [...new Set([...current, chipInput.trim()])];

        onChange?.(updated.join(", "), name);
        setChipInput("");
    };
    const removeChip = (chip) => {
        if (name !== "external_participants") return;
        const current =
            typeof value === "string"
                ? value.split(",").map((v) => v.trim()).filter(Boolean)
                : [];
        const updated = current.filter((item) => item !== chip);
        onChange?.(updated.join(", "), name);
    };

    const chips =
        name === "external_participants"
            ? typeof value === "string"
                ? value.split(",").map((v) => v.trim()).filter(Boolean)
                : Array.isArray(value)
                    ? value
                    : []
            : [];

    return (
        <div className={`mb-4 font-medium ${width}`}>
            {/* Label */}
            {label && (
                <label
                    htmlFor={name}
                    className={`block mb-2 font-medium whitespace-nowrap text-text-black1 text-[16px]
            }`}
                >
                    {label}
                    {required && <span className="text-red-500"> *</span>}
                </label>
            )}

            {/* Input Wrapper */}
            <div
                className={`relative flex items-center ${isIconOnly ? "px-3 py-3" : ""
                    }  ${error ? "border-red-500" : "border-gray-300"} ${border} border border-gray-300 
          ${disabled_profile && "text-text-black1 bgColor-white"}
          ${disabled || readOnly
                        ? "bg-input-bgColor  text-text-black1"
                        : "bg-white text-black"
                    }
          `
                }
            >

                {/* External Participants Chipset */}
                {name === "external_participants" ? (
                    <div className="flex flex-wrap items-center gap-1 w-full py-1 ml-2">
                        {chips.map((chip, i) => (
                            <div
                                key={i}
                                className="bg-black text-white px-2 py-1 rounded-2xl flex items-center gap-1 text-[16px]"              >
                                <span>{chip}</span>
                                <span
                                    className="cursor-pointer"
                                    onClick={() => removeChip(chip)}
                                >
                                    ✕
                                </span>
                            </div>
                        ))}

                        <input
                            type="text"
                            value={chipInput}
                            maxlength={40}
                            placeholder={chips.length === 0 ? placeholder : ""}
                            onChange={(e) => setChipInput(e.target.value)}
                            onKeyDown={handleChipKeyDown}
                            onBlur={handleChipBlur}
                            className="flex-1 outline-none text-sm p-2 min-w-[120px] ml-2 wrap-break-word"
                        />
                    </div>
                ) : (
                    <input
                        id={name}
                        name={name}
                        type={type}
                        placeholder={placeholder}
                        value={fileUpload ? "" : value}
                        onChange={handleChange}
                        onKeyDown={handleKeyDown}
                        disabled={disabled || disabled_profile}
                        readOnly={readOnly}
                        autoComplete={autoComplete}
                        className="w-full p-3 border-0 outline-none focus:ring-0 sm:text-sm text-base placeholder-gray-400"
                    />
                )}

                {/* Icon */}
                {icon && (
                    onIconClick || fileUpload ? (
                        <button
                            type="button"
                            onClick={fileUpload ? triggerFileUpload : onIconClick}
                            disabled={disabled}
                            className="mr-2 flex items-center justify-center"
                        >
                            <img src={icon} alt="icon" className={`w-5 h-5 ${pointer && "cursor-pointer"}`} />
                        </button>
                    ) : (
                        <div className="mr-2 flex items-center justify-center pointer-events-none">
                            <img src={icon} alt="icon" className="w-5 h-5" />
                        </div>
                    )
                )}
            </div>

            {/* Hidden File Input */}
            {fileUpload && (
                <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    className="hidden"
                    onChange={handleFileChange}
                />
            )}

            {/* Error */}
            {showErrors && <p className="text-xs text-red-500 mt-1 leading-tight h-5 md:h-5 md:min-h-5 min-h-fit">{error}</p>}
        </div>
    );
}

export default TextInput;
