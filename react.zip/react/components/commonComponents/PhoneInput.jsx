import React from "react";

const PhoneInput = ({
    label = "Mobile number",
    name = "mobile",
    countryCode,
    onCountryChange,
    onNumberChange,
    onChange, // generic handler like TextInput
    value,
    placeholder = "Enter mobile number",
    required = false,
    disabled = false,
    error,
    readOnly,
    classname,
    maxLength = 10
}) => {
    const handleNumberChange = (e) => {
        // ✅ allow only numbers
        const newVal = e.target.value.replace(/[^0-9]/g, "").slice(0, maxLength);
        if (onNumberChange) {
            onNumberChange(newVal);
        }
        if (onChange) {
            onChange(newVal, name);
        }


    };


    return (
        <div className={`w-full mb-4 font-regular ${classname}`}>
            {/* Label */}
            {label && (
                <label className="block text-[16px] font-medium mb-2">
                    {label} {required && <span className="text-red-500">*</span>}
                </label>
            )}

            <div className="flex flex-row gap-3">
                {/* Country Code */}
                <div className="flex">
                    <select
                        value={countryCode}
                        onChange={(e) =>
                            onCountryChange && onCountryChange(e.target.value)
                        }
                        disabled={disabled}
                        className={`px-3 py-2 sm:py-3 border border-gray-300 rounded-lg ${disabled || readOnly
                            ? "bg-input-bgColor  text-text-black1"
                            : "bg-white text-black"
                            }  placeholder-gray-400 sm:text-sm text-base focus:outline-none w-20 `}
                    >
                        <option value="+91">+91</option>
                        <option value="+1">+971</option>
                    </select>
                </div>

                {/* Phone number input */}
                <div className="w-full">
                    <input
                        type="tel"
                        name={name}
                        value={value}
                        onChange={handleNumberChange}
                        placeholder={placeholder}
                        disabled={disabled}
                        className={`flex-1 px-3 py-2 sm:text-sm text-base placeholder-gray-400 sm:py-3 border border-gray-300 rounded-lg focus:outline-none  w-full  ${disabled || readOnly
                            ? "bg-input-bgColor  text-text-black1"
                            : "bg-white text-black"
                            }`}
                    />
                </div>
            </div>

            {/* Error message */}
            <p className="text-xs text-red-500 min-h-4 mt-1">{error}</p>
        </div>
    );
};

export default PhoneInput;
