import React, { useEffect, useRef, useCallback, useState } from "react";
import "react-datepicker/dist/react-datepicker.css";
import "../../css/datepicker.css";
import DatePicker from "react-datepicker";
import { format } from "date-fns";
import calen from "../../assets/icons/calendar.svg";
import nextButton from "../../assets/icons/next.svg";
import previousButton from "../../assets/icons/previous.svg";

const CustomDate = ({
  value,
  onChange,
  width = "w-full",
  placeholder = "Select date",
  calendarKey,
  label,
  required = false,
  name,
  errors,
  minDate,
  maxDate,
  openCalendar,
  setOpenCalendar,
  disabled = false,
  className = "",
  singleClickSelect = false,
}) => {
  const modalRef = useRef(null);

  const uniqueKey = calendarKey || label;

  const [activeTab, setActiveTab] = useState("DATE");
  const [selectedDate, setSelectedDate] = useState(null);
  const [tempYear, setTempYear] = useState(new Date().getFullYear());
  const [hasUserSelectedDate, setHasUserSelectedDate] = useState(false);

  const isValidDate = (date) => date instanceof Date && !isNaN(date);

  const formatDate = (date) =>
    isValidDate(date) ? format(date, "dd MMM yyyy") : "";

  const handleInputClick = () => {
    if (!disabled) {
      // setOpenCalendar((prev) => (prev === label ? null : label));
       setOpenCalendar((prev) => (prev === uniqueKey ? null : uniqueKey));
    }
  };

  const handleDateChange = (date) => {
    if (disabled) return;

    if (singleClickSelect) {
      setSelectedDate(date);
      setHasUserSelectedDate(true);
      onChange(date, name);
      setOpenCalendar(null);
      return;
    }

    if (activeTab === "MONTH") {
      const newDate = new Date(tempYear, date.getMonth(), 1);
      setSelectedDate(newDate);
      setActiveTab("DATE");
    } else if (activeTab === "DATE") {
      setSelectedDate(date);
      setHasUserSelectedDate(true);
      onChange(date, name);
      setOpenCalendar(null);
    }
  };

  const handleOutsideClick = useCallback(
    (e) => {
      if (modalRef.current && !modalRef.current.contains(e.target)) {
        setOpenCalendar(null);
      }
    },
    [setOpenCalendar]
  );

  useEffect(() => {
    if (openCalendar === uniqueKey) {
      document.addEventListener("mousedown", handleOutsideClick);
    }
    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
    };
  }, [openCalendar, uniqueKey, handleOutsideClick]);

  useEffect(() => {
    if (value) {
      const dateObj = value instanceof Date ? value : new Date(value);
      if (isValidDate(dateObj)) {
        setSelectedDate(dateObj);
        setTempYear(dateObj.getFullYear());
        setHasUserSelectedDate(true);
        setActiveTab("DATE");
      } else {
        setSelectedDate(null);
        setActiveTab("DATE");
      }
    } else {
      setSelectedDate(null);
      setActiveTab("DATE");
    }
  }, [value]);

  return (
    <div className="flex flex-col">
      {label && (
        <label
          className={`block mb-2 font-medium text-text-black1 text-[16px] ${
            disabled ? "" : ""
          }`}
        >
          {label}
          {required && <span className="text-red-500">*</span>}
        </label>
      )}

      <div
        className={`cursor-pointer ${className}`}
        onClick={handleInputClick}
      >
        <div
          className={`flex items-center gap-2 justify-between px-2.5 md:px-3 py-3 rounded-xl border text-sm
            ${errors ? "border-red-500" : "border-gray-300"}
            ${
              disabled
                ? "bg-input-bgColor text-text-black1 cursor-text"
                : selectedDate
                ? "bg-white text-black"
                : "bg-white text-gray-400"
            }
            ${width}
          `}
        >
          <span className="text-nowrap">
            {selectedDate ? formatDate(selectedDate) : placeholder}
          </span>
          <img src={calen} alt="calendar" className="w-5 h-5" />
        </div>
      </div>

      {openCalendar === uniqueKey && !disabled && (
       
          <>
            <div className="fixed inset-0 bg-black/40 z-90" />
            <div
              ref={modalRef}
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-100"
            >
              <DatePicker
                selected={hasUserSelectedDate ? selectedDate : null}
                onChange={handleDateChange}
                minDate={minDate}
                maxDate={maxDate}
                inline
                formatWeekDay={(day) => day.charAt(0)}
                calendarClassName="custom-datepicker"
                renderCustomHeader={({ date, decreaseMonth, increaseMonth }) => {
                  const months = [
                    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
                  ];
                  return (
                    <div className="flex justify-between items-center gap-50">
                      <span className="text-[18px] pl-4 font-medium text-gray-800">
                        {months[date.getMonth()]} {date.getFullYear()}
                      </span>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={decreaseMonth}
                          className="w-6 h-6 flex items-center justify-center rounded-full
                                   bg-transparent hover:bg-[#fdf4d8]
                                   border-none cursor-pointer transition-colors"
                        >
                          <img src={previousButton} alt="previous" width={9} height={15} />
                        </button>
                        <button
                          onClick={increaseMonth}
                          className="w-6 h-6 flex items-center justify-center rounded-full
                                   bg-transparent hover:bg-[#fdf4d8]
                                   border-none cursor-pointer transition-colors"
                        >
                          <img src={nextButton} alt="next" width={9} height={15} />
                        </button>
                      </div>
                    </div>
                  );
                }}
              />
            </div>
          </>
        
      )}

      {errors && (
        <p className="text-xs text-red-500 font-medium min-h-4 mt-1">
          {errors}
        </p>
      )}
    </div>
  );
};

export default CustomDate;