import React from "react";

const Toggle = ({
    label,
    checked = false,
    onChange,
    disabled = false,
    name,
    error,
    required = false,
    size = "md",
    labelPosition = "side",
}) => {
    const sizes = {
        sm: "w-9 h-5 after:h-4 after:w-4 after:top-[2px] after:left-[2px]",
        md: "w-11 h-6 after:h-5 after:w-5 after:top-[2px] after:left-[2px]",
        lg: "w-14 h-7 after:h-6 after:w-6 after:top-[2px] after:left-[4px]",
    };

    return (

        <div className="flex flex-col gap-1 w-full">
            <label
                className={`flex ${labelPosition === "top"
                    ? "flex-col items-start gap-2"
                    : "items-center justify-between"
                    }`}
            >
                {label && (
                    <span className="text-text-black1 text-[16px]">
                        {label}
                        {required && (
                            <span className="text-red-500 ml-1">*</span>
                        )}
                    </span>
                )}

                {/* Hidden Checkbox */}
                <input
                    type="checkbox"
                    className="sr-only peer"
                    checked={checked}
                    disabled={disabled}
                    name={name}
                    onChange={(e) =>
                        onChange({
                            target: {
                                name,
                                checked: e.target.checked,
                            },
                        })
                    }
                />

                {/* Toggle UI */}
                <div
                    className={` ml-3 mt-3 ${disabled ? "opacity-50 cursor-pointer" : " cursor-pointer"}
                        relative peer
                        bg-gray-300
                        rounded-full
                        transition-all
                        duration-300
                        peer-checked:bg-[var(--fc-btn-bg)]
                        
                        after:content-['']
                        after:absolute
                        after:bg-white
                        after:rounded-full
                        after:transition-all
                        after:duration-300
                        peer-checked:after:translate-x-full
                        ${sizes[size]}
                    `}
                />
            </label>

            {error && <span className="text-red-500 text-xs">{error}</span>}
        </div>
    );
};

export default Toggle;
