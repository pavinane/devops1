import React, { lazy, Suspense } from "react";
import { Route, Routes, Navigate } from "react-router-dom";
import { useSelector } from "react-redux";
import LoginLayout from "../layouts/LoginLayout";
import DashboardLayout from "../layouts/DashboardLayout";
import LoginPage from "../pages/Login/LoginPage";
import PrivateRoute from "../PrivateRoute";
import ForgetPassword from "../pages/Login/ForgetPassword";
import NotFound from "./NotFound";
import MealSettings from "../pages/MealSetting/MealSetting";
import FoodReport from "../pages/food-report/FoodReport";
import Buildings from "../pages/buildings/Buildings";
import Users from "../pages/UserManagement/Users";
import DashBoardPages from "../pages/DashBoardPage/DashBoardPages";
import ServiceRequest from "../pages/Accommodation/ServiceRequest";
import ServiceCategories from "../pages/Accommodation/ServiceCategories";
import AccommodationMenu from "../pages/Accommodation/AccommodationMenu";
import Profile from "../pages/profile/Profile";
import RoomDetail from "../pages/buildings/RoomDetail";
import Setpassword from "../pages/Login/SetPassword";

const MealSelection = lazy(() => import("../pages/MealSelection/MealSection"));
const RoomGroup = lazy(() => import("../pages/RoomGroup/RoomGroup"));
const BuildingDetail = lazy(() => import("../pages/buildings/BuildingDetail"));

// Redirect users to their role's home page
const RoleHome = () => {
  const roles = useSelector((state) => state.user.roles);
  const normalizedRole = Array.isArray(roles) ? roles[0] : roles?.trim();

  if (normalizedRole === "office_admin") return <Navigate to="/dashboard" replace />;
  if (normalizedRole === "member") return <Navigate to="/meal-selection" replace />;
  if (normalizedRole === "room_incharge") return <Navigate to="/profile" replace />;
  return <Navigate to="/" replace />;
};


const Unauthorized = () => (
  <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: "100vh", gap: 12 }}>
    <h2>403 – Unauthorized</h2>
    <p>You don't have permission to view this page.</p>
    <a href="/">Go back</a>
  </div>
);

const MainRouter = () => {
  return (
    <Suspense fallback={<div className="flex items-center justify-center min-h-screen">Loading...</div>}>
      <Routes>


        <Route element={<LoginLayout />}>
          <Route path="/" element={<LoginPage />} />
          <Route path="/forgetpassword" element={<ForgetPassword />} />
          <Route path="/setpassword" element={<Setpassword />} />
        </Route>


        {/* <Route path="/unauthorized" element={<NotFound />} /> */}

        <Route element={<DashboardLayout />}>

          <Route
            element={
              <PrivateRoute allowedRoles={["office_admin", "member", "room_incharge"]} />
            }
          >
            <Route path="/home" element={<RoleHome />} />
          </Route>

          <Route
            element={
              <PrivateRoute allowedRoles={["office_admin", "member", "room_incharge"]} />
            }
          >
            <Route path="/profile" element={<Profile />} />
          </Route>


          <Route element={<PrivateRoute allowedRoles={["office_admin"]} />}>
            <Route path="/dashboard" element={<DashBoardPages />} />
            <Route path="/meal-setting" element={<MealSettings />} />
            <Route path="/food-report" element={<FoodReport />} />
            <Route path="/building" element={<Buildings />} />
            <Route path="/building/:id" element={<BuildingDetail />} />
            <Route path="/building/:buildingId/rooms/:roomId" element={<RoomDetail />} />
            <Route path="/user-management" element={<Users />} />
            <Route path="/accommodation" element={<AccommodationMenu />} />
            <Route path="/service-request" element={<ServiceRequest />} />
            <Route path="/service-categories" element={<ServiceCategories />} />
          </Route>


          <Route element={<PrivateRoute allowedRoles={["member"]} />}>
            <Route path="/meal-selection" element={<MealSelection />} />
            <Route path="/room-group" element={<RoomGroup />} />
          </Route>

        </Route>

        <Route path="*" element={<NotFound />} />

      </Routes>
    </Suspense>
  );
};

export default MainRouter;