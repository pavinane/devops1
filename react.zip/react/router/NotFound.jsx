import { Link, Navigate } from "react-router-dom";

import logo from "../assets/images/error.webp"
import { useSelector } from "react-redux";
const NotFound = () => {
    const { isAuthenticated, roles } = useSelector((state) => state.user);

    const userRole = Array.isArray(roles) ? roles[0] : roles?.trim();
    const roleHomeMap = {
        office_admin: "/dashboard",
        member: "/meal-selection",
        room_incharge: "/profile",
    };
    const from = roleHomeMap[userRole];


    return (
        <div className="min-h-screen bg-gray-100 flex items-center justify-center px-6">
            <div className="max-w-6xl w-full flex flex-col lg:flex-row items-center justify-between gap-16">

                {/* Left Section */}
                <div className="max-w-md text-center lg:text-left">


                    <h1 className="text-4xl lg:text-5xl font-bold text-slate-800 mb-4">
                        Something's wrong here...
                    </h1>

                    <p className="text-gray-500 text-base leading-relaxed mb-8">
                        We can't find the page you're looking for.
                        <br />
                        Check out our help center or head back to home.
                    </p>

                    <div className="flex flex-wrap gap-4 justify-center lg:justify-start">


                        <Link
                            to={from}
                            className="bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg font-medium transition"
                        >
                            Back to home
                        </Link>
                    </div>
                </div>

                {/* Right Section */}
                <div className="flex justify-center">
                    <img
                        src={logo}
                        alt="404 Error"
                        className="w-full max-w-lg"
                    />
                </div>
            </div>
        </div>
    );
};

export default NotFound;