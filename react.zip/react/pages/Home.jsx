import React from 'react';


const Home = () => (
  <>
  
    <main>
      <section>
        <h1>Welcome to the Home Page</h1>
        <p>This is a sample home page using the Header component.</p>
     
      </section>
    </main>
  </>
);

export default Home;
