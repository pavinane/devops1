import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import TextInput from "../../components/commonComponents/TextInput";
import PrimaryButton from "../../components/commonComponents/PrimaryButton";
import passIcon from '../../assets/Buttons/PasswordIcon.svg'
import passwordIcom from '../../assets/Buttons/EyeOpen.svg'
import useForm from "../../components/commonComponents/useForm";
import { LoginSchema } from "../../validation/LoginSchema";
import profileicon from '../../assets/Buttons/InputProfileIcon.svg'
import { useReusableMutation } from "../../customHooks/useDataQuery";
import { useDispatch, useSelector } from "react-redux";
import { setUserState } from "../../redux/slice/userSlice";
import { ForgetPasswordSchema } from "../../validation/ForgetPassword";
import { useToast } from "../../components/ToastContext";
import resetPasswordIcon from '../../assets/Buttons/ResetPopup.svg'
import { MailCheck } from "lucide-react";
const ForgetPassword = () => {
    const navigate = useNavigate();
    const forgetPassword = {
        forgetusername: "",

    };
    const dispatch = useDispatch();
    const { success, error, warning, info, showToast } = useToast();
    const { forgetEmail } = useSelector((state) => state.user);
    const [showSuccessPopup, setShowSuccessPopup] = useState(false);

    const { mutate: reset } = useReusableMutation({
        onSuccess: (data) => {
            success(data?.message)
            dispatch(setUserState({ forgetEmail: formData?.forgetusername, activeTab: true }),);
            navigate("/otpverify")

        },
        onError: (err) => {
            error(err?.response?.data?.message)
        },
    });


    // const handleRestPassword = () => {
    //     const sendOtpPayload = {
    //         endPoint: "api/auth/password/send_otp",
    //         method: "POST",
    //         payload: {
    //             email: formData?.forgetusername
    //         },
    //     };
    //     reset(sendOtpPayload);
    // }

    const { mutate, isPending } = useReusableMutation({
        onSuccess: (data) => {
            setShowSuccessPopup(true)
            // handleRestPassword();
        },
        onError: (err) => {
            error(err?.response?.data?.message)
        },
    });

    const handleForgetPass = () => {
        if (isPending) return;

        const apiPayload = {
            endPoint: "api/auth/forgot-password",
            method: "POST",
            payload: {
                email: formData?.forgetusername
            },
        };

        mutate(apiPayload);
    };
    const {
        formData,
        setErrors,
        setFormData,
        errors,
        updateFieldData,
        handleSubmit,
    } = useForm(forgetPassword, ForgetPasswordSchema, handleForgetPass);

    return (
        <div className="w-full flex items-center justify-center p-4 sm:p-6 max-h-screen overflow-y-auto">
            <div className="w-full max-w-md  p-6 sm:p-8 my-auto  bg-white rounded-2xl shadow-lg">
                {showSuccessPopup ? <div className="text-center">
                    <div className="mb-6">
                        <div className="inline-block px-6 py-2 rounded-lg mb-6">
                            <h3 className="text-2xl font-bold text-black">
                                Email sent
                            </h3>
                        </div>
                    </div>
                    <div className="mb-6">
                        <MailCheck size={100} className="mx-auto text-green-600" />
                    </div>
                    <p className="font-inter font-medium text-[16px] mb-8">
                        Password reset link sent successfully. Please check your email.
                    </p>

                </div> : <>
                    <h2 className="text-3xl font-semibold text-black mb-8">
                        Forgot password
                    </h2>

                    <form className="space-y-6" onSubmit={handleSubmit}>
                        <TextInput
                            label="Email"
                            name="forgetusername"
                            placeholder="Enter username / Email"
                            value={formData?.forgetusername}
                            onChange={updateFieldData}
                            error={errors?.forgetusername}
                            icon={profileicon}
                            required
                        />
                        <PrimaryButton
                            title={isPending ? "Loading" : "Submit"}
                            width="w-[100%]"
                            type="submit"
                            onClick={handleSubmit}
                            disabled={isPending}
                            disable={isPending}
                            customClass={isPending ? "opacity-50 cursor-not-allowed" : "!bg-[#099309]"}
                        />
                        <div
                            onClick={() => navigate(-1)}
                            className="block text-center text-sm text-black mt-4 cursor-pointer underline"
                        >
                            Back
                        </div>
                    </form></>}


            </div>
        </div>
    );
};

export default ForgetPassword;


