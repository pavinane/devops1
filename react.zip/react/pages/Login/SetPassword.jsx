import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import TextInput from "../../components/commonComponents/TextInput";
import PrimaryButton from "../../components/commonComponents/PrimaryButton";
import passIcon from '../../assets/Buttons/PasswordIcon.svg'
import passwordIcom from '../../assets/Buttons/EyeOpen.svg'
import useForm from "../../components/commonComponents/useForm";
import { LoginSchema } from "../../validation/LoginSchema";
import { useReusableMutation } from '../../customHooks/useDataQuery'
import { SetPass } from "../../validation/SetPassSchema";
import { useToast } from "../../components/ToastContext";
import { jwtDecode } from "jwt-decode";
import { RegexValidations } from "../../validation/RegexValidation";
import resetPasswordIcon from '../../assets/Buttons/ResetPopup.svg'
import { setLogout, setUserState } from "../../redux/slice/userSlice";



const Setpassword = () => {
    const navigate = useNavigate();
    const { success, error, warning, info, showToast } = useToast();
    const [isNewPasswordVisible, setIsNewPasswordVisible] = useState(false);
    const [isConfirmPasswordVisible, setIsConfirmPasswordVisible] = useState(false);
    const [showSuccessPopup, setShowSuccessPopup] = useState(false);
    const [isNavigating, setIsNavigating] = useState(false);
    const { token } = useSelector((state) => state.user);
    const dispatch = useDispatch();
    const [gmailToken, setGmailToken] = useState("");
    const [email, setEmail] = useState("");

    const setPassword = {
        newPass: "",
        confirmPass: "",
    };


    const { mutate, isPending } = useReusableMutation({
        onSuccess: (data) => {
            success(data?.message)
            setShowSuccessPopup(true)
        },
        onError: (err) => {
            error(err?.response?.data?.message)
        },
    });

    const handleSetPass = () => {
        if (isPending) return;

        const apiPayload = {
            endPoint: `api/auth/reset-password`,
            method: "POST",
            payload: {
                email,
                token: gmailToken,
                password: formData?.newPass,
                password_confirmation: formData?.confirmPass,
            },
            token,
        };

        mutate(apiPayload);
    };

    const handleGoToLogin = () => {
        dispatch(setLogout());
        setIsNavigating(true);
        setTimeout(() => {
            navigate("/", { replace: true });
        }, 3000);
    }



    const { formData, setErrors, setFormData, errors, updateFieldData, handleSubmit, } = useForm(setPassword, SetPass, handleSetPass);


    useEffect(() => {
        const queryParams = new URLSearchParams(location.search);
        const tokenFromUrl = queryParams.get("token");
        const mailFromUrl = queryParams.get("email")
        setEmail(mailFromUrl);
        setGmailToken(tokenFromUrl);


    }, []);

    return (
        <div className="w-full flex items-center justify-center p-4 md:p-6">
            <div className="w-full max-w-md bg-white rounded-2xl shadow-lg p-4 md:p-8">
                {showSuccessPopup ? (
                    <div className="text-center">
                        <div className="mb-6">
                            <div className="inline-block px-6 py-2 rounded-lg mb-6">
                                <h3 className="text-2xl font-bold text-black">
                                    Password created
                                </h3>
                            </div>
                        </div>
                        <div className="mb-6">
                            <img
                                src={resetPasswordIcon}
                                alt="Success"
                                className="w-32 h-32 mx-auto"
                            />
                        </div>
                        <p className="font-inter font-medium text-[16px] mb-8">
                            Password created successfully. You can now log in
                        </p>
                        <PrimaryButton
                            title={isNavigating ? "Loading" : "Go to Login"}
                            width="w-full"
                            onClick={handleGoToLogin}
                            disabled={isNavigating}
                            disable={isNavigating}
                            customClass={isNavigating ? "opacity-50 cursor-not-allowed" : ""}
                        />
                    </div>
                ) : (
                    <>
                        <h2 className="text-3xl font-semibold text-black mb-8">
                            Create Password
                        </h2>

                        <form
                            className="space-y-6"
                            onSubmit={(e) => e.preventDefault()}
                        >
                            <TextInput
                                label="New Password"
                                name={"newPass"}
                                placeholder="Enter New Password"
                                value={formData?.newPass}
                                onChange={updateFieldData}
                                type={isNewPasswordVisible ? "text" : "password"}
                                icon={
                                    isNewPasswordVisible ? passwordIcom : passIcon
                                }
                                onIconClick={() =>
                                    setIsNewPasswordVisible(!isNewPasswordVisible)
                                }
                                error={errors?.newPass}
                                maxLength={17}
                                pointer={true}
                                regexValidation={RegexValidations.noSpaces}
                            />
                            <TextInput
                                label="Confirm Password"
                                name={"confirmPass"}
                                placeholder="Enter Confirm Password"
                                value={formData?.confirmPass}
                                onChange={updateFieldData}
                                type={
                                    isConfirmPasswordVisible ? "text" : "password"
                                }
                                icon={
                                    isConfirmPasswordVisible
                                        ? passwordIcom
                                        : passIcon
                                }
                                onIconClick={() =>
                                    setIsConfirmPasswordVisible(
                                        !isConfirmPasswordVisible,
                                    )
                                }
                                error={errors?.confirmPass}
                                maxLength={17}
                                pointer={true}
                                regexValidation={RegexValidations.noSpaces}
                            />

                            <PrimaryButton
                                title={isPending ? "Loading" : "Update"}
                                width="w-[100%]"
                                onClick={handleSubmit}
                                disabled={isPending}
                                disable={isPending}
                                customClass={isPending ? "opacity-50 cursor-not-allowed" : ""}
                            />
                            <div
                                onClick={() => navigate(-1)}
                                className="block text-center text-sm text-black mt-4 cursor-pointer underline"
                            ></div>
                        </form>
                    </>
                )}
            </div>
        </div>
    );
};

export default Setpassword;


