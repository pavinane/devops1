import React, { useContext, useEffect, useState } from "react";
import { useNavigate, useLocation, Navigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

import TextInput from "../../components/commonComponents/TextInput";
import PrimaryButton from "../../components/commonComponents/PrimaryButton";
import Checkbox from "../../components/commonComponents/Checkbox";

import useForm from "../../components/commonComponents/useForm";
import { LoginSchema } from "../../validation/LoginSchema";

import passIcon from "../../assets/Buttons/PasswordIcon.svg";
import passwordIcon from "../../assets/Buttons/EyeOpen.svg";
import profileIcon from "../../assets/Buttons/InputProfileIcon.svg";
import { useReusableMutation } from "../../customHooks/useDataQuery";
import { setUserState } from "../../redux/slice/userSlice";
import { useToast } from "../../components/ToastContext";
import { RegexValidations } from "../../validation/RegexValidation";

const LoginPage = () => {
    const { success, error, warning, info, showToast } = useToast();
    const navigate = useNavigate();
    const location = useLocation();
    const { isAuthenticated, roles } = useSelector((state) => state.user);

    const userRole = Array.isArray(roles) ? roles[0] : roles?.trim();
    const roleHomeMap = {
        office_admin: "/dashboard",
        member: "/meal-selection",
        room_incharge: "/profile",
    };


    const validRoutes = ["/dashboard"];

    const fromPath = location.state?.from?.pathname || "/dashboard";
    const isValidRoute = validRoutes.includes(fromPath);

    const from = roleHomeMap[userRole]

    // const from = isValidRoute
    //     ? fromPath + (location.state?.from?.search || "")
    //     : "/dashboard";
    const dispatch = useDispatch();

    const [isPasswordVisible, setIsPasswordVisible] = useState(false);
    const [rememberMe, setRememberMe] = useState(false);



    const LoginForm = {
        username: "",
        password: "",
    };

    const { mutate, isPending } = useReusableMutation({
        onSuccess: async (data) => {
            const { token, user } = data.data;

            dispatch(
                setUserState({
                    userName: user?.name,
                    token,
                    email: user?.email,
                    user_id: user?.id,
                    roles: user?.role,
                    isAuthenticated: true,
                    expiresAt: data?.expiresAt,
                })
            );

            const roleHomeMap = {
                office_admin: "/dashboard",
                member: "/meal-selection",
                room_incharge: "/profile",
            };

            navigate(roleHomeMap[user?.role] || "/", {
                replace: true,
            });
        },
        onError: (err) => {
            console.log(err);

            error(err?.response?.data?.message)
        },
    });

    const handleLogin = () => {
        if (isPending) return;


        const apiPayload = {
            endPoint: "api/auth/login",
            method: "POST",
            payload: {
                email: formData.username?.toLowerCase(),
                password: formData.password,
                remember_me: rememberMe,
            },
        };

        mutate(apiPayload);
    };

    const { formData, errors, updateFieldData, handleSubmit } = useForm(
        LoginForm,
        LoginSchema,
        handleLogin,
    );

    useEffect(() => {
        if (isAuthenticated) {
            navigate(from, { replace: true });
        }
    }, [isAuthenticated, navigate, from]);

    return (
        <div className="w-full flex flex-col items-center justify-center p-4 sm:p-6 max-h-screen overflow-y-auto">


            <div className="w-full max-w-md   bg-white rounded-2xl shadow-lg p-6 sm:p-8">
                <div>
                    <h2 className="text-2xl sm:text-3xl font-semibold text-black mb-6 sm:mb-8">
                        Sign in to Cloud Gate
                    </h2>

                </div>
                <form className="space-y-4 sm:space-y-6" onSubmit={handleSubmit}>
                    <TextInput
                        name="username"
                        placeholder="Enter  Email"
                        value={formData.username}
                        onChange={updateFieldData}
                        error={errors.username}
                        icon={profileIcon}
                        required

                    />

                    <TextInput
                        name="password"
                        placeholder="Enter password"
                        value={formData.password}
                        onChange={updateFieldData}
                        error={errors.password}
                        required
                        type={isPasswordVisible ? "text" : "password"}
                        icon={isPasswordVisible ? passwordIcon : passIcon}
                        onIconClick={() =>
                            setIsPasswordVisible((prev) => !prev)
                        }
                        pointer={true}
                        regexValidation={RegexValidations.noSpaces}
                    />

                    <div className="flex items-center justify-between">
                        <Checkbox
                            label="Remember me"
                            checked={rememberMe}
                            onChange={setRememberMe}
                        />

                        <button
                            type="button"
                            onClick={() => navigate("/forgetpassword")}
                            className="text-sm text-gray-600 hover:text-black cursor-pointer underline"
                        >
                            Forgot Password?
                        </button>
                    </div>

                    <PrimaryButton
                        title={isPending ? "Loading" : "Login"}
                        type="submit"
                        width="w-full"
                        disabled={isPending}
                        disable={isPending}
                        onClick={handleSubmit}
                        customClass={isPending ? "opacity-50 cursor-not-allowed" : " !bg-[#099309]"}
                    />
                </form>
            </div>

        </div>
    );
};

export default LoginPage;
