import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import Commonstatcard, {
    Sparkline,
} from "../../components/commonComponents/Commonstatcard";
import RevenueChart from "../../components/commonComponents/RevenueChart";
import TotalSalesChart from "../../components/commonComponents/TotalSalesChart";
import SalesOverview from "../../components/commonComponents/SalesOverview";
import NotificationPanel from "../../components/commonComponents/NotificationPanel";
import { DollarSign, ShoppingCart, Users } from "lucide-react";
import { useReusableMutation } from "../../customHooks/useDataQuery";
import { useToast } from "../../components/ToastContext";
import PageHeader from "../../components/commonComponents/PageHeader";

const CARD_SPARKLINES = {
    orders: [8, 14, 10, 24, 16, 32, 20, 38, 18, 30, 17, 34],
    rooms: [6, 12, 9, 18, 14, 28, 17, 33, 21, 29, 16, 31],
    users: [5, 10, 7, 16, 12, 24, 18, 30, 20, 27, 19, 32],
};

const DashBoardPages = () => {
    const { token } = useSelector((state) => state.user);
    const { error: showError } = useToast();
    const [stats, setStats] = useState({
        buildings: 0,
        rooms: 0,
        users: 0,
        meals_breakdown: { veg: 0, non_veg: 0, total: 0 },
    });

    const { mutate: fetchDashboardStats, isLoading } = useReusableMutation({
        onSuccess: (data) => {
            const responseData = data?.data || {};
            setStats({
                buildings: responseData?.stats?.buildings ?? 0,
                rooms: responseData?.stats?.rooms ?? 0,
                users: responseData?.stats?.users ?? 0,
                managers: responseData?.stats?.managers ?? 0,
                employees: responseData?.stats?.employees ?? 0,
                meals_breakdown: {
                    veg: responseData?.meals_breakdown?.veg ?? 0,
                    non_veg: responseData?.meals_breakdown?.non_veg ?? 0,
                    total: responseData?.meals_breakdown?.total ?? 0,
                },
            });
        },
        onError: (err) => {
            showError(err?.response?.data?.message || "Failed to load dashboard stats");
        },
    });

    const viewAPI = () => {
        const apiPayload = {
            endPoint: "api/admin/dashboard",
            method: "GET",
            token,
        };

        fetchDashboardStats(apiPayload);
    };

    useEffect(() => {
        viewAPI();
    }, []);

    return (
        <>
            <div className="flex w-full flex-col gap-6 pt-[15px]">
                <PageHeader title="Dashboard" />
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    <Commonstatcard
                        title="Orders"
                        value={stats?.meals_breakdown?.total?.toString() || "0"}
                        // growth="+19.01%"
                        chart={
                            <Sparkline
                                color="#F59E0B"
                                data={CARD_SPARKLINES.orders}
                                seriesName="Orders"
                            />
                        }
                        subtitle={`${stats?.meals_breakdown?.veg} Veg + ${stats?.meals_breakdown?.non_veg} Non-Veg`}
                    />

                    <Commonstatcard
                        title="Rooms"
                        value={stats?.rooms?.toString() || "0"}
                        growth="+19.01%"
                        chart={
                            <Sparkline
                                color="#60A5FA"
                                data={CARD_SPARKLINES.rooms}
                                seriesName="Rooms"
                            />
                        }
                    // subtitle={"jjgjgfgg"}
                    />

                    <Commonstatcard
                        title="Users"
                        value={stats?.users?.toString() || "0"}
                        growth=""
                        chart={
                            <Sparkline
                                color="#4ADE80"
                                data={CARD_SPARKLINES.users}
                                seriesName="Users"
                            />
                        }
                        subtitle={`${stats?.managers} Managers and ${stats?.employees} Employees`}
                    />
                </div>
                 {console.log(stats?.managers,"manager")}
                <div className="grid w-full grid-cols-1 gap-4 lg:grid-cols-[minmax(0,7fr)_minmax(0,3fr)]">
                    <div className="min-w-0">
                        <RevenueChart />
                    </div>

                    <div className="min-w-0">
                        <TotalSalesChart />
                    </div>
                </div>

                <div className="grid w-full grid-cols-1 gap-4 lg:grid-cols-2">
                    <div className="min-w-0">
                        <SalesOverview />
                    </div>

                    <div className="min-w-0">
                        <NotificationPanel />
                    </div>
                </div>
            </div>
        </>
    );
};

export default DashBoardPages;
