import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import TextInput from "../../components/commonComponents/TextInput";
import SelectInput from "../../components/commonComponents/SelectInput";
import DataTable from "../../components/commonComponents/DataTable";
import Modal from "../../components/commonComponents/Modal";
import useForm from "../../components/commonComponents/useForm";
import { buildingSchema } from "../../validation/buildingSchema";
import Edit from "../../assets/images/Edit.svg";
import Delete from "../../assets/images/Delete.svg";
import View from "../../assets/icons/view.svg";
import { useReusableMutation } from "../../customHooks/useDataQuery";
import { setBuildingSlice } from "../../redux/slice/buildingSlice.js";
import { useDispatch, useSelector } from "react-redux";
import { useMediaQueryValues } from "../../components/commonComponents/MediaQueryContext";
import MobileCard from "../../components/commonComponents/MobileCard.jsx";
import { useToast } from "../../components/ToastContext.jsx";
import ReactPaginateModule from "react-paginate";
import RadioButton from "../../components/commonComponents/RadioButton";
import PageHeader from "../../components/commonComponents/PageHeader.jsx";
import SearchIcon from "../../assets/icons/search.svg";

const statusOptions = [
    { value: "active", label: "Active" },
    { value: "inactive", label: "Inactive" },
];

const initialForm = {
    name: "",
    location: "",
    status: "active",
};

export default function Buildings() {
    const ReactPaginate = ReactPaginateModule.default ?? ReactPaginateModule;
    const navigate = useNavigate();

    const [showModal, setShowModal] = useState(false);
    const [isDeleteModal, setIsDeleteModal] = useState(false);
    const [buildingColumnList, setBuildingColumnList] = useState([]);
    const [rowId, setRowId] = useState(null);
    const [editData, setEditData] = useState(null);
    const [disableForm, setDisableForm] = useState(false);
    const [apiControl, setApiControl] = useState(true);
    const [searchTerm, setSearchTerm] = useState("");
    const [paginationData, setPaginationData] = useState({ pageSize: 10, pageIndex: 0, totalPages: 0, totalData: 0 });
    const { token } = useSelector((state) => state?.user);
    const dispatch = useDispatch();
    const { isDesktop, isMobile, isTablet } = useMediaQueryValues();
    const { success, error, warning, info, showToast } = useToast();

    const { mutate: buildingList, isPending } = useReusableMutation({
        onSuccess: (data) => {
            const rows = (data?.data ?? []).map((item) => ({
                id: item.id,
                building: item.name,
                location: item.location,
                rooms: item.rooms_count,
                status:
                    item.status === "active"
                        ? "Active"
                        : item.status === "inactive"
                            ? "Inactive"
                            : item.status,
            }));
            setBuildingColumnList(rows);
            setPaginationData((prev) => ({
                ...prev,
                totalPages: data?.pagination?.last_page ?? 1,
                totalData: data?.pagination?.total ?? rows.length,
            }));
            if (apiControl) setTimeout(() => setApiControl(false), 2000);
        },
        onError: (err) => { },
    });

    const fetchBuildings = () => {
        buildingList({
            endPoint: "api/admin/buildings/index",
            method: "POST",
            payload: {
                per_page: paginationData.pageSize,
                page: paginationData.pageIndex + 1,
                search: searchTerm,
            },
            token,
        });
    };

    useEffect(() => {
        fetchBuildings();
    }, []);

    useEffect(() => {
        if (!apiControl) fetchBuildings();
    }, [paginationData.pageIndex, paginationData.pageSize]);

    useEffect(() => {
        if (apiControl) return;
        if (searchTerm.length !== 0 && searchTerm.length < 3) return;
        const timerId = setTimeout(() => {
            setPaginationData((prev) => ({ ...prev, pageIndex: 0 }));
            fetchBuildings();
        }, 300);
        return () => clearTimeout(timerId);
    }, [searchTerm]);

    const handleSave = (formData) => {
        if (isBuildingAddPending) return;
        buildingAdd({
            endPoint: editData
                ? `api/admin/buildings/update`
                : "api/admin/buildings/store",
            method: editData ? "POST" : "POST",
            payload: editData
                ? {
                    id: rowId,
                    name: formData?.name,
                    location: formData?.location,
                    status: formData?.status,
                }
                : {
                    name: formData?.name,
                    location: formData?.location,
                    status: formData?.status,
                },
            token,
        });
    };

    const { mutate: buildingAdd, isPending: isBuildingAddPending } = useReusableMutation({
        onSuccess: () => {
            handleClose();
            fetchBuildings();
        },
        onError: (err) => {
            error(err?.response?.data?.errors?.name?.[0]);
        },
    });

    const {
        formData,
        errors,
        updateFieldData,
        handleSubmit,
        handleReset,
        setFormData,
    } = useForm(initialForm, buildingSchema, handleSave);

    const handleClose = () => {
        setShowModal(false);
        setEditData(null);
        setRowId(null);
        setDisableForm(false);
        handleReset();
    };

    const handleRowClick = (row) => {
        setDisableForm(true);
        setEditData(row);
        setRowId(row.id);
        setFormData({
            name: row.building,
            location: row.location ?? "",
            status: row.status === "Active" ? "active" : "inactive",
        });
        setShowModal(true);
    };

    const handleEdit = (e, row) => {
        e.stopPropagation();
        setDisableForm(false);
        setEditData(row);
        setRowId(row.id);
        setFormData({
            name: row.building,
            location: row.location ?? "",
            status: row.status === "Active" ? "active" : "inactive",
        });
        setShowModal(true);
    };

    const handleDelete = (e, row) => {
        e.stopPropagation();
        setRowId(row.id);
        setIsDeleteModal(true);
    };

    const { mutate: buildingDelete } = useReusableMutation({
        onSuccess: () => {
            setIsDeleteModal(false);
            setRowId(null);
            fetchBuildings();
        },
        onError: (err) => {
            error(err?.response?.data?.message)
        },
    });

    const confirmDelete = () => {
        buildingDelete({
            endPoint: `api/admin/buildings/delete`,
            method: "DELETE",
            payload: { id: rowId },
            token,
        });
    };

    const columns = [
        {
            key: "building",
            label: "BUILDING",
            render: (value) => (
                <div
                    data-tooltip-id="my-tooltip"
                    data-tooltip-content={value}
                    data-tooltip-place="bottom"
                    className="inline-block max-w-36 truncate whitespace-nowrap overflow-hidden text-ellipsis"
                >
                    {value}
                </div>
            ),
        },
        { key: "location", label: "LOCATION" },
        { key: "rooms", label: "ROOMS" },
        {
            key: "status",
            label: "STATUS",
            render: (val) => (
                <span

                    className={`text-xs font-medium px-2.5 py-1 rounded-full
                        ${val === "Active"
                            ? "bg-green-100 text-green-700"
                            : "bg-red-100 text-red-600"
                        }`}
                >
                    {val}
                </span>
            ),
        },
        {
            key: "action",
            label: "ACTIONS",
            render: (_, row) => (
                <div className="flex gap-3 justify-start">
                    <div
                        data-tooltip-id="my-tooltip"
                        data-tooltip-content={"View"}
                        data-tooltip-place="bottom"
                        className="w-[30px] h-[30px] rounded-full flex items-center justify-center bg-[#F4F4F4] cursor-pointer"
                        onClick={(e) => {
                            e.stopPropagation();
                            dispatch(setBuildingSlice({ buildingId: row.id }));
                            navigate(`/building/${row.id}`);
                        }}
                    >
                        <img src={View} alt="view" className="h-[22px]" />
                    </div>
                    <div
                        data-tooltip-id="my-tooltip"
                        data-tooltip-content={"Edit"}
                        data-tooltip-place="bottom"
                        className="w-[30px] h-[30px] rounded-full flex items-center justify-center bg-[#F4F4F4] cursor-pointer"
                        onClick={(e) => handleEdit(e, row)}
                    >
                        <img src={Edit} alt="edit" />
                    </div>
                    <div
                        data-tooltip-id="my-tooltip"
                        data-tooltip-content={"Delete"}
                        data-tooltip-place="bottom"
                        className="w-[30px] h-[30px] rounded-full flex items-center justify-center bg-[#F4F4F4] cursor-pointer"
                        onClick={(e) => handleDelete(e, row)}
                    >
                        <img src={Delete} alt="delete" />
                    </div>
                </div>
            ),
        },
    ];

    return (
        <div className="flex w-full flex-col gap-6 pt-[15px]">
            <PageHeader title="Buildings" />
            <div className="bg-white border border-black/10 flex justify-between rounded-2xl shadow-sm p-4 text-gray-500 w-full">
                <div className="flex gap-2 items-center rounded-2xl border border-black/10 px-3 py-1">
                    <img src={SearchIcon} alt="search" className="w-7 h-7" />
                    <input
                        type="search"
                        onChange={(e) => setSearchTerm(e.target.value)}
                        placeholder="Search Building"
                        value={searchTerm}
                        className="outline-none p-1 text-sm placeholder:text-sm"
                    />
                </div>
                {isDesktop && (
                    <button
                        onClick={() => setShowModal(true)}
                        className="bg-[#0aad0a] hover:bg-[#089408] transition-colors text-white py-2 px-4 rounded-xl cursor-pointer font-medium"
                    >
                        + Add Building
                    </button>
                )}
            </div>
            {!isDesktop && (
                <div className="fixed bottom-20 right-5 z-50">
                    <button
                        onClick={() => setShowModal(true)}
                        className="bg-[#0aad0a] hover:bg-[#089408] text-3xl text-white px-4 py-2 rounded-full font-medium transition cursor-pointer"
                    >
                        +
                    </button>
                </div>
            )}

            <div>
                {isDesktop ? (
                    <DataTable
                        columns={columns}
                        data={buildingColumnList}
                        pageSize={10}
                        showDot={false}
                        showCheckbox={false}
                        pageSizeOptions={[10, 30, 50]}
                        searchable={false}
                        searchPlaceholder="Search..."
                        tableHeight={480}
                        loading={isPending}
                        onRowClick={handleRowClick}
                        pagination={true}
                        paginationData={paginationData}
                        setPaginationData={setPaginationData}
                    />
                ) : (
                    <>
                        <div className={`grid gap-4 px-2 ${isTablet ? "grid-cols-2" : "grid-cols-1"}`}>
                            {buildingColumnList.map((row) => (
                                <MobileCard
                                    key={row.id}
                                    row={row}
                                    onClick={handleRowClick}
                                    onView={(e, r) => {
                                        e.stopPropagation();
                                        dispatch(setBuildingSlice({ buildingId: r.id }));
                                        navigate(`/building/${r.id}`);
                                    }}
                                    onEdit={handleEdit}
                                    onDelete={handleDelete}
                                />
                            ))}
                        </div>
                        {paginationData.totalPages > 0 && (
                            <div className="pb-4">
                                <div className="flex items-center justify-center mb-1">
                                    <p className="text-center text-sm text-gray-500">
                                        Showing {paginationData.totalData === 0 ? 0 : paginationData.pageIndex * paginationData.pageSize + 1} to {Math.min((paginationData.pageIndex + 1) * paginationData.pageSize, paginationData.totalData)} of {paginationData.totalData} entries
                                    </p>
                                </div>
                                <div className="flex justify-center">
                                    <ReactPaginate
                                        breakLabel="..."
                                        nextLabel=">"
                                        previousLabel="<"
                                        pageCount={paginationData.totalPages}
                                        forcePage={paginationData.pageIndex}
                                        onPageChange={(selected) =>
                                            setPaginationData((prev) => ({ ...prev, pageIndex: selected.selected }))
                                        }
                                        containerClassName="flex items-center gap-2"
                                        pageClassName="border rounded-full"
                                        pageLinkClassName="!w-[23px] h-[23px] flex items-center justify-center"
                                        activeClassName="bg-[#0aad0a] text-white border-[#0aad0a]"
                                        previousClassName="rounded-lg"
                                        previousLinkClassName="px-3 py-2 block"
                                        nextClassName="rounded-lg"
                                        nextLinkClassName="px-3 py-2 block"
                                        disabledClassName="opacity-50 cursor-not-allowed"
                                    />
                                </div>
                            </div>
                        )}
                    </>
                )}
            </div>

            <Modal
                isOpen={showModal}
                onClose={handleClose}
                title={disableForm ? "Building Details" : editData ? "Edit Building" : "Add Building"}
                showCloseButton
                outSideClick
                size="medium"
                width="w-full max-w-md"
            >
                <div className="mt-4 flex flex-col">
                    <TextInput
                        label="Name"
                        placeholder="Enter building name"
                        name="name"
                        value={formData.name}
                        onChange={updateFieldData}
                        error={errors.name}
                        required
                        disabled={disableForm}
                    />
                    <TextInput
                        label="Location"
                        placeholder="Enter location"
                        name="location"
                        value={formData.location}
                        onChange={updateFieldData}
                        error={errors.location}
                        required
                        disabled={disableForm}
                    />
                    <RadioButton
                        label="Status"
                        options={statusOptions}
                        selectedOption={formData?.status}
                        name="status"
                        onSelect={updateFieldData}
                        disabled={disableForm}
                        errors={errors?.status}
                    />
                    {!disableForm && (
                        <div className="flex justify-end mt-2">
                            <button
                                onClick={handleSubmit}
                                disabled={isBuildingAddPending}
                                className={`bg-[#0aad0a] hover:bg-[#089408] transition-colors text-white py-2 px-6 rounded-lg font-medium cursor-pointer ${isBuildingAddPending ? "opacity-50 cursor-not-allowed" : ""}`}
                            >
                                {isBuildingAddPending ? (editData ? "Updating..." : "Saving...") : editData ? "Update" : "Save"}
                            </button>
                        </div>
                    )}
                </div>
            </Modal>

            <Modal
                isOpen={isDeleteModal}
                onClose={() => setIsDeleteModal(false)}
                title="Delete Building"
                showCloseButton
                outSideClick
                size="medium"
                width="w-full max-w-sm"
            >
                <div className="mt-4">
                    <p className="text-sm text-gray-500 mb-6">
                        Are you sure you want to delete this building?
                    </p>
                    <div className="flex justify-end gap-3">
                        <button
                            onClick={() => setIsDeleteModal(false)}
                            className="px-4 py-2 rounded-lg border border-gray-300 text-sm font-medium text-gray-700 hover:bg-gray-50 cursor-pointer"
                        >
                            Cancel
                        </button>
                        <button
                            onClick={confirmDelete}
                            className="px-4 py-2 rounded-lg bg-red-500 hover:bg-red-600 text-white text-sm font-medium cursor-pointer"
                        >
                            Delete
                        </button>
                    </div>
                </div>
            </Modal>
        </div>
    );
}
