function SectionCard({ icon, title, children }) {
    return (
        <div className="bg-white border border-gray-200 rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-3">
                {icon}
                <h2 className="text-sm font-semibold text-gray-800">{title}</h2>
            </div>
            {children}
        </div>
    );
}

export default SectionCard;