import React, { useState, useRef, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { useReusableMutation } from "../../customHooks/useDataQuery";
import RoomRequestsSection from "../../components/commonComponents/Roomrequestssection";
import EmployeesSection from "../../components/commonComponents/EmployeesSection";

const RoomDetail = () => {
    const { buildingId, roomId } = useParams();
    const navigate = useNavigate();
    const { token } = useSelector((state) => state?.user);
    const [room, setRoom] = useState(null);
    const [expandedEmployeeId, setExpandedEmployeeId] = useState(null);

    const { mutate: fetchRoom, isPending } = useReusableMutation({
        onSuccess: (data) => {
            if (data?.data) {
                setRoom(data.data);
            }
        },
        onError: (err) => {
            console.error("Error fetching room:", err);
        },
    });

    useEffect(() => {
        if (roomId) {
            fetchRoom({
                endPoint: `api/admin/rooms/show`,
                method: "POST",
                payload: { id: roomId },
                token,
            });
        }
    }, [roomId]);

    if (isPending) {
        return (
            <div className="max-w-6xl mx-auto px-3 sm:px-4 py-6 sm:py-8">
                <p className="text-gray-400 text-xs sm:text-sm">Loading room details...</p>
            </div>
        );
    }

    if (!room) {
        return (
            <div className="max-w-6xl mx-auto px-3 sm:px-4 py-6 sm:py-8">
                <p className="text-gray-400 text-xs sm:text-sm">Room not found.</p>
            </div>
        );
    }

    return (
        <div className="max-w-6xl mx-auto px-3 sm:px-4 py-6 sm:py-8 flex flex-col gap-4 sm:gap-6">
     
            <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between border border-gray-200 rounded-lg sm:rounded-2xl bg-white p-3 sm:p-5 gap-3 sm:gap-0">
                <div className="flex flex-col gap-2 sm:gap-3 flex-1">
                    <h1 className="text-2xl sm:text-3xl font-semibold text-gray-900">
                        Room {room.room_number}
                    </h1>
                    <p className="text-xs sm:text-sm text-gray-500">
                        {room.building?.name} 
                    </p>
                    <div className="">
                        <span
                            className={`inline-block text-xs font-medium px-2.5 py-1 rounded-full ${
                                room.status === "active"
                                    ? "bg-green-100 text-green-700"
                                    : "bg-red-100 text-red-600"
                            }`}
                        >
                            {room.status === "active" ? "Active" : "Inactive"}
                        </span>
                    </div>
                    <p className="text-[12px] sm:text-[14px] font-medium text-gray-500">
                        Floor {room.floor} - {room.capacity} members - code : {room.room_code}
                    </p>
                </div>
                <button
                    onClick={() => navigate(`/building/${buildingId}`)}
                    className="w-full sm:w-auto px-3 sm:px-4 py-2 border border-[#0aad0a] rounded-lg text-xs sm:text-sm font-medium text-[#0aad0a] hover:bg-gray-50 transition cursor-pointer"
                >
                    Back to Rooms
                </button>
            </div>            

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
                <EmployeesSection members={room.members || []} />
                <RoomRequestsSection
                    requests={room.requests?.map((req) => ({
                        ...req,
                        employee_name: room.members?.find(
                            (m) => m.employee_id === req.employee_id
                        )?.name,
                    })) || []}
                />
            </div>

            <div className="bg-white border border-gray-200 rounded-lg sm:rounded-2xl overflow-hidden">
                <div className="p-3 sm:p-5 border-b border-gray-200">
                    <div className="flex items-center gap-2">
                        <svg
                            width="18"
                            height="18"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            className="text-gray-600 flex-shrink-0"
                        >
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                            <line x1="16" y1="2" x2="16" y2="6" />
                            <line x1="8" y1="2" x2="8" y2="6" />
                            <line x1="3" y1="10" x2="21" y2="10" />
                        </svg>
                        <h2 className="text-xs sm:text-sm font-semibold text-gray-800">
                            Monthly request history
                        </h2>
                    </div>
                </div>

                {room.members && room.members.length > 0 ? (
                    <div className="divide-y divide-gray-200">
                        {room.members.map((member) => {
                            const memberRequests =
                                room.requests?.filter(
                                    (req) => req.employee_id === member.employee_id
                                ) || [];

                            return (
                                <div key={member.id}>
                                    <button
                                        onClick={() =>
                                            setExpandedEmployeeId(
                                                expandedEmployeeId === member.id ? null : member.id
                                            )
                                        }
                                        className="w-full px-3 sm:px-5 py-3 sm:py-4 flex items-center justify-between hover:bg-gray-50 transition text-left cursor-pointer"
                                    >
                                        <div className="flex items-center gap-2 sm:gap-3 flex-1 min-w-0">
                                            <span className="text-xs sm:text-sm font-semibold text-gray-900 truncate">
                                                {member.name}
                                            </span>
                                            <span className="text-xs text-gray-500 bg-blue-50 px-2 py-1 rounded-2xl flex-shrink-0">
                                                {member.employee_id}
                                            </span>
                                            <span className="text-xs font-semibold text-gray-600 bg-gray-100 px-2 py-1 sm:px-2.5 sm:py-1 rounded-full whitespace-nowrap flex-shrink-0">
                                                {memberRequests.length} req
                                                {memberRequests.length !== 1 ? "s" : ""}
                                            </span>
                                        </div>
                                        <svg
                                            width="20"
                                            height="20"
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            strokeWidth="2"
                                            className={`text-gray-500 transition-transform flex-shrink-0 ${
                                                expandedEmployeeId === member.id ? "rotate-180" : ""
                                            }`}
                                        >
                                            <polyline points="6 9 12 15 18 9" />
                                        </svg>
                                    </button>

                                    {expandedEmployeeId === member.id &&
                                        memberRequests.length > 0 && (
                                            <div className="bg-blue-50 px-3 sm:px-5 py-3 sm:py-4">
                                                <div className="space-y-2 sm:space-y-3">
                                                    {memberRequests.map((request) => (
                                                        <div
                                                            key={request.id}
                                                            className="flex flex-col sm:flex-row sm:items-center sm:justify-between text-xs sm:text-sm p-2 sm:p-3 bg-white rounded-lg border border-gray-200 gap-2"
                                                        >
                                                            <div className="flex-1 min-w-0">
                                                                <p className="font-semibold text-gray-900 truncate">
                                                                    {request.category}
                                                                </p>
                                                                <p className="text-xs text-gray-500 mt-1">
                                                                    {request.requested_date}
                                                                </p>
                                                            </div>
                                                            <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
                                                                <span className="text-gray-600 text-xs whitespace-nowrap">
                                                                    Qty: {request.quantity}
                                                                </span>
                                                                <span
                                                                    className={`text-xs font-medium px-2 py-1 rounded-full capitalize flex-shrink-0 ${
                                                                        request.status === "pending"
                                                                            ? "text-[#B56A2A] bg-[#EFD1B1]"
                                                                            : request.status === "approved"
                                                                            ? "bg-green-100 text-green-700"
                                                                            : "bg-red-100 text-red-600"
                                                                    }`}
                                                                >
                                                                    {request.status === "pending"
                                                                        ? "Pending"
                                                                        : request.status === "approved"
                                                                        ? "Approved"
                                                                        : "Rejected"}
                                                                </span>
                                                            </div>
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                        )}
                                </div>
                            );
                        })}
                    </div>
                ) : (
                    <div className="px-3 sm:px-5 py-6 sm:py-8 text-center text-gray-400">
                        <p className="text-xs sm:text-sm">No request history available</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default RoomDetail;