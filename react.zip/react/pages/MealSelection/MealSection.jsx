import React, { useEffect, useState } from "react";
import passwordIcon from "../../assets/Buttons/EyeOpen.svg";
import editIcon from "../../assets/images/Edit.svg";
import Modal from "../../components/commonComponents/Modal";
import { useMediaQueryValues } from "../../components/commonComponents/MediaQueryContext";
import { useSelector } from "react-redux";
import { useReusableMutation } from "../../customHooks/useDataQuery";
import { useToast } from "../../components/ToastContext";
import PrimaryButton from "../../components/commonComponents/PrimaryButton";
import PageHeader from "../../components/commonComponents/PageHeader";

const MEAL_KEYS = ["breakfast", "lunch", "dinner"];

const MEAL_ICONS = {
  breakfast: "☀️",
  lunch: "🍴",
  dinner: "🌙",
};

export default function MealSelection() {
  const { success, error } = useToast();
  const { isMobile,isTablet } = useMediaQueryValues();
  const { token } = useSelector((state) => state.user);

  const [mealDates, setMealDates] = useState([]);
  const [modal, setModal] = useState(null);
  const [saved, setSaved] = useState(false);

  const cardToTempState = (card) => ({
    foodType: card.preview?.meal_type === "nonveg" ? "nonveg" : "veg",
    breakfast: card.meals?.breakfast?.done ?? false,
    lunch: card.meals?.lunch?.done ?? false,
    dinner: card.meals?.dinner?.done ?? false,
    breakfast_location: card.meals?.breakfast?.location ?? "room",
    lunch_location: card.meals?.lunch?.location ?? "room",
    dinner_location: card.meals?.dinner?.location ?? "room",
  });

  const { mutate: getMealDetails } = useReusableMutation({
    onSuccess: (data) => {
      setMealDates(data?.data?.date_cards ?? []);
    },
    onError: () => error("Failed to load meal data"),
  });

  const getUserData = () => {
    getMealDetails({
      endPoint: "api/member/meal-selection",
      method: "GET",
      token,
    });
  };

  useEffect(() => {
    getUserData();
  }, []);

  const { mutate: mealSetting } = useReusableMutation({
    onSuccess: (data) => {
       setSaved(false);
      success(data?.message);
        
       
   
      getUserData();
      closeModal();
    },
    onError: (err) => {
      error(err?.response?.data?.message ?? "Something went wrong");
    },
  });

  const saveOrder = () => {
    if (!modal) return;
    const card = mealDates[modal.dateIndex];
    const meal_type = modal.tempState.foodType === "nonveg" ? "nonveg" : "veg";

    const selections = MEAL_KEYS
      .filter((mk) => modal.tempState[mk] === true)
      .map((mk) => ({
        meal_time: mk,
        location: modal.tempState[`${mk}_location`],
      }));

    if (selections.length === 0) {
      error("Please select at least one meal.");
      return;
    }
     setSaved(true);

    mealSetting({
      endPoint: "api/member/meal-selection/save",
      method: "POST",
      payload: {
        meal_date: card.date,
        meal_type,
        selections,
      },
      token,
    });
  };


  const openModal = (dateIndex) => {
    const card = mealDates[dateIndex];
    if (!card) return;
    setModal({ dateIndex, tempState: cardToTempState(card) });
  };

  const closeModal = () => setModal(null);

  const toggleFoodType = () =>
    setModal((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        tempState: {
          ...prev.tempState,
          foodType: prev.tempState.foodType === "veg" ? "nonveg" : "veg",
        },
      };
    });

  const toggleMeal = (mk) =>
    setModal((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        tempState: {
          ...prev.tempState,
          [mk]: !prev.tempState[mk],
        },
      };
    });



  const toggleLocation = (mk) =>
    setModal((prev) => {
      if (!prev) return prev;
      const key = `${mk}_location`;
      return {
        ...prev,
        tempState: {
          ...prev.tempState,
          [key]: prev.tempState[key] === "room" ? "office" : "room",
        },
      };
    });


  const renderCard = (card, dateIndex) => {
    const { day_num, day_short, tag, hint, is_today, is_tomorrow, meals, preview, locked } = card;


    return (
      <div
        key={card.date}
        onClick={() => openModal(dateIndex)}
        className={`
          bg-white rounded-xl p-6 cursor-pointer transition-all min-h-[180px]
          ${is_today
            ? "border-2 border-teal-500"
            : "border border-gray-200 hover:border-gray-300"
          }
        `}
      >

        <div className="flex justify-between items-start">
          <div>
            <div className="text-4xl font-semibold text-gray-900">{day_num}</div>
            <div className="text-sm font-medium text-gray-700">{day_short}</div>

          </div>
          {is_today
            ?
            <div className="flex gap-4 ">
              <img src={passwordIcon} alt="Preview" className="w-5 h-5" />
              <div className="text-sm font-medium text-gray-700 text-end w-full ">{locked && "🔒"}</div>

            </div>
            :
            <img src={editIcon} alt="Edit" className="w-7 h-7" />
          }
        </div>

        {tag && (
          <div className="mt-3">
            <span className={`text-xs font-semibold px-3 py-1 rounded text-white
              ${is_today ? "bg-teal-600" : "bg-blue-600"}`}>
              {tag}
            </span>
          </div>
        )}


        <div className="mt-2">
          <span className={`text-xs font-medium px-2 py-0.5 rounded-full
            ${preview?.meal_type === "nonveg"
              ? "bg-red-100 text-red-600"
              : "bg-green-100 text-green-700"
            }`}>
            {preview?.meal_type === "nonveg" ? "Non-Veg" : "Veg"}
          </span>
        </div>


        <div className="flex flex-wrap gap-2 mt-3">
          {MEAL_KEYS.map((mk) => (
            <span
              key={mk}
              className={`flex items-center gap-1 text-xs px-3 py-1 rounded-lg border
                ${meals[mk]?.done
                  ? "border-(--fc-btn-border-color) bg-teal-50 text-teal-700"
                  : "border-gray-200 bg-gray-50 text-gray-500"
                }`}
            >
              <span>{MEAL_ICONS[mk]}</span>
              {meals[mk]?.label}
            </span>
          ))}
        </div>


        <div className="mt-4 text-sm">
          {is_today
            ? <span className="text-gray-500">Preview only</span>
            : is_tomorrow
              ? <span className="text-red-600 font-medium">{hint}</span>
              : <span className="text-gray-500">{hint}</span>
          }
        </div>
      </div>
    );
  };

  const firstRow = mealDates.slice(0, 4);
  const secondRow = mealDates.slice(4);

  return (
    <div className={`${isMobile ? "p-3" : "p-6"} font-sans`}>
      <PageHeader title="Meal Selection" />

      <div className="bg-white border border-gray-200 rounded-2xl shadow-sm p-5 md:p-6 mb-8">
        <div className="space-y-3">
          <p className="text-base md:text-lg text-gray-800">
            <span className="font-semibold">Today</span> — preview only (kitchen prepared).
            <span className="font-semibold ml-2">Tomorrow</span> — order before
            <span className="text-red-600 font-bold mx-1">7:00 PM</span> (then locked).
          </p>
          <p className="italic text-gray-600 text-sm md:text-base">
            Later dates — order anytime; tap again to change or preview.
          </p>
        </div>
      </div>


      <div className="mt-8 md:mt-12">
        

        {mealDates.length === 0 ? (
          <p className="text-gray-400 text-sm text-center py-10">Loading...</p>
        ) : isMobile ? (
          <div className="flex flex-col gap-4">
            {mealDates.map((card, i) => renderCard(card, i))}
          </div>
        ) : isTablet ? (
          // Tablet: 2 columns
          <div className="grid grid-cols-2 gap-4">
            {mealDates.map((card, i) => renderCard(card, i))}
          </div>
        ) : (
   
          <>
            <div className="grid grid-cols-4 gap-6 mb-6">
              {firstRow.map((card, i) => renderCard(card, i))}
            </div>
            <div className="grid grid-cols-4 gap-6">
              {secondRow.map((card, i) => renderCard(card, i + 4))}
            </div>
          </>
        )}
      </div>


      <Modal
        isOpen={!!modal}
        onClose={closeModal}
        outSideClick={false}
        size="medium"
        width="w-full max-w-md"
        showCloseButton={false}
        customClass="!p-0 overflow-hidden mx-4"
      >

        {modal && (() => {
          const card = mealDates[modal.dateIndex];
          
          if (!card) return null;

          const isLocked = card.locked;
          const currentLocation = modal.tempState.breakfast_location;

          return (
            <div className={`rounded-2xl w-full mx-auto ${isMobile ? "p-4" : "p-6"} max-w-sm`}>


              <h3 className="text-base font-medium text-gray-900">
                {card.day_short} {card.day_num}
              </h3>


              <div className="flex items-center justify-between border border-gray-200 rounded-lg px-4 py-3 mt-4 mb-2">
                <div>
                  <p className="text-sm font-medium text-gray-700">Food Type</p>
                  <p className={`text-xs font-semibold mt-0.5 ${modal.tempState.foodType === "nonveg" ? "text-red-500" : "text-green-600"
                    }`}>
                    {modal.tempState.foodType === "nonveg" ? "Non-Veg" : "Veg"}
                  </p>
                </div>
                <button
                  onClick={toggleFoodType}
                  disabled={isLocked}
                  className={`w-12 h-6 rounded-full relative transition-colors 
                    ${modal.tempState.foodType === "nonveg" ? "bg-red-500" : "bg-green-500"}
                    ${isLocked ? "opacity-50 cursor-not-allowed cursor-pointer" : "cursor-pointer"}
                  `}
                >
                  <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all
                    ${modal.tempState.foodType === "nonveg" ? "left-[26px]" : "left-0.5"}`}
                  />
                </button>
              </div>



              <p className="text-sm text-gray-400 mt-1 mb-4">{card.hint}</p>


              <div className="divide-y divide-gray-100">
                {MEAL_KEYS.map((mk) => {
                  const locKey = `${mk}_location`;
                  const loc = modal.tempState[locKey];
                  return (
                    <div key={mk} className="py-3">

                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-2 text-sm text-gray-700">
                          <span>{MEAL_ICONS[mk]}</span>
                          {card.meals[mk]?.label}
                        </span>
                        <button
                          onClick={() => toggleMeal(mk)}
                          disabled={isLocked}
                          className={`w-10 h-6 rounded-full relative transition-colors
              ${modal.tempState[mk] ? "bg-[var(--fc-btn-active-bg)]" : "bg-gray-200"}
              ${isLocked ? "opacity-50 cursor-not-allowed cursor-pointer" : "cursor-pointer"}
            `}
                        >
                          <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all
              ${modal.tempState[mk] ? "left-[18px]" : "left-0.5"}`}
                          />
                        </button>
                      </div>

       
                      {modal.tempState[mk] && (
                        <div className="flex items-center justify-between mt-2 pl-6">
                          <p className={`text-xs font-medium ${loc === "office" ? "text-blue-500" : "text-orange-500"}`}>
                            {loc === "office" ? "🏢 Office" : "🏠 Room"}
                          </p>
                          <button
                            onClick={() => toggleLocation(mk)}
                            disabled={isLocked}
                            className={`w-10 h-6 rounded-full relative transition-colors
                ${loc === "office" ? "bg-blue-500" : "bg-orange-400"}
                ${isLocked ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}
              `}
                          >
                            <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all
                ${loc === "office" ? "left-[18px]" : "left-0.5"}`}
                            />
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

           
              <div className={`gap-3 mt-5 ${isMobile ? "flex flex-row justify-between" : "flex"}`}>
                <PrimaryButton
                  onClick={closeModal}
                  title="Cancel"
                  btnBorder="border border-[var(--fc-btn-hover-border-color)]"
                  customClass="rounded-md"
                  bgColor="bg-white"
                  textColor="text-black"
                  width="w-full"
                />
                {!isLocked && (
                  <PrimaryButton
                    onClick={saveOrder}
                    disable={saved}
                       title={saved ? "Saved!" : "Save Order"}
                    customClass="btn-primary btn-primary:hover rounded-md"
                    bgColor="bg-white"
                    textColor="text-black"
                    width="w-full"
                  />
                )}
              </div>

            </div>
          );
        })()}
      </Modal>
    </div>
  );
}