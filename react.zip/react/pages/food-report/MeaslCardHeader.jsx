import FoodReportIcon from "./FoodReportIcon";
import StatusPill from "./StatusPill";

const MealCardHeader = ({
  icon,
  label,
  status,
  statusLabel,
  roomSummary,
  reportingStatus,
  currentEst,
}) => (
  <div className="flex items-start justify-between gap-3 mb-3">
    <div className="flex items-center gap-2.5">
      <div className="w-9 h-9 rounded-xl bg-[#0aad0a] flex items-center justify-center flex-shrink-0">
        <FoodReportIcon name={icon} filled className="text-white text-[30px]" />
      </div>
      <div>
        <div className="flex items-center gap-2">
          <h3 className="text-base font-bold text-white">{label}</h3>
        </div>
        {roomSummary && (
          <p className="text-[11px] text-white mt-0.5">{roomSummary}</p>
        )}
      </div>
    </div>
    {currentEst && (
      <div className="text-right flex-shrink-0">
        <p className="text-[10px] text-white/70 uppercase tracking-wider">Current</p>
        <p className="text-sm font-bold text-white mono">
          V {currentEst.veg} / NV {currentEst.nonVeg}
        </p>
      </div>
    )}
  </div>
);

export default MealCardHeader;