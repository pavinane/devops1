import FoodReportIcon from "./FoodReportIcon";
import RoomCard from "./RoomCard";
import { useMediaQueryValues } from "../../components/commonComponents/MediaQueryContext";

const BuildingGroup = ({
  name,
  totalRooms,
  reportedRooms,
  rooms = [],
  isOpen = false,
  onToggle,
}) => {
  const { isMobile, isTablet } = useMediaQueryValues();
  const roomGridCols = isMobile ? "grid-cols-1" : isTablet ? "grid-cols-2" : "grid-cols-3";

  return (
    <div className="border border-gray-200 rounded-xl overflow-hidden">
      <button
        onClick={onToggle}
        className={`w-full cursor-pointer flex items-center justify-between px-4 py-3.5 transition-colors ${
          isOpen ? "bg-blue-50" : "bg-white hover:bg-gray-50"
        }`}
      >
        <div className="flex items-center gap-3">
          <span className="text-sm font-extrabold tracking-wide text-gray-800 uppercase">
            {name}
          </span>
          <span className="text-[11px] font-semibold text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">
            {reportedRooms}/{totalRooms} rooms
          </span>
        </div>
        <FoodReportIcon
          name={isOpen ? "keyboard_arrow_up" : "keyboard_arrow_down"}
          className="text-gray-400 text-[22px]"
        />
      </button>

      <div className={`grid transition-all duration-[500ms] ease-in-out ${
        isOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]"
      }`}>
        <div className="overflow-hidden">
          {rooms.length > 0 ? (
            <div className="p-4 bg-gray-50 border-t border-gray-100">
              <div className={`grid ${roomGridCols} gap-3`}>
                {rooms.map((room) => (
                  <RoomCard key={room.id} {...room} />
                ))}
              </div>
            </div>
          ) : (
            <div className="px-4 py-6 bg-gray-50 border-t border-gray-100 text-center">
              <FoodReportIcon name="meeting_room" className="text-gray-300 text-[32px] mb-2" />
              <p className="text-xs text-gray-400">No room data available yet.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BuildingGroup