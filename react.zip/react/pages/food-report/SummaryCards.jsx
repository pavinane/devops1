import FoodReportIcon from "./FoodReportIcon";
import { useMediaQueryValues } from "../../components/commonComponents/MediaQueryContext";

const SummaryCards = ({ totalVeg, totalNonVeg, grandTotal }) => {
  const { isMobile } = useMediaQueryValues();
  const cards = [
    {
      key: "veg",
      label: "VEG",
      value: totalVeg,
      icon: "eco",
      bg: "bg-emerald-50",
      iconBg: "bg-[#0aad0a]",
      text: "text-[#0aad0a]",
      border: "border-[#0aad0a]",
    },
    {
      key: "nonveg",
      label: "NON-VEG",
      value: totalNonVeg,
      icon: "set_meal",
      bg: "bg-red-50",
      iconBg: "bg-red-500",
      text: "text-red-500",
      border: "border-red-500",
    },
    {
      key: "grand",
      label: "GRAND TOTAL",
      value: grandTotal,
      icon: "bar_chart",
      bg: "bg-gray-200",
      iconBg: "bg-black",
      text: "text-black",
      border: "border-black",
    },
  ];

  return (
    <div className={`grid gap-3 ${isMobile ? "grid-cols-1" : "grid-cols-3"}`}>
      {cards.map((c, i) => (
        <div
          key={c.key}
          className={`${c.bg} rounded-2xl p-4 border ${c.border} shadow-sm flex items-center justify-between fade-up`}
          style={{ animationDelay: `${i * 60}ms` }}
        >
          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-1">
              {c.label}
            </p>
            <p className={`text-3xl font-bold ${c.text} mono`}>{c.value}</p>
          </div>
          <div
            className={`${c.iconBg} w-10 h-10 rounded-xl flex items-center justify-center text-white`}
          >
            <FoodReportIcon name={c.icon} filled className="text-[30px]" />
          </div>
        </div>
      ))}
    </div>
  );
};
export default SummaryCards