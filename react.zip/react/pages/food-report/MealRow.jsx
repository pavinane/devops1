const MealRow = ({ label, value }) => (
  <div className="flex items-center justify-between py-1.5 border-b border-gray-100 last:border-0">
    <span className="text-xs text-gray-500">{label}:</span>
    <span className="text-xs font-medium text-gray-700">
      {value ?? <span className="text-gray-300">—</span>}
    </span>
  </div>
);

export default MealRow;