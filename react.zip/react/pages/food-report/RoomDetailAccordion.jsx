import { useState } from "react";
import BuildingGroup from "./BuildingGroup";
import FoodReportIcon from "./FoodReportIcon";

const RoomDetailAccordion = ({ expanded, onToggle, buildings = [] }) => {
  const [openIndex, setOpenIndex] = useState(0);
  return (
  <div className="bg-white border border-gray-200 rounded-2xl shadow-sm overflow-hidden">

    <button
      onClick={onToggle}
      className="w-full flex items-center justify-between px-5 py-4 hover:bg-gray-50 transition-colors cursor-pointer"
    >
      <div className="flex items-center gap-2.5">
        <FoodReportIcon
          name={expanded ? "arrow_drop_down" : "play_arrow"}
          className="text-[#0aad0a] text-[22px]"
        />
        <span className="text-sm font-semibold text-gray-700">
          Room detail cards (source &amp; per-meal breakdown)
        </span>
      </div>
      <span className="text-xs text-gray-400 font-medium hidden sm:block">
        {expanded ? "Collapse" : "Click to expand details"}
      </span>
    </button>

    {expanded && (
      <div className="border-t border-gray-100">

        <p className="px-5 pt-3 pb-4 text-xs text-gray-400 leading-relaxed">
          Incharge submitted entries and member selections when no incharge entry exists.
        </p>

        <div className="px-5 pb-5 space-y-3">
          {buildings.map((building, i) => (
            <BuildingGroup
              key={building.id}
              {...building}
              isOpen={openIndex === i}
              onToggle={() => setOpenIndex(openIndex === i ? -1 : i)}
            />
          ))}
        </div>
      </div>
    )}
  </div>
  );
};

export default RoomDetailAccordion;