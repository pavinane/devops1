const RoomStatusBadge = ({ status }) => {
  const styles = {
    none:   "bg-blue-50   text-blue-500  border-blue-100",
    veg:    "bg-emerald-50 text-emerald-600 border-emerald-100",
    nonveg: "bg-red-50    text-red-500   border-red-100",
    both:   "bg-gray-300 text-black border-[#0aad0a]",
  };
  const labels = { none: "None", veg: "Veg", nonveg: "Non-Veg", both: "Both" };
  return (
    <span
      className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${
        styles[status] ?? styles.none
      }`}
    >
      {labels[status] ?? "None"}
    </span>
  );
};


export default RoomStatusBadge;