import ProgressBar from "./ProgressBar";

const DinnerPrepStatus = ({ items = [] }) => (
  <div>
    <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-3 px-1">
      Inventory &amp; Prep Status
    </p>
    <div className="space-y-4">
      {items.map((item) => (
        <ProgressBar key={item.label} {...item} />
      ))}
    </div>
  </div>
);


export default DinnerPrepStatus