import VNT from "./VNT";

const LocationRow = ({ name, veg, nonVeg }) => (
  <div className="flex items-center justify-between py-2.5 px-4 hover:bg-gray-50 rounded-xl transition-colors group">
    <span className="text-sm font-medium text-gray-700 group-hover:text-[#0aad0a] transition-colors">
      {name}
    </span>
    <VNT veg={veg} nonVeg={nonVeg} />
  </div>
);

export default LocationRow