import FoodReportIcon from "./FoodReportIcon";
import MealLocationList from "./MealLocationList";

const DinnerCard = ({ meal }) => (
  <div
    className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow fade-up"
    style={{ animationDelay: "120ms" }}
  >
    <div className="px-5 pt-4 pb-2 bg-[#0aad0a]">
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#0aad0a] flex items-center justify-center flex-shrink-0">
            <FoodReportIcon name={meal.icon} filled className="text-white text-[30px]" />
          </div>
          <h3 className="text-base font-bold text-white">{meal.label}</h3>
        </div>
        {meal.currentEst && (
          <div className="text-right flex-shrink-0">
            <p className="text-[10px] text-white/70 uppercase tracking-wider">Current</p>
            <p className="text-sm font-bold text-white mono">
              V {meal.currentEst.veg} / NV {meal.currentEst.nonVeg}
            </p>
          </div>
        )}
      {/* <div className="bg-white rounded-b-xl p-4">
      <div className={`grid gap-6 ${isMobile ? "grid-cols-1" : "grid-cols-2"}`}>
        {meal.quickSummary && <DinnerQuickSummary {...meal.quickSummary} />}
        {meal.prepStatus && <DinnerPrepStatus items={meal.prepStatus} />}
      </div>
    </div> */}
      </div>
    </div>
    <MealLocationList locations={meal.locations || []} reportingStatus={null} />
    <div className="h-3" />
  </div>
);

export default DinnerCard;