import LocationRow from "./LocationRow";

const MealLocationList = ({ reportingStatus, locations = [] }) => (
  <div className="mt-1">
    <div className="flex items-center justify-between px-4 py-1 mb-1">
      <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">
        Location Breakdown
      </span>
      {/* {reportingStatus != null && (
        <span className="text-[11px] text-gray-400">
          Reporting Status:{" "}
          <strong className="text-[#0aad0a]">{reportingStatus}%</strong>
        </span>
      )} */}
    </div>
    <div className="divide-y divide-gray-100">
      {locations.map((loc) => (
        <LocationRow key={loc.id} {...loc} />
      ))}
    </div>
  </div>
);

export default MealLocationList;