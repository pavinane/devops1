import DinnerCard from "./DinnerCard";
import StandardMealCard from "./StandardMealCard";
import { useMediaQueryValues } from "../../components/commonComponents/MediaQueryContext";

const MealGrid = ({ meals = [] }) => {
  const { isMobile } = useMediaQueryValues();
  const standard = meals.filter((m) => m.id !== "dinner");
  const dinner   = meals.find((m) => m.id === "dinner");

  return (
    <div className="flex flex-col gap-4">
      <div className={`grid gap-4 ${isMobile ? "grid-cols-1" : "grid-cols-2"}`}>
        {standard.map((meal) => (
          <StandardMealCard key={meal.id} meal={meal} />
        ))}
      </div>
      {dinner && <DinnerCard meal={dinner} />}
    </div>
  );
};

export default MealGrid;