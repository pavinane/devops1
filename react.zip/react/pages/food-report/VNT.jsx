const VNT = ({ veg, nonVeg }) => (
  <span className="mono text-sm tabular-nums">
    <span className="text-[#0aad0a] font-medium">V: {veg}</span>
    {"  "}
    <span className="text-red-600 font-semibold">NV: {nonVeg}</span>
    {"  "}
    <span className="text-[#0aad0a] font-bold">T: {veg + nonVeg}</span>
  </span>
);

export default VNT