import { useState } from "react";
import axios from "axios";
import { useSelector } from "react-redux";
import SelectInput from "../../components/commonComponents/SelectInput";
import CustomDate from "../../components/commonComponents/CustomDate";
import FoodReportIcon from "./FoodReportIcon";
import { useMediaQueryValues } from "../../components/commonComponents/MediaQueryContext";

const FilterBarFoodReport = ({
  date,
  buildings = [],
  rooms = [],
  selectedBuilding,
  selectedRoom,
  onDateChange,
  onBuildingChange,
  onRoomChange,
}) => {
  const [openCalendar, setOpenCalendar] = useState(null);
  const [exporting, setExporting] = useState(null);
  const { isMobile } = useMediaQueryValues();
  const { token } = useSelector((state) => state?.user);

  const selectedBuildingOpt = buildings.find((b) => b.value === selectedBuilding) ?? buildings[0] ?? null;
  const selectedRoomOpt     = rooms.find((r) => r.value === selectedRoom) ?? rooms[0] ?? null;

  const dateValue = date ? new Date(date + "T00:00:00") : null;

  const handleDateChange = (dateObj) => {
    if (!dateObj) return;
    onDateChange?.(dateObj.toISOString().slice(0, 10));
  };

  const handleExport = async (format) => {
    setExporting(format);
    try {
      const payload = { format };
      if (date) payload.date = date;
      if (selectedBuilding) payload.building_id = selectedBuilding;
      if (selectedRoom) payload.room_id = selectedRoom;

      const response = await axios.post("/api/admin/food-report/export", payload, {
        responseType: "blob",
        headers: { Authorization: `Bearer ${token}` },
      });

      const ext = format === "xlsx" ? "xlsx" : "pdf";
      const url = URL.createObjectURL(response.data);
      const a = document.createElement("a");
      a.href = url;
      a.download = `food-report-${date ?? "export"}.${ext}`;
      a.click();
      URL.revokeObjectURL(url);
    } catch {
    } finally {
      setExporting(null);
    }
  };

  return (
    <div className="bg-white border border-gray-200 rounded-2xl pt-4 px-3 pb-4 shadow-sm">
      <div className={`${isMobile ? "flex flex-col gap-3" : "flex flex-wrap gap-4"}` }>

        <div className={isMobile ? "w-full" : "flex flex-col gap-1 min-w-[200px]"}>
          <label className="block mb-2 font-medium text-text-black1 text-[16px]">
            Date
          </label>
          <div className="relative flex items-center border border-gray-300 rounded-lg bg-white overflow-hidden">
            <input
              type="date"
              value={date}
              onChange={(e) => onDateChange?.(e.target.value)}
              min={new Date().toISOString().split("T")[0]}
              className="w-full p-3 text-sm text-gray-700 outline-none border-0 [&::-webkit-calendar-picker-indicator]:cursor-pointer [&::-moz-calendar-picker-indicator]:cursor-pointer"
/>
          </div>
        </div>

        <div className={isMobile ? "w-full" : "flex flex-col gap-1 min-w-[180px] flex-1"}>
          <label className="block mb-2 font-medium text-text-black1 text-[16px]">
            Building
          </label>
          <SelectInput
            name="building"
            options={buildings}
            value={selectedBuildingOpt}
            onChange={(opt) => onBuildingChange?.(opt?.value ?? null)}
            placeholder="All Buildings"
          />
        </div>

        <div className={isMobile ? "w-full" : "flex flex-col gap-1 min-w-[160px] flex-1"}>
          <label className="block mb-2 font-medium text-text-black1 text-[16px]">
            Room
          </label>
          <SelectInput
            name="room"
            options={rooms}
            value={selectedRoomOpt}
            onChange={(opt) => onRoomChange?.(opt?.value ?? null)}
            placeholder="All Rooms"
          />
        </div>

        <div className={`flex items-center gap-2 ${isMobile ? "w-full justify-end" : "pb-1"}`}>
          <button
            onClick={() => handleExport("xlsx")}
            disabled={!!exporting}
            className={`items-center gap-1.5 px-3 py-2 border border-[#0aad0a] rounded-lg text-sm font-semibold text-[#0aad0a] hover:bg-gray-50 transition cursor-pointer disabled:opacity-60 ${isMobile ? "flex-1" : ""}`}
          >
            <FoodReportIcon name="excel" /> {exporting === "xlsx" ? "Exporting…" : "Excel"}
          </button>
          <button
            onClick={() => handleExport("pdf")}
            disabled={!!exporting}
            className={`items-center gap-1.5 px-3 py-2 border border-red-500 rounded-lg text-sm font-semibold text-red-600 hover:bg-red-50 transition cursor-pointer disabled:opacity-60 ${isMobile ? "flex-1" : ""}`}
          >
            <FoodReportIcon name="picture_as_pdf" /> {exporting === "pdf" ? "Exporting…" : "PDF"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default FilterBarFoodReport;