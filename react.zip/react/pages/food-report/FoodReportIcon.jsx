import leafSvg        from "../../assets/icons/leaf.svg";
import mealSvg        from "../../assets/icons/meal.svg";
import barChartSvg    from "../../assets/icons/bar-chart.svg";
import sunSvg         from "../../assets/icons/sun-2.svg";
import calendarSvg    from "../../assets/icons/calendar.svg";
import pdfSvg         from "../../assets/icons/pdf.svg";
import buildingSvg    from "../../assets/icons/apartment-building.svg";
import conferenceSvg  from "../../assets/icons/conference-room.svg";
import bedSvg         from "../../assets/icons/bed.svg";
import expandSvg      from "../../assets/icons/expand-more.svg";
import moonsvg      from "../../assets/icons/moon.svg";
import excelsvg      from "../../assets/icons/excel.svg";

const MAP = {
  eco:                leafSvg,
  set_meal:           mealSvg,
  restaurant:         mealSvg,
  bar_chart:          barChartSvg,
  table_chart:        barChartSvg,
  sun:                sunSvg,
  moon:               moonsvg,
  excel:              excelsvg,
  nightlight:         bedSvg,
  calendar_today:     calendarSvg,
  picture_as_pdf:     pdfSvg,
  store:              buildingSvg,
  apartment:          buildingSvg,
  groups:             conferenceSvg,
  meeting_room:       conferenceSvg,
  arrow_drop_down:    expandSvg,
  play_arrow:         expandSvg,
  keyboard_arrow_down: expandSvg,
  keyboard_arrow_up:  expandSvg,
};

const FoodReportIcon = ({ name, className = "" }) => {
  const src = MAP[name];
  if (!src) return null;

  const rotate = name === "keyboard_arrow_up" || name === "play_arrow" ? "rotate-180" : "";

  return (
    <img
      src={src}
      alt={name}
      className={`inline-block ${rotate} ${className}`}
      style={{ width: "1em", height: "1em" }}
    />
  );
};

export default FoodReportIcon;
