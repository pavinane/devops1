const StatusPill = ({ status, label }) => {
  const styles = {
    pending:  "bg-amber-100  text-amber-800  border-amber-200",
    ready:    "bg-emerald-100 text-emerald-800 border-emerald-200",
    upcoming: "bg-sky-100    text-sky-800     border-sky-200",
  };
  return (
    <span
      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold border ${
        styles[status] ?? "bg-gray-100 text-gray-700 border-gray-200"
      }`}
    >
      {label}
    </span>
  );
};
export default StatusPill;