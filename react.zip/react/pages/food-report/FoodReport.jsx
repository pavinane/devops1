import { useEffect, useState } from "react";
import FilterBarFoodReport from "./FilterBarFoodReport";
import MealGrid from "./MealGrid";
import RoomDetailAccordion from "./RoomDetailAccordion";
import SummaryCards from "./SummaryCards";
import { useSelector } from "react-redux";
import { useReusableMutation } from "../../customHooks/useDataQuery";
import PageHeader from "../../components/commonComponents/PageHeader";

const todayISO = () => new Date().toISOString().slice(0, 10);

const roomBadgeStatus = (roomEntry) => {
    const meals = roomEntry.meals ?? {};
    let hasVeg = false;
    let hasNonVeg = false;
    Object.values(meals).forEach(({ veg, non_veg }) => {
        if (veg > 0) hasVeg = true;
        if (non_veg > 0) hasNonVeg = true;
    });
    if (hasVeg && hasNonVeg) return "both";
    if (hasVeg) return "veg";
    if (hasNonVeg) return "nonveg";
    return "none";
};

const mealLabel = (mealObj) => {
    if (!mealObj) return null;
    const { veg, non_veg } = mealObj;
    if (!veg && !non_veg) return null;
    return `V:${veg} NV:${non_veg}`;
};

const transformApiData = (apiData) => {
    const {
        buildings = [],
        rooms = [],
        buildingSummaries = [],
        mealBreakdown = {},
        totalVeg = 0,
        totalNonVeg = 0,
    } = apiData;

    const buildingOptions = [
        { value: null, label: "All Buildings" },
        ...buildings.map((b) => ({ value: b.id, label: b.name })),
    ];
    const roomOptions = [
        { value: null, label: "All Rooms" },
        ...rooms.map((r) => ({ value: r.id, label: `Room ${r.room_number}` })),
    ];

    const summary = {
        totalVeg,
        totalNonVeg,
        grandTotal: totalVeg + totalNonVeg,
    };

    const roomBuildings = buildingSummaries.map((bs) => ({
        id: String(bs.building.id),
        name: bs.building.name,
        totalRooms: bs.room_count,
        reportedRooms: bs.rooms_with_data,
        rooms: bs.rooms.map((r) => ({
            id: String(r.room.id),
            name: `Room ${r.room.room_number}`,
            status: roomBadgeStatus(r),
            breakfast: mealLabel(r.meals?.breakfast),
            lunch: mealLabel(r.meals?.lunch),
            dinner: mealLabel(r.meals?.dinner),
        })),
    }));

    const meal_times = mealBreakdown?.meal_times ?? {};

    const buildingLocations = (mealKey) => {
        const mealData = meal_times[mealKey];
        if (!mealData) return [];
        return (mealData.buildings ?? []).map((b) => ({
            id: b.building_name,
            name: b.building_name,
            veg: b.rooms.reduce((s, r) => s + r.veg, 0),
            nonVeg: b.rooms.reduce((s, r) => s + r.non_veg, 0),
        }));
    };

    const participationLabel = (mealKey) => {
        const p = meal_times[mealKey]?.participation;
        if (!p) return null;
        const pct =
            p.registered > 0 ? Math.round((p.ordered / p.registered) * 100) : 0;
        return pct;
    };

    const mealTotals = (mealKey) => {
        const rt = meal_times[mealKey]?.room_totals;
        return { veg: rt?.veg ?? 0, nonVeg: rt?.non_veg ?? 0 };
    };

    const meals = [
        {
            id: "breakfast",
            label: "Breakfast",
            icon: "sun",
            reportingStatus: participationLabel("breakfast"),
            locations: buildingLocations("breakfast"),
            currentEst: mealTotals("breakfast"),
        },
        {
            id: "lunch",
            label: "Lunch",
            icon: "sun",
            reportingStatus: participationLabel("lunch"),
            locations: buildingLocations("lunch"),
            currentEst: mealTotals("lunch"),
        },
        {
            id: "dinner",
            label: "Dinner",
            icon: "moon",
            locations: buildingLocations("dinner"),
            currentEst: mealTotals("dinner"),
        },
    ];

    return { buildingOptions, roomOptions, summary, roomBuildings, meals };
};

const FoodReport = ({ onExport }) => {
    const { token } = useSelector((state) => state?.user);

    const [date, setDate] = useState(todayISO());
    const [buildingId, setBuildingId] = useState(null);
    const [roomId, setRoomId] = useState(null);
    const [accordionOpen, setAccordion] = useState(false);
    const [reportData, setReportData] = useState(null);
    const [buildingOpts, setBuildingOpts] = useState([{ value: null, label: "All Buildings" }]);
    const [roomOpts, setRoomOpts] = useState([{ value: null, label: "All Rooms" }]);

    const { mutate: fetchFoodReport, isPending } = useReusableMutation({
        onSuccess: (res) => {
            if (res?.success && res?.data) {
                const transformed = transformApiData(res.data);
                setBuildingOpts(transformed.buildingOptions);
                setRoomOpts(transformed.roomOptions);
                setReportData(transformed);
            }
        },
        onError: () => {},
    });

    const loadReport = ({ date: d, buildingId: b, roomId: r }) => {
        const params = new URLSearchParams({ date: d });
        if (b) params.append("building_id", b);
        if (r) params.append("room_id", r);
        fetchFoodReport({
            endPoint: `api/admin/food-report?${params.toString()}`,
            method: "GET",
            token,
        });
    };

    useEffect(() => {
        loadReport({ date, buildingId, roomId });
    }, []);

    const handleRefresh = () => loadReport({ date, buildingId, roomId });

    const handleDateChange = (val) => {
        setDate(val);
        loadReport({ date: val, buildingId, roomId });
    };

    const handleBuildingChange = (val) => {
        setBuildingId(val);
        setRoomId(null);
        loadReport({ date, buildingId: val, roomId: null });
    };

    const handleRoomChange = (val) => {
        setRoomId(val);
        loadReport({ date, buildingId, roomId: val });
    };

    return (
        <div className="">
            <div className="flex flex-col gap-4">
                <PageHeader title="Food Report" />
                <FilterBarFoodReport
                    date={date}
                    buildings={buildingOpts}
                    rooms={roomOpts}
                    selectedBuilding={buildingId}
                    selectedRoom={roomId}
                    onDateChange={handleDateChange}
                    onBuildingChange={handleBuildingChange}
                    onRoomChange={handleRoomChange}
                    onRefresh={handleRefresh}
                />

                {isPending && (
                    <div className="flex items-center justify-center py-10 text-sm text-gray-400">
                        Loading…
                    </div>
                )}

                {!isPending && reportData && (
                    <>
                        <SummaryCards
                            totalVeg={reportData.summary.totalVeg}
                            totalNonVeg={reportData.summary.totalNonVeg}
                            grandTotal={reportData.summary.grandTotal}
                        />

                        <MealGrid meals={reportData.meals} />

                        <RoomDetailAccordion
                            expanded={accordionOpen}
                            onToggle={() => setAccordion((v) => !v)}
                            buildings={reportData.roomBuildings}
                        />
                    </>
                )}
            </div>
        </div>
    );
};

export default FoodReport;
