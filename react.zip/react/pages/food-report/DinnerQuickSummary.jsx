import FoodReportIcon from "./FoodReportIcon";

const DinnerQuickSummary = ({ allBuildings, guestList }) => (
  <div>
    <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-3 px-1">
      Quick Summary
    </p>
    <div className="space-y-2">
      <div className="flex items-center gap-3 p-2 rounded-xl hover:bg-gray-50 transition">
        <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center">
          <FoodReportIcon name="store" className="text-gray-500 text-[17px]" />
        </div>
        <div>
          <p className="text-sm font-semibold text-gray-700">All Buildings</p>
          <p className="text-[11px] text-gray-400">
            Total Orders: {allBuildings.totalOrders}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-3 p-2 rounded-xl hover:bg-gray-50 transition">
        <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center">
          <FoodReportIcon name="groups" className="text-gray-500 text-[17px]" />
        </div>
        <div>
          <p className="text-sm font-semibold text-gray-700">Guest List</p>
          <p className="text-[11px] text-gray-400">
            {guestList.specialRequests} Special Requests
          </p>
        </div>
      </div>
    </div>
  </div>
);

export default DinnerQuickSummary;