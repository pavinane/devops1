const ProgressBar = ({ label, percent, color }) => (
  <div className="flex-1 min-w-0">
    <div className="flex justify-between items-center mb-1">
      <span className="text-xs font-medium text-gray-600">{label}</span>
      <span
        className="text-xs font-bold mono"
        style={{ color }}
      >
        {percent}% Prepared
      </span>
    </div>
    <div className="h-1.5 rounded-full bg-gray-200 overflow-hidden">
      <div
        className="h-full rounded-full transition-all duration-700"
        style={{ width: `${percent}%`, backgroundColor: color }}
      />
    </div>
  </div>
);

export default ProgressBar