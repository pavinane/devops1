import MealLocationList from "../food-report/MealLocationList";
import MealCardHeader from "../food-report/MeaslCardHeader";

const StandardMealCard = ({ meal }) => {

  return (
    <div
      className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow fade-up"
      style={{ animationDelay: "60ms" }}
    >
      <div className="px-5 pt-4 pb-2 bg-[#0aad0a]">
        <MealCardHeader
          icon={meal.icon}
          label={meal.label}
          status={meal.status}
          statusLabel={meal.statusLabel}
          roomSummary={meal.roomSummary}
          reportingStatus={null}
          currentEst={meal.currentEst}
        />
      </div>
      <MealLocationList
        reportingStatus={meal.reportingStatus}
        locations={meal.locations || []}
      />
      <div className="h-3" />
    </div>
  );
};

export default StandardMealCard;