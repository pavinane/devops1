import MealRow from "./MealRow";
import RoomStatusBadge from "./RoomStatusBadge";

const RoomCard = ({ name, status = "none", breakfast, lunch, dinner }) => (
  <div className="bg-white border border-gray-200 rounded-xl p-3.5 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200">
    <div className="flex items-center justify-between mb-2.5 pb-2 border-b border-gray-100">
      <span className="text-sm font-bold text-gray-800">{name}</span>
      <RoomStatusBadge status={status} />
    </div>
    <div className="space-y-0">
      <MealRow label="Breakfast" value={breakfast} />
      <MealRow label="Lunch"     value={lunch}     />
      <MealRow label="Dinner"    value={dinner}    />
    </div>
  </div>
);

export default RoomCard;