import React, { useEffect, useState } from "react";
import Modal from "../../components/commonComponents/Modal";
import { useMediaQueryValues } from "../../components/commonComponents/MediaQueryContext";
import { useReusableMutation } from "../../customHooks/useDataQuery";
import { useSelector } from "react-redux";
import { useToast } from "../../components/ToastContext";
import PrimaryButton from "../../components/commonComponents/PrimaryButton";
import PageHeader from "../../components/commonComponents/PageHeader";
import DataTable from "../../components/commonComponents/DataTable";
import ReactPaginateModule from "react-paginate";
const BASE_URL = `${import.meta.env.AWS_IMAGE_URL}/`;


const formatDate = (date) => {
  const d = new Date(date);
  return d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }).replace(/ /g, " ");
};

const formatTime = (date) => {
  return new Date(date).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
};

const getInitials = (name) =>
  name?.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2) || "U";

export default function RoomGroup() {
  const ReactPaginate = ReactPaginateModule.default;
  const { success, error } = useToast();
  const [categories, setCategories] = useState([]);
  const { isMobile, isTablet, isDesktop } = useMediaQueryValues();
  const [requests, setRequests] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ category: "", quantity: 1, remarks: "", attachment: null });
  const [errors, setErrors] = useState({});
  const [fileName, setFileName] = useState("No file chosen");
  const [paginationData, setPaginationData] = useState({ pageSize: 10, pageIndex: 0, totalPages: 0, totalData: 0 });
  const [searchTerm, setSearchTerm] = useState("");
  const { token, role } = useSelector((state) => state.user);
  const [deleteConfirm, setDeleteConfirm] = useState(false);
  const [deleteId, setDeleteId] = useState("");
  const [viewModal, setViewModal] = useState(null);
  const [previewImage, setPreviewImage] = useState(null);
  const [saved, setSaved] = useState(false);

  const columns = [
    {
      key: "poster",
      label: "USER",
      render: (value) => <p className=" capitalize">{value?.name}</p>,
    },
    {
      key: "category",
      label: "CATEGORY",
      render: (value) => <p>{value?.name}</p>,
    },
    {
      key: "quantity",
      label: "QUANTITY",
    },
    {
      key: "description",
      label: "DESCRIPTION",
    },
    {
      key: "remarks",
      label: "REMARKS",
    },
    {
      key: "created_at",
      label: "CREATED",
      render: (value) => <p>{formatDate(value)}</p>,
    },
    {
      key: "created_at_time",
      label: "TIME",

      render: (_, row) => <p>{formatTime(row.created_at)}</p>,
    },
    {
      key: "status",
      label: "STATUS",
      render: (value) => {

        return (
          <span className={`px-3 py-1 rounded-full text-xs capitalize font-medium ${value === "approved" ?
            "bg-green-100 text-green-700" :
            value === "rejected" ?
              "bg-red-100 text-red-700" :
              "bg-yellow-100 text-yellow-700"
            }`}>
            {value}
          </span>
        )
      }



    },
    {
      key: "action",
      label: "ACTIONS",
      render: (_, row) => {
        const req = row?.originalData ?? row;
        return (
          <div className="flex items-center gap-2">

            <button
              onClick={(e) => {

                e.stopPropagation();
                setDeleteId(req.id);
                setDeleteConfirm(true);


              }}
              className="w-8 h-8 cursor-pointer rounded-full bg-red-50 hover:bg-red-100 flex items-center justify-center transition-colors"
              title="Delete"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="3 6 5 6 21 6" />
                <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
                <path d="M10 11v6M14 11v6" />
                <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
              </svg>
            </button>
          </div>
        );
      },
    },
  ];




  const openModal = () => {
    setForm({ category: "", quantity: 1, remarks: "", attachment: null });
    setFileName("No file chosen");
    setErrors({});
    setShowModal(true);
  };

  const closeModal = () => setShowModal(false);

  const deleteClose = () => {
    setDeleteConfirm(false);
    setDeleteId("")
  }

  const validate = () => {
    const e = {};
    if (!form.category) e.category = "Category is required";
    if (!form.quantity || form.quantity < 1) e.quantity = "Quantity must be at least 1";
    return e;
  };

  // const handleFileChange = (e) => {
  //   const file = e.target.files[0];
  //   if (file) { setForm((p) => ({ ...p, attachment: file })); setFileName(file.name); }
  // };

  // Add this to your component's function handlers

const handleFileChange = (e) => {
  const file = e.target.files?.[0];
  
  if (!file) {
    setForm((p) => ({ ...p, attachment: null }));
    setFileName("No file chosen");
    return;
  }

  const allowedFormats = ["image/jpeg", "image/png", "image/webp"];
  const allowedExtensions = [".jpg", ".jpeg", ".png", ".webp"];

  // Validate file type by MIME type
  if (!allowedFormats.includes(file.type)) {
    error("Invalid file type. Please upload only JPG, PNG, or WebP images.");
    e.target.value = ""; 
    setFileName("No file chosen");
    setForm((p) => ({ ...p, attachment: null }));
    return;
  }


  const fileName = file.name.toLowerCase();
  const hasValidExtension = allowedExtensions.some((ext) =>
    fileName.endsWith(ext)
  );

  if (!hasValidExtension) {
    error("Invalid file extension. Please upload only JPG, PNG, or WebP images.");
    e.target.value = ""; 
    setFileName("No file chosen");
    setForm((p) => ({ ...p, attachment: null }));
    return;
  }

  const maxFileSize = 5 * 1024 * 1024; // 5MB
  if (file.size > maxFileSize) {
    error("File size exceeds 5MB. Please choose a smaller image.");
    e.target.value = "";
    setFileName("No file chosen");
    setForm((p) => ({ ...p, attachment: null }));
    return;
  }

  setForm((p) => ({ ...p, attachment: file }));
  setFileName(file.name);
};


  const { mutate: deleteMealSetting } =
    useReusableMutation({
      onSuccess: (data) => {
        success(data?.message);
        getUserData();
        getRequestData()
        setDeleteConfirm(false)
      },
      onError: (err) => {
        error(err?.response?.data?.message);
        setDeleteConfirm(false)
      },
    });

  const handleDelete = (id) => {
    const payload = {
      "id": id
    };

    deleteMealSetting({
      endPoint: "api/member/room-group/delete",
      method: "DELETE",
      payload,
      token,
    });
  };


  const { mutate: getCategory, isPending: userPending } =
    useReusableMutation({
      onSuccess: (data) => {

        const setting = data?.data;

        setCategories(setting);

      },
      onError: (err) => {
        const apiErrors = err?.response?.data?.errors;

        const firstError =
          apiErrors && Object.values(apiErrors)[0];

        error(firstError || "Something went wrong");
      },
    });

  const getUserData = (edit) => {

    getCategory({
      endPoint: "api/member/room-group/select",
      method: "GET",
      token,
    })
  };

  const { mutate: saveMealSetting } = useReusableMutation({
    onSuccess: (data) => {
     

      closeModal();
      success(data?.message);
      getRequestData()

      setTimeout(() => {
        setSaved(false);
      }, 2000);
    },
    onError: (err) => {
      const apiErrors = err?.response?.data?.errors;

      if (apiErrors) {
        setErrors({
          category: apiErrors.thing_category_id?.[0],
          quantity: apiErrors.quantity?.[0],
        });
        return;
      }

      error("Something went wrong");
    },
  });

  function handleSubmit() {

    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
   setSaved(true);
    const payload = {
      "thing_category_id": categories.find(c => c.name === form.category)?.id,
      "quantity": Number(form.quantity),
      "description": form.remarks,
      "attachment": form.attachment
    };

  


    saveMealSetting({
      endPoint: "api/member/room-group/store",
      method: "POST",
      payload,
      token,
    });
  }


  const { mutate: getRequest } =
    useReusableMutation({
      onSuccess: (data) => {
        const requestData = data?.data;
        setRequests(requestData?.group);
        setPaginationData((prev) => ({
          ...prev,
          totalPages: requestData?.group?.pagination?.last_page ?? 0,
          totalData: requestData?.group?.pagination?.total ?? 0,
        }))
      },
      onError: (err) => {
        error(err)
      },
    });



  const handleRowClick = (row) => {
    const req = row?.originalData ?? row;
    setViewModal(req);
  };


  const getRequestData = () => {
    const payloadValue = {
      per_page: paginationData?.pageSize || 10,
      page: paginationData?.pageIndex + 1,

    }
    getRequest({
      endPoint: "api/member/room-group/index",
      method: "GET",
      payload: payloadValue,
      token,
    })
  };


  useEffect(() => {
    getUserData();
    getRequestData()
  }, []);


  return (
    <div className=" bg-white font-sans relative mb-8">
      <div className={` ${isMobile ? "px-4 py-5" : " px-6 py-8"}`}>

        <PageHeader title="Room Group" />

        {/* <div className="mb-5">
          <p className="text-4xs font-semibold text-gray-400 tracking-widest uppercase mb-1">
            Community Board
          </p>
        </div> */}

        <div className={`flex ${isMobile ? "flex-col gap-3" : "items-start justify-between"} mb-2`}>
          <div>

            <h1 className={`font-bold text-gray-900 ${isMobile ? "text-2xl" : "text-xl"}`}>
              {requests?.name}
            </h1>
            <p className="text-sm text-gray-500 mt-1">
              {requests?.members?.length} member{requests?.members?.length !== 1 ? "s" : ""} in this room
            </p>
          </div>

          {
            isDesktop ?
              <PrimaryButton
                onClick={openModal}
                title="New Request"
                width={isMobile ? "w-full" : "w-auto"}
                bgColor="btn-primary"
                btnBorder=""
                textColor="text-white"
                textSize="text-sm"
                customClass="rounded-lg font-semibold"
                icon={
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <line x1="12" y1="5" x2="12" y2="19" />
                    <line x1="5" y1="12" x2="19" y2="12" />
                  </svg>
                }
              />
              :
              <button
                onClick={openModal}
                title="New Request"
                className="fixed bottom-24 right-5 z-30 w-14 h-14 rounded-full btn-primary text-white shadow-lg shadow-black/20 flex items-center justify-center active:scale-95 transition-transform"
              >
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="12" y1="5" x2="12" y2="19" />
                  <line x1="5" y1="12" x2="19" y2="12" />
                </svg>
              </button>
          }

        </div>

        <div className="mt-6 space-y-4">
          {/* {requests.posts?.length === 0 && (
            <div className="text-center py-16 text-gray-400 text-sm">
              No requests yet.
            </div>
          )} */}



          {
            isDesktop ? (
              <DataTable
                searchable={false}
                onRowClick={handleRowClick}
                columns={columns}
                data={requests?.posts}
                pageSize={10}
                pagination={true}
                paginationData={paginationData}
                setPaginationData={setPaginationData}
                showCheckbox={false}
                // tableHeight={
                //     tableData > 9 ? "min-h[500px]" : ""
                // }
                showDot={false}

              />
            ) : (
              <div className="relative mb-12  flex flex-col gap-4">
                {requests?.posts?.map((req) => {

                  return (
                    <div key={req.id} className="border border-gray-200 rounded-xl p-4"
                      onClick={
                        () =>
                          handleRowClick(req)
                      }
                    >

                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className="w-4 h-4 p-4 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center text-sm font-bold flex-shrink-0">
                            {getInitials(req?.poster?.name)}
                          </div>
                          <span className="text-sm font-semibold text-gray-800">{req.user}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className={`text-xs font-semibold border
                             ${req.status === "approved" ?
                              "bg-green-100 text-green-700" :
                              req.status === "rejected" ?
                                "bg-red-100 text-red-700" :
                                "bg-yellow-100 text-yellow-700"
                            }
                            
                            
                          px-3 py-1 rounded-full capitalize`}>
                            {req.status}
                          </span>
                   
                          <PrimaryButton
                            title="Delete"
                            onClick={(e) => {
                              e.stopPropagation();
                              setDeleteConfirm(true)
                              // handleDelete(req.id)
                              setDeleteId(req.id)
                            }}
                            bgColor="bg-white"
                            textColor="text-red-500"
                            btnBorder="border border-red-400"
                            textSize="text-xs"
                            customClass="rounded-full hover:bg-red-50 !p-2 !w-20 font-semibold"
                          />
                        </div>
                      </div>


                      <div className={`grid gap-3 mb-3 ${isMobile ? "grid-cols-2" : "grid-cols-2 sm:grid-cols-4"}`}>
                        <div>
                          <p className="text-xs text-gray-400 mb-0.5">Requested Item</p>
                          <p className="text-sm font-semibold text-gray-800">{req.category?.name}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-400 mb-0.5">Quantity</p>
                          <p className="text-sm font-semibold text-gray-800">{req.quantity}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-400 mb-0.5">Requested On</p>
                          <p className="text-sm font-semibold text-gray-800">{formatDate(req.created_at)}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-400 mb-0.5">Time</p>
                          <p className="text-sm font-semibold text-gray-800">{formatTime(req.created_at)}</p>
                        </div>
                      </div>

                      {req.description && (
                        <p className="text-sm text-gray-600 mt-2">
                          <span className="font-semibold text-gray-800">Remarks:</span> {req.description}
                        </p>
                      )}
                    </div>
                  )
                }
                )}

                {paginationData.totalPages > 0 && (
                  <div className="fixed bottom-12 left-0 w-full bg-white">
                    <div className="flex  justify-between px-4 items-center  h-18">


                      <div className="flex items-center justify-center m-0 ">
                        <p className="text-center font-regular text-sm  m-0">
                          Showing {paginationData.totalData === 0 ? 0 : (paginationData.pageIndex * paginationData.pageSize) + 1} to {Math.min((paginationData.pageIndex + 1) * paginationData.pageSize, paginationData.totalData)} of {paginationData.totalData} entries
                        </p>
                      </div>
                      <div className="flex justify-center ">

                        <ReactPaginate
                          breakLabel="..."
                          nextLabel=">"
                          previousLabel="<"
                          pageCount={paginationData.totalPages}
                          forcePage={paginationData.pageIndex}
                          onPageChange={(selectedItem) => {
                            setPaginationData((prev) => ({
                              ...prev,
                              pageIndex: selectedItem.selected,
                            }));
                          }}
                          containerClassName="flex items-center gap-2"
                          pageClassName="border rounded-full"
                          pageLinkClassName="!w-[23px] h-[23px] flex items-center justify-center"
                          activeClassName="bg-[#099309] text-white border-[#099309]"
                          previousClassName=" rounded-lg"
                          previousLinkClassName="px-3 py-2 block"
                          nextClassName=" rounded-lg"
                          nextLinkClassName="px-3 py-2 block"
                          disabledClassName="opacity-50 cursor-not-allowed"
                        />
                      </div>
                    </div>

                  </div>
                )}

              </div>
            )
          }
        </div>
      </div>

      <Modal
        isOpen={showModal}
        onClose={closeModal}
        size="medium"
        width="w-full max-w-md"
        showCloseButton={true}
        customClass="overflow-hidden  mx-4"
        title="New Service Request"
        outSideClick={false}
      >
        <div className={`${isMobile ? "px-4 py-4" : "px-6 py-5"} space-y-5`}>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">
              Category <span className="text-red-500">*</span>
            </label>
            <select
              value={form.category}
              onChange={(e) => { setForm((p) => ({ ...p, category: e.target.value })); setErrors((p) => ({ ...p, category: "" })); }}
              className={`w-full cursor-pointer px-3 py-2.5 text-sm border rounded-lg outline-none  bg-white
                ${errors.category ? "border-red-400" : "border-gray-300"}`}
            >
              <option value="">Select category...</option>
              {categories?.map((c) => <option key={c.id} value={c.name}>{c.name}</option>)}
            </select>
            {errors.category && <p className="text-xs text-red-500 mt-1">{errors.category}</p>}
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">
              Quantity <span className="text-red-500">*</span>
            </label>
            <input
              type="number"
              min="1"
              max="99999"
              value={form.quantity}
              onChange={(e) => {
                let val = e.target.value;
                if (val.length > 5) val = val.slice(0, 5);
                setForm((p) => ({ ...p, quantity: val }));
                setErrors((p) => ({ ...p, quantity: "" }));
              }}
              className={`w-full px-3 py-2.5 text-sm border rounded-lg outline-none transition-all
                ${errors.quantity ? "border-red-400" : "border-gray-300"}`}
            />
            {errors.quantity && <p className="text-xs text-red-500 mt-1">{errors.quantity}</p>}
          </div>


          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">
              Remarks <span className="text-gray-400 font-normal">(optional)</span>
            </label>
            <textarea
              rows={isMobile ? 3 : 4}
              placeholder="Add any notes..."
              value={form.remarks}
              onChange={(e) => setForm((p) => ({ ...p, remarks: e.target.value }))}
              className="w-full px-3 py-2.5 text-sm border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-teal-200 focus:border-teal-500 transition-all resize-none"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">
              Attachment <span className="text-gray-400 font-normal">(optional)</span>
            </label>
            <div className="flex items-center border border-gray-300 rounded-lg overflow-hidden">
              <label className="cursor-pointer bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm font-medium px-4 py-2.5 transition-colors flex-shrink-0">
                Choose file
                <input type="file" className="hidden" onChange={handleFileChange} />
              </label>
              <span className="px-3 text-sm text-gray-400 truncate  cursor-pointer">{fileName}</span>
            </div>
          </div>
        </div>

        {/* Modal footer */}
        <div className={`flex items-center gap-3 border-t border-gray-100 justify-between
          ${isMobile ? " px-4 py-4 flex-row-reverse " : "px-6 py-4"}
        `}>


          <PrimaryButton
            title="Cancel"
            width="w-full"
            onClick={closeModal}
            bgColor="bg-white"
            textColor="text-gray-600"
            btnBorder="border border-gray-200"
            textSize="text-sm"
            customClass={`rounded-lg hover:bg-gray-50 font-semibold ${isMobile ? "w-full order-2" : ""
              }`}
          />
          <PrimaryButton
            width="w-full"
            title={saved ? "Saved!" : "Create Request"}
            disable={saved}
            onClick={handleSubmit}
            bgColor="btn-primary"
            btnBorder=""
            textColor="text-white"
            textSize="text-sm"
            customClass={`rounded-lg font-semibold ${isMobile ? "w-full order-1" : ""
              }`}
          />
        </div>
      </Modal>


      <Modal
        isOpen={deleteConfirm}
        onClose={() => {
          setDeleteConfirm(false);
          setDeleteId("")
        }}
        size="medium"
        width="w-full max-w-md"
        showCloseButton={true}
        customClass="overflow-hidden  mx-4 !text-center"
        // title=""
        outSideClick={false}
      >

        <h1>Are you sure want to Delete?</h1>

        <div className={`flex justify-between gap-8 mt-10 ${isMobile && "flex-row-reverse "}`}>


          <PrimaryButton
            title="Cancel"
            width="w-full"
            onClick={deleteClose}
            bgColor="bg-white"
            textColor="text-gray-600"
            btnBorder="border border-gray-200"
            textSize="text-sm"
            customClass={`rounded-lg hover:bg-gray-50 font-semibold ${isMobile ? "w-full order-2" : ""
              }`}
          />
          <PrimaryButton
            width="w-full"
            title="Confirm"
            onClick={() => handleDelete(deleteId)}
            bgColor="bg-red-400"
            btnBorder=""
            textColor="text-white"
            textSize="text-sm"
            customClass={`rounded-lg font-semibold
               ${isMobile ? "w-full order-1" : ""
              }`}
          />

        </div>
      </Modal>



      <Modal
        isOpen={!!viewModal}
        onClose={() => setViewModal(null)}
        size="medium"
        width="w-full max-w-md"
        showCloseButton={true}
        customClass="overflow-hidden mx-4"
        title="Request Details"
        outSideClick={false}
      >
        <>


          {viewModal && (
            <div className={`${isMobile ? "px-4 py-4" : "px-6 py-5"} space-y-4`}>


              <div className="flex items-center gap-3 pb-4 border-b border-gray-100">
                <div className="w-10 h-10 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center text-sm font-bold flex-shrink-0">
                  {getInitials(viewModal?.poster?.name)}
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-800 capitalize">{viewModal?.poster?.name}</p>
                  <p className="text-xs text-gray-400">Requested by</p>
                </div>
                <span className={`ml-auto text-xs font-semibold px-3 py-1 rounded-full capitalize
          ${viewModal.status === "approved" ? "bg-green-100 text-green-700" :
                    viewModal.status === "rejected" ? "bg-red-100 text-red-700" :
                      "bg-yellow-100 text-yellow-700"}`}>
                  {viewModal.status}
                </span>
              </div>


              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-gray-400 mb-0.5">Category</p>
                  <p className="text-sm font-semibold text-gray-800">{viewModal?.category?.name ?? "—"}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 mb-0.5">Quantity</p>
                  <p className="text-sm font-semibold text-gray-800">{viewModal?.quantity ?? "—"}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 mb-0.5">Date</p>
                  <p className="text-sm font-semibold text-gray-800">{formatDate(viewModal?.created_at)}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 mb-0.5">Time</p>
                  <p className="text-sm font-semibold text-gray-800">{formatTime(viewModal?.created_at)}</p>
                </div>
              </div>


              {viewModal?.description && (
                <div className="pt-2 border-t border-gray-100">
                  <p className="text-xs text-gray-400 mb-1">Remarks</p>
                  <p className="text-sm text-gray-700">{viewModal.description}</p>
                </div>
              )}


              {viewModal?.attachment_path && (
                <div className="pt-2 border-t border-gray-100">
                  <p className="text-xs text-gray-400 mb-1">Attachment</p>
                  <img
                    src={viewModal.attachment_path}
                    alt="Attachment preview"
                    onClick={() => setPreviewImage(`${viewModal.attachment_path}`)}
                    className="w-16 h-16 object-cover rounded-lg border border-gray-200 hover:opacity-80 transition-opacity cursor-pointer"
                  />
                </div>
              )}

              {previewImage && (
                <div
                  onClick={() => setPreviewImage(null)}
                  className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4"
                >
                  <button
                    onClick={() => setPreviewImage(null)}
                    className="absolute top-4 right-4 w-9 h-9 cursor-pointer rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors"
                  >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                      <line x1="18" y1="6" x2="6" y2="18" />
                      <line x1="6" y1="6" x2="18" y2="18" />
                    </svg>
                  </button>
                  <img
                    src={previewImage}
                    alt="Full preview"
                    width={"50%"}
                    height={"50%"}
                    onClick={(e) => e.stopPropagation()}
                    className="max-w-full max-h-[90vh] object-contain rounded-lg"
                  />
                </div>
              )}



            </div>
          )}

          <div className={`border-t border-gray-100 ${isMobile ? "px-4 py-4" : "px-6 py-4"}`}>
            <PrimaryButton
              title="Close"
              width="w-full"
              onClick={() => setViewModal(null)}
              bgColor="bg-white"
              textColor="text-gray-600"
              btnBorder="border border-gray-200"
              textSize="text-sm"
              customClass="rounded-lg hover:bg-gray-50 font-semibold"
            />
          </div>

        </>


      </Modal >

    </div>
  );
}