import React, { useEffect, useState } from "react";
import TextInput from "../../components/commonComponents/TextInput";
import passIcon from "../../assets/Buttons/PasswordIcon.svg";
import passwordIcon from "../../assets/Buttons/EyeOpen.svg";
import { RegexValidations } from "../../validation/RegexValidation";
import useForm from "../../components/commonComponents/useForm";
import { useToast } from "../../components/ToastContext";
import { useReusableMutation } from "../../customHooks/useDataQuery";
import { changePasswordSchema } from "../../validation/changePasswordSchema";
import icons3d from "../../assets/icons/3dicon/Success.png";
import { useSelector } from "react-redux";
import PrimaryButton from "../../components/commonComponents/PrimaryButton";
import Modal from "../../components/commonComponents/Modal";
import SuccessModal from "../../components/commonComponents/SuccessModal";
import TooltipContainer from "../../components/commonComponents/ToolTip";

const Profile = () => {
    const { token, roles } = useSelector((state) => state.user);
    const [userDetails, setUserDetails] = useState({})
    const [isPasswordVisible, setIsPasswordVisible] = useState(false);
    const [isCurrentPasswordVisible, setIsCurrentPasswordVisible] = useState(false);
    const [isNewPasswordVisible, setIsNewPasswordVisible] = useState(false);
    const [isConfirmPasswordVisible, setIsConfirmPasswordVisible] = useState(false);
    const [showSuccessModal, setShowSuccessModal] = useState(false);
    const ChangePasswordForm = {
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
    };
    const [successText, setSuccessText] = useState("")
    const { error: showError, success } = useToast();
    const { mutate, isPending } = useReusableMutation({
        onSuccess: (data) => {
            setSuccessText(data?.message)
            setShowSuccessModal(true)
            success(data?.message)

            setTimeout(() => {
                setShowSuccessModal(false);

            }, 2000);

        },
        onError: (err) => {
            if (err?.response?.data?.message === "Validation errors occurred") {
                showError(err?.response?.data?.errors?.password)

            } else {
                showError(err?.response?.data?.message)

            }

        },
    });

    const handleSave = () => {
        const apiPayload = {
            endPoint: "api/admin/profile/password",
            method: "POST",
            payload: {
                current_password: formData?.currentPassword,
                new_password: formData?.newPassword,
                new_password_confirmation: formData?.confirmPassword,
            },
            token,

        };
        mutate(apiPayload);

    };

    const { formData, errors, updateFieldData, handleSubmit } = useForm(ChangePasswordForm, changePasswordSchema, handleSave,);

    const { mutate: userMutate } = useReusableMutation({
        onSuccess: (data) => {

            setUserDetails(data?.data)
        },
        onError: (err) => {
            showError(err?.response?.data?.message)

        },
    });

    const viewAPI = () => {

        const apiPayload = {
            endPoint: "api/auth/me",
            method: "GET",
            token
        };

        userMutate(apiPayload);
    }
    const handleSuccessClose = () => {
        setSuccessOpen(false)
    }

    useEffect(() => {
        viewAPI()
    }, [])

    return (
        <div className="h-full bg-white">
            <div className="w-full  mx-auto">

                {/* Page Header */}
                <div className="mb-6">
                    <h1 className="text-2xl font-semibold text-[#099309]">
                        My Profile
                    </h1>
                    <p className="text-gray-500 mt-1">
                        {
                            roles === "office_admin" ? "View your account details and update your password." : "View your account details"
                        }

                    </p>
                </div>

                {/* Cards */}
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">

                    {/* Profile Card */}
                    <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6">
                        <div className="flex items-center gap-4">
                            <div className="w-16 h-16 rounded-full bg-[#099309] text-white flex items-center justify-center text-2xl font-bold">
                                {userDetails?.name?.charAt(0)?.toUpperCase() || "N/A"}
                            </div>

                            <div>
                                <h2
                                    data-tooltip-id="profile-tooltip"
                                    data-tooltip-content={userDetails?.name}
                                    data-tooltip-place="bottom"
                                    className="text-2xl font-semibold max-w-[250px] truncate"
                                >
                                    {userDetails?.name}
                                </h2>

                                <span className="inline-block mt-1 px-3 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-700">
                                    {userDetails?.role
                                        ?.split("_")
                                        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
                                        .join(" ")}
                                </span>
                            </div>
                        </div>

                        <hr className="my-6" />

                        <div className="space-y-6">
                            <div>
                                <p className="text-sm text-gray-500">
                                    Employee ID
                                </p>
                                <p className="font-medium">
                                    {userDetails?.employee_id ?? "N/A"}
                                </p>
                            </div>

                            <div>
                                <p className="text-sm text-gray-500">
                                    Email Address
                                </p>
                                <p
                                    data-tooltip-id="profile-tooltip"
                                    data-tooltip-content={userDetails?.email}
                                    data-tooltip-place="bottom"
                                    className="font-medium max-w-[250px] truncate"
                                >
                                    {userDetails?.email}
                                </p>
                            </div>

                            <div>
                                <p className="text-sm text-gray-500">
                                    Phone Number
                                </p>
                                <p className="font-medium">
                                    {userDetails?.phone}
                                </p>
                            </div>
                        </div>
                    </div>

                    {
                        roles === "office_admin" && (<>
                            {/* Change Password Card */}
                            <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6">
                                <h2 className="text-xl font-semibold mb-2">
                                    Change Password
                                </h2>

                                <p className="text-gray-500 text-sm mb-6">
                                    Ensure your account is using a long, random
                                    password to stay secure.
                                </p>

                                <form className="space-y-5" onSubmit={handleSubmit}>
                                    <div>
                                        <TextInput
                                            label="Current Password"
                                            name="currentPassword"
                                            placeholder="Enter Current Password"
                                            value={formData?.currentPassword}
                                            onChange={updateFieldData}
                                            error={errors?.currentPassword}
                                            type={isCurrentPasswordVisible ? "text" : "password"}
                                            icon={isCurrentPasswordVisible ? passwordIcon : passIcon}
                                            onIconClick={() => setIsCurrentPasswordVisible((prev) => !prev)}
                                            pointer={true}
                                            maxLength={17}
                                            regexValidation={RegexValidations.noSpaces}
                                            required
                                        />
                                    </div>

                                    <div>
                                        <TextInput
                                            label="New Password"
                                            name="newPassword"
                                            placeholder="Enter New Password"
                                            value={formData?.newPassword}
                                            onChange={updateFieldData}
                                            error={errors?.newPassword}
                                            type={isNewPasswordVisible ? "text" : "password"}
                                            icon={isNewPasswordVisible ? passwordIcon : passIcon}
                                            onIconClick={() => setIsNewPasswordVisible((prev) => !prev)}
                                            pointer={true}
                                            maxLength={17}
                                            regexValidation={RegexValidations.noSpaces}
                                            required
                                        />
                                    </div>

                                    <div>
                                        <TextInput
                                            label="Confirm Password"
                                            name="confirmPassword"
                                            placeholder="Enter Confirm Password"
                                            value={formData?.confirmPassword}
                                            onChange={updateFieldData}
                                            error={errors?.confirmPassword}
                                            type={isConfirmPasswordVisible ? "text" : "password"}
                                            icon={isConfirmPasswordVisible ? passwordIcon : passIcon}
                                            onIconClick={() => setIsConfirmPasswordVisible((prev) => !prev)}
                                            pointer={true}
                                            maxLength={17}
                                            regexValidation={RegexValidations.noSpaces}
                                            required
                                        />
                                    </div>


                                    <PrimaryButton
                                        title="Save Password"
                                        type="submit"
                                        customClass="md:w-[200px] w-full  hover:bg-[#077c07] "
                                        disabled={isPending}
                                        onClick={handleSubmit}
                                    />
                                </form>
                            </div>

                        </>)
                    }
                </div>
            </div>

            <SuccessModal
                isOpen={showSuccessModal}
                title={successText}
                handleCloseModal={handleSuccessClose}
                message={""}
            />

            <TooltipContainer id={"profile-tooltip"} maxWidth="!max-w-80" />
        </div >
    );
};

export default Profile;