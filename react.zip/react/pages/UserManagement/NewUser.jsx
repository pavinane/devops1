import React from 'react'
import TextInput from '../../components/commonComponents/TextInput';
import PhoneInput from '../../components/commonComponents/PhoneInput';
import SelectInput from '../../components/commonComponents/SelectInput';
import RadioButton from '../../components/commonComponents/RadioButton';
import PrimaryButton from "../../components/commonComponents/PrimaryButton"
import Toggle from '../../components/commonComponents/Toggle';

const NewUser = ({
    isDesktop,
    errors,
    options,
    updateFieldData,
    handleSubmit,
    formData,
    rowId,
    disableForm,
    handleBuildingChange,
    roomOptions,
    buildingOptions,
    addDisabled,
    handleCancel,
    isPasswordVisible,
    passwordIcon,
    passIcon,
    setIsPasswordVisible,
    RegexValidations,
    handleToggleClick,
    handleRoomChange,
    roleOptions
}) => {
    return (
        <div autoComplete='off' className={`relative flex mt-3 flex-col ${isDesktop && "max-h-[80vh] "} ${!isDesktop && "max-h-[70vh] "}  `}>
            <div className={`mt-1 p-1  flex-1 custom-scroll overflow-auto pb-18.75`}>

                <TextInput

                    maxLength={151}
                    required
                    label="User Name"
                    name="user_name"
                    placeholder="Enter User Name"
                    value={formData?.user_name}
                    onChange={(value, name) => {
                        updateFieldData(value?.toLowerCase(), name)
                    }}
                    error={errors?.user_name}
                    disabled={disableForm}
                    width={"!mb-0"}

                />
                <TextInput
                    maxLength={255}
                    required
                    label="Email"
                    name="user_email"
                    placeholder="Enter Email ID"
                    value={formData?.user_email}
                    onChange={(value, name) => {
                        updateFieldData(value?.toLowerCase(), name)
                    }}
                    error={errors?.user_email}
                    disabled={disableForm}
                    width={"!mb-0"}

                />
                {/* {
                    !disableForm && !rowId && (
                        <TextInput
                            autoComplete="new-password"
                            name="user_password"
                            label="Enter Password"
                            placeholder="Enter password"
                            value={formData.user_password}
                            onChange={updateFieldData}
                            error={errors.user_password}
                            required
                            type={isPasswordVisible ? "text" : "password"}
                            icon={isPasswordVisible ? passwordIcon : passIcon}
                            onIconClick={() =>
                                setIsPasswordVisible((prev) => !prev)
                            }
                            pointer={true}
                            regexValidation={RegexValidations.noSpaces}
                        />
                    )
                } */}

                <PhoneInput
                    required
                    label="Mobile Number"
                    name="phone"
                    maxLength={16}
                    value={formData?.phone}
                    placeholder="Enter Mobile No"
                    onChange={
                        updateFieldData
                    }
                    error={errors?.phone}
                    disabled={disableForm}
                    classname={"!mb-0"}
                />
                <SelectInput
                    required
                    label="Building"
                    name="building"
                    placeholder='Select Building'
                    value={formData?.building}
                    onChange={handleBuildingChange}
                    errors={errors?.building}
                    options={buildingOptions}
                    disabled={disableForm}
                    width={"!mb-0"}
                />
                <SelectInput
                    required
                    label="Room"
                    name="room"
                    placeholder='Select Room'
                    value={formData?.room}
                    onChange={handleRoomChange}
                    errors={errors?.room}
                    options={roomOptions}
                    disabled={disableForm}
                    width={"!mb-0"}
                />
                <SelectInput
                    required
                    label="Role"
                    name="role"
                    placeholder='Select Role'
                    value={formData?.role}
                    onChange={updateFieldData}
                    errors={errors?.role}
                    options={roleOptions}
                    disabled={disableForm}
                    width={"!mb-0"}
                />
                <RadioButton
                    label={"Status"}
                    options={options}
                    value={formData?.status}
                    selectedOption={formData?.status}
                    name="status"
                    onSelect={updateFieldData}
                    disabled={disableForm} />

                <div className='w-2/6'>
                    <Toggle
                        labelPosition="top"
                        label="Room Incharge"
                        name="is_room_incharge"
                        checked={formData?.is_room_incharge}
                        onChange={handleToggleClick}
                        disabled={disableForm}
                    />
                </div>


            </div>
            <div className={`flex justify-end gap-4 bg-white  p-4  absolute bottom-0 w-full`}>
                {!disableForm && <div
                    className={`flex items-center gap-4 justify-end  z-3 w-full`}
                >
                    <PrimaryButton
                        title="Cancel"
                        onClick={handleCancel}
                        buttonType="button"
                        customClass="w-[100px] bg-transparent text-black! hover:bg-[#cbf5cb] hover:border-[#black] hover:text-black transition-colors duration-500"
                        disable={disableForm}
                    />
                    <PrimaryButton
                        title={
                            addDisabled
                                ? "Loading..."
                                : rowId
                                    ? "Update"
                                    : "Create"
                        }
                        onClick={handleSubmit}
                        buttonType="submit"
                        customClass="w-[100px] hover:bg-[#077c07]  transition-colors duration-500"
                        disable={disableForm || addDisabled}
                        btnBorder={"border-none"}
                    />
                </div>}

            </div>


        </div>
    )
}

export default NewUser