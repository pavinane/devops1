import React, { useEffect, useState } from "react";
import DataTable from "../../components/commonComponents/DataTable";
import Edit from "../../assets/images/Edit.svg";
import Delete from "../../assets/images/Delete.svg";
import { useMediaQueryValues } from "../../components/commonComponents/MediaQueryContext";
import UserCard from "../../components/commonComponents/UserCard";
import { useReusableMutation } from '../../customHooks/useDataQuery';
import { useToast } from '../../components/ToastContext';
import { useSelector } from "react-redux";
import useForm from "../../components/commonComponents/useForm";
import Modal from "../../components/commonComponents/Modal";
import SuccessModal from "../../components/commonComponents/SuccessModal";
import NewUser from "./NewUser";
import DeleteModal from "../../components/commonComponents/DeleteModal";
import { user_validation } from "../../validation/uservalidation";
import passIcon from "../../assets/Buttons/PasswordIcon.svg";
import passwordIcon from "../../assets/Buttons/EyeOpen.svg";
import { RegexValidations } from "../../validation/RegexValidation";
import SearchIcon from '../../assets/icons/search.svg'
import ReactPaginateModule from "react-paginate";
import PageHeader from "../../components/commonComponents/PageHeader";
const Users = () => {
    const ReactPaginate = ReactPaginateModule.default;
    const { isDesktop, isTablet } = useMediaQueryValues();
    const { token, role } = useSelector((state) => state.user);
    const { error: showError, success } = useToast();
    // States
    const [apiControl, setApiControl] = useState(true);
    const [searchTerm, setSearchTerm] = useState("");
    const [tableData, setTableData] = useState([]);
    const [editData, setEditData] = useState(null);
    const [rowId, setRowId] = useState(null);
    const [isPasswordVisible, setIsPasswordVisible] = useState(false);
    const [paginationData, setPaginationData] = useState({ pageSize: 10, pageIndex: 0, totalPages: 0, totalData: 0 });
    const [confirmStatusModal, setConfirmStatusModal] = useState(false);
    const [roomID, setRoomId] = useState(null);


    const [modalState, setModalState] = useState({
        isOpen: false,
        type: ""
    });

    const [successOpen, setSuccessOpen] = useState({
        isOpen: false,
        type: ""
    });

    const [isDeleteModal, setIsDeleteModal] = useState(false);
    const [disableForm, setDisableForm] = useState(false);
    const [buildingOptions, setBuildingOptions] = useState();
    const [roomOptions, setRoomOptions] = useState();
    const [roleOptions, setRoleOptions] = useState();

    // Static Data
    const INITIAL_SELECT_VALUE = { value: "", label: "" };

    const options = [
        { label: "Active", value: 1 },
        { label: "Inactive", value: 0 },
    ];

    const initialValues = {
        user_name: "",
        user_email: "",
        phone: "",
        building: INITIAL_SELECT_VALUE,
        room: INITIAL_SELECT_VALUE,
        role: INITIAL_SELECT_VALUE,
        status: 1,
        is_room_incharge: false,
    };


    // useForm
    const handleFormSubmit = () => {
        const formDataToSend = new FormData();

        formDataToSend.append("name", formData?.user_name || "");
        formDataToSend.append("email", formData?.user_email || "");
        formDataToSend.append("phone", formData?.phone || "");
        formDataToSend.append("status", formData.status === 1 ? "active" : "inactive");
        formDataToSend.append("building_id", formData?.building?.value || "");
        formDataToSend.append("room_id", formData?.room?.value || "");
        formDataToSend.append("member_role_id", formData?.role?.value || "");
        // 
        formDataToSend.append("is_room_incharge", Boolean(formData?.is_room_incharge));

        const payloadData = {
            name: formData?.user_name,
            email: formData?.user_email,
            phone: formData?.phone,
            status: formData.status === 1 ? "active" : "inactive",
            building_id: formData?.building?.value,
            room_id: formData?.room?.value,
            member_role_id: formData?.role?.value,
            is_room_incharge: formData?.is_room_incharge ? 1 : 0,
        };

        if (rowId) {
            formDataToSend.append("id", rowId);
        }


        const formValue = {
            endPoint: rowId
                ? `api/admin/members/${rowId}`
                : "api/admin/addmember",
            method: rowId ? "PUT" : "POST",
            payload: payloadData,
            token,
            contentType: "application/json",
        };
        apimutate(formValue, {


            onSuccess: (res) => {

                if (rowId) {

                    setSuccessOpen({
                        isOpen: true,
                        type: "update",
                    });
                } else {

                    setSuccessOpen({ isOpen: true, type: "create" });
                }

                handleCancelAddform();
                setTimeout(() => {
                    setSuccessOpen({ isOpen: false, type: "" })
                }, 3000);
                getUserData();
            },

            onError: (err) => {

                const apiErrors = err?.response?.data?.errors;
                const firstError =
                    apiErrors && Object.values(apiErrors)[0];
                showError(firstError || "Something went wrong");
            }
        });

    }


    const {
        formData,
        setFormData,
        errors,
        setErrors,
        updateFieldData,
        handleSubmit,
    } = useForm(initialValues, user_validation(!!rowId), handleFormSubmit);

    // API Mutations

    const { mutate: apimutate, isPending: createPending } = useReusableMutation(
        {
            onError: (err) => {
                const apiErrors = err?.response?.data?.errors;
                const firstError =
                    apiErrors && Object.values(apiErrors)[0];
                showError(firstError || "Something went wrong");
            },
        },
    );

    const { mutate: getBuildingMutate, isPending: buildingPending } =
        useReusableMutation({
            onError: (err) => {
                const apiErrors = err?.response?.data?.errors;

                const firstError =
                    apiErrors && Object.values(apiErrors)[0];

                showError(firstError || "Something went wrong");
            },
        });

    const { mutate: getRoleMutate, isPending: rolePending } =
        useReusableMutation({
            onError: (err) => {
                const apiErrors = err?.response?.data?.errors;

                const firstError =
                    apiErrors && Object.values(apiErrors)[0];

                showError(firstError || "Something went wrong");
            },
        });

    const { mutate: deleteMutate, isPending: deletePending } =
        useReusableMutation({
            onError: (err) => {
                const apiErrors = err?.response?.data?.errors;
                const firstError =
                    apiErrors && Object.values(apiErrors)[0];
                showError(firstError || "Something went wrong");
            },
        });

    const { mutate: getUserMutate, isPending: userPending } =
        useReusableMutation({
            onError: (err) => {
                const apiErrors = err?.response?.data?.errors;

                const firstError =
                    apiErrors && Object.values(apiErrors)[0];

                showError(firstError || "Something went wrong");
            },
        });

    const { mutate: getRoomMutate, isPending: inchargePending } =
        useReusableMutation({
            onError: (err) => {
                const apiErrors = err?.response?.data?.errors;

                const firstError =
                    apiErrors && Object.values(apiErrors)[0];

                showError(firstError || "Something went wrong");
            },
        });

    const { mutate: fetchRoom } = useReusableMutation({
        onSuccess: ({ data }) => {
            if (!data || data?.length === 0) {
                setRoomOptions([]);
                return;
            }

            if (data) {

                const roomData = data?.map((val) => ({
                    value: val?.id,
                    label: `${val?.room_number} (${val?.room_code})`
                }))
                setRoomOptions(roomData);
                if (rowId && editData && roomData) {

                    const formattedData = {
                        user_name: editData?.name,
                        user_email: editData?.email,
                        phone: editData?.phone,

                        building: buildingOptions?.find(
                            (option) => option.value === editData?.member?.building_id
                        ),

                        room: roomData?.find(
                            (option) => option.value === editData?.member?.room_id
                        ),
                        role: roleOptions?.find(
                            (option) => option.value === editData?.member?.member_role_id
                        ),

                        status: editData?.status === "active" ? 1 : 0,


                        is_room_incharge: editData?.room_incharge?.id ? true : false
                    };


                    setFormData(formattedData);
                    handleOpenModal('add');
                }

            }
        },
        onError: (err) => {
            const apiErrors = err?.response?.data?.errors;
            const firstError =
                apiErrors && Object.values(apiErrors)[0];
            showError(apiErrors || "Something went wrong");


        }
    })

    // Get Users
    const getUserData = (edit) => {

        const payloadValue = {
            per_page: paginationData?.pageSize || 10,
            page: paginationData?.pageIndex + 1,
            search: searchTerm,
        }
        const payload = {
            endPoint: "api/admin/members",
            method: "GET",
            payload: payloadValue,
            token,
        };
        getUserMutate(payload, {
            onSuccess: (data) => {
                const formattedData = data?.data?.map((item) => ({
                    id: item.id,
                    name: item.name,
                    email: item.email,
                    phone: item.phone,
                    building: item.member?.building?.name,
                    room: `${item.member?.room?.room_number} - ${item.member?.room?.room_code}`,
                    role: item.member?.role?.name,
                    status: item.status === "active" ? "Active" : "Inactive",
                    is_room_incharge: item.is_room_incharge,
                    originalData: item
                }));

                setTableData(formattedData);
                setPaginationData((prev) => ({
                    ...prev,
                    totalPages: data?.pagination?.last_page,
                    totalData: data?.pagination?.total,
                }));


                if (apiControl) {
                    setTimeout(() => setApiControl(false), 2000);
                }
            },
            onError: (err) => {
                const apiErrors = err?.response?.data?.errors;

                const firstError =
                    apiErrors && Object.values(apiErrors)[0];

                showError(firstError || "Something went wrong");
            },


        });
    };

    // Role
    const getRoleData = () => {
        const payload = {
            endPoint: "api/admin/memberRoles",
            method: "GET",
            token,
        };
        getRoleMutate(payload, {
            onSuccess: (data) => {
                if (!data || data.length === 0) {
                    setRoleOptions([]);
                    return;
                }
                if (data) {
                    const roleData = data?.data?.map((val) => ({
                        value: val?.value,
                        label: val?.label
                    }))
                    setRoleOptions(roleData)
                }
            },
            onError: (err) => {

                const apiErrors = err?.response?.data?.errors;

                const firstError =
                    apiErrors && Object.values(apiErrors)[0];

                showError(firstError || "Something went wrong");

            },


        });
    };

    // Get Buildings
    const getBuildingData = () => {
        const payload = {
            endPoint: "api/buildings/list",
            method: "GET",
            token,
        };
        getBuildingMutate(payload, {
            onSuccess: (data) => {
                if (!data || data.length === 0) {
                    setBuildingOptions([]);
                    return;
                }
                if (data) {
                    const buildingData = data?.data?.map((val) => ({
                        value: val?.id,
                        label: val?.name
                    }))
                    setBuildingOptions(buildingData)
                }
            },
            onError: (err) => {

                const apiErrors = err?.response?.data?.errors;

                const firstError =
                    apiErrors && Object.values(apiErrors)[0];

                showError(firstError || "Something went wrong");

            },


        });
    };

    // Get Rooms
    const fetchRoomOptions = (id) => {
        const payloadValue = {
            building_id: id,
        }
        const apiRequest = {
            endPoint: "api/rooms-by-building",
            method: 'POST',
            token,
            payload: payloadValue,
        }
        fetchRoom(apiRequest)
    }


    //Delete
    const handleDeleteAPI = () => {
        const payloadValues = {
            user: rowId,
        };
        const formValue = {
            endPoint: `api/admin/members/${rowId}`,
            method: "DELETE",
            payload: payloadValues,
            token,
        };
        deleteMutate(formValue, {
            onSuccess: (data) => {
                setIsDeleteModal(false);
                setSuccessOpen({ isOpen: true, type: "delete" });
                setTimeout(() => {
                    setSuccessOpen({ isOpen: false, type: "" })
                }, 3000);
                setRowId(null);
                getUserData();
            },
            onError: (err) => {

                const apiErrors = err?.response?.data?.message;
                const firstError =
                    apiErrors && Object.values(apiErrors)[0];
                showError(apiErrors || "Something went wrong");
            },

        });
    };

    //  get is room incharge or not  
    const getRoomIncharge = () => {


        const value = {
            endPoint: `api/admin/rooms/${roomID}/check-incharge`,
            method: "GET",
            payload: {
                room_id: roomID
            },
            token,
        };
        getRoomMutate(value, {
            onSuccess: (data) => {
                if (data?.data?.has_incharge) {
                    setConfirmStatusModal(true)
                } else {
                    setFormData((prev) => ({
                        ...prev,
                        is_room_incharge: true,
                    }));
                }
            },
            onError: (err) => {
                const apiErrors = err?.response?.data?.errors;

                const firstError =
                    apiErrors && Object.values(apiErrors)[0];

                showError(firstError || "Something went wrong");
            },


        });
    };





    const handleOpenModal = (type) => {
        setModalState({ isOpen: true, type: type })
    };

    const handleCancelAddform = () => {


        setFormData(initialValues);

        setErrors({});
        setRowId(null);
        setDisableForm(false);
        setModalState({ isOpen: false, type: "" })
    };

    const handleSuccessClose = () => {
        setSuccessOpen({ isOpen: false, type: "" })
    }

    const handleCancelDeleteModal = () => {
        setIsDeleteModal(false);
        setRowId(null);
    }


    const handleConfirmNo = () => {
        setConfirmStatusModal(false);
    };
    const handleConfirmYes = () => {
        setFormData((prev) => ({
            ...prev,
            is_room_incharge: true,
        }));
        setConfirmStatusModal(false);
    };

    const onChange = (e) => {
        setSearchTerm(e.target.value)
    };

    // const handleToggleClick = (e) => {
    //     const { name, checked } = e.target;

    //     setFormData((prev) => ({
    //         ...prev,
    //         [name]: checked,
    //     }));

    //     if (checked && roomID) {
    //         getRoomIncharge();
    //     }
    // };
    const handleToggleClick = (e) => {

        if (!formData?.room?.label) {
            showError("Select Room");
            return;
        }
        const { checked } = e.target;

        if (!checked) {
            setFormData((prev) => ({
                ...prev,
                is_room_incharge: false,
            }));
            return;
        }

        getRoomIncharge();
    };

    const handleRoomChange = (value, name) => {

        updateFieldData(value, name);
        setRoomId(value?.value);
        setFormData((prev) => ({
            ...prev,
            is_room_incharge: false,
        }))
    };


    const handleBuildingChange = (value, name) => {
        updateFieldData(value, name);
        setEditData(null)
        if (value?.value) {

            fetchRoomOptions(value?.value)
        }
        setFormData((prev) => ({
            ...prev,
            room: INITIAL_SELECT_VALUE,
            is_room_incharge: false,
        }))
    }

    const getSuccessTitle = () => {
        if (successOpen.type === "update") {
            return successOpen.title || "User  updated successfully.";
        }

        if (successOpen.type === "create") return "User  created successfully.";
        if (successOpen.type === "delete") return "User  removed successfully.";
        return "";
    };

    const handleFinalSubmit = () => {
        handleSubmit();
    }


    const handleRowClick = (data) => {

        const formattedData = {
            user_name: data?.name,
            user_email: data?.email,
            phone: data?.phone,

            building: buildingOptions?.find(
                (option) =>
                    option.value === data?.originalData?.member?.building_id
            ),

            room: {
                value: data?.originalData?.member?.room?.id,
                label: `${data?.originalData?.member?.room?.room_number} (${data?.originalData?.member?.room?.room_code})`
            },
            role: roleOptions?.find(
                (option) =>
                    option.value === data?.originalData?.member?.member_role_id
            ),

            status: data?.status === "Active" ? 1 : 0,

            // user_password: "",
            is_room_incharge: data?.originalData?.room_incharge?.id ? true : false,
        };

        setDisableForm(true);
        setFormData(formattedData);
        setRowId(data?.id);
        handleOpenModal("add");
    };



    const columns = [
        {
            key: "name",
            label: "MEMBER",
            render: (value) => (
                <div
                    data-tooltip-id="my-tooltip"
                    data-tooltip-content={value}
                    data-tooltip-place="bottom"
                    className="inline-block max-w-36 truncate whitespace-nowrap overflow-hidden text-ellipsis"
                >
                    {value}
                </div>
            ),
        },
        {
            key: "email",
            label: "EMAIL",
            render: (value, row) => {
                return (
                    <div
                        data-tooltip-id="my-tooltip"
                        data-tooltip-content={value}
                        data-tooltip-place="bottom"
                        className="inline-block text-left max-w-36 truncate whitespace-nowrap overflow-hidden text-ellipsis"
                    >
                        {value}
                    </div>
                );
            },
        },

        {
            key: "phone",
            label: "PHONE",
        },
        {
            key: "building",
            label: "BUILDING",
            render: (value) => (
                <div
                    data-tooltip-id="my-tooltip"
                    data-tooltip-content={value}
                    data-tooltip-place="bottom"
                    className="inline-block max-w-36 truncate whitespace-nowrap overflow-hidden text-ellipsis"
                >
                    {value}
                </div>
            ),
        },
        {
            key: "room",
            label: "ROOM",
            render: (value) => (
                <div
                    data-tooltip-id="my-tooltip"
                    data-tooltip-content={value}
                    data-tooltip-place="bottom"
                    className="inline-block max-w-36 truncate whitespace-nowrap overflow-hidden text-ellipsis"
                >
                    {value}
                </div>
            ),
        },
        {
            key: "role",
            label: "ROLE",

        },
        {
            key: "status",
            label: "STATUS",
            render: (value) => (
                <span
                    className={`px-3 py-1 rounded-full text-xs font-medium ${value === "Active"
                        ? "bg-green-100 text-green-700"
                        : "bg-red-100 text-red-700"
                        }`}
                >
                    {value}
                </span>
            ),
        },
        {
            key: "action",
            label: "ACTIONS",
            render: (_, row) => {
                const handleEdit = (e, user) => {
                    e.stopPropagation();
                    const data = user.originalData;


                    const buildingId = buildingOptions?.find(
                        (option) =>
                            option.value ===
                            data?.member?.building_id
                    );
                    setDisableForm(false)
                    setEditData(data);
                    setRowId(user?.id);
                    fetchRoomOptions(buildingId?.value);
                };
                const handleDelete = (e, row) => {
                    e.stopPropagation();
                    setRowId(row?.originalData?.id);
                    setIsDeleteModal(true)

                }
                return (
                    <div className="flex gap-3 justify-start">
                        <div
                            className="w-[30px] h-[30px] rounded-full flex items-center justify-center bg-[#F4F4F4] cursor-pointer"
                            onClick={(e) => handleEdit(e, row)}
                            data-tooltip-id="my-tooltip"
                            data-tooltip-content={"Edit"}
                            data-tooltip-place="bottom"
                        >
                            <img src={Edit} alt="edit" />
                        </div>

                        <div
                            className="w-[30px] h-[30px] rounded-full flex items-center justify-center bg-[#F4F4F4] cursor-pointer"
                            // onClick={() => handleDelete(row)}
                            onClick={(e) => handleDelete(e, row)}
                            data-tooltip-id="my-tooltip"
                            data-tooltip-content={"Delete"}
                            data-tooltip-place="bottom"
                        >
                            <img src={Delete} alt="delete" />
                        </div>
                    </div>
                );
            },
        },
    ];



    useEffect(() => {
        getRoleData();
    }, []);
    useEffect(() => {
        setRowId(null);
        getUserData();
    }, []);
    useEffect(() => {
        getBuildingData();
    }, []);


    useEffect(() => {
        if (!apiControl) {
            getUserData();
        }
    }, [paginationData.pageIndex, paginationData.pageSize]);

    useEffect(() => {
        if (apiControl) return;
        if (searchTerm.length !== 0 && searchTerm.length < 3) return;

        const timerId = setTimeout(() => {
            setPaginationData((prev) => ({
                ...prev,
                pageIndex: 0,
                pageSize: 10,
            })); setPaginationData((prev) => ({
                ...prev,
                pageIndex: 0,
                pageSize: 10,
            }));

            getUserData();
        }, 300);

        return () => clearTimeout(timerId);

    }, [searchTerm]);



    return (
        <div className="h-full w-full bg-white pt-[15px]">
            <div className="w-full space-y-6">
                {/* Page Header */}
                <PageHeader title="User Management" />
                {/* Info Banner */}
                <div className="bg-white border border-black/10 flex justify-between rounded-2xl shadow-sm p-4 text-gray-500">
                    {/* <p className="max-w-112.5"> Only admins can create users. Members are listed here and
                        can be edited.</p> */}

                    <div className="xs:max-w-45  xsmm:w-[70%] xl:max-w-100 xsmm:max-w-75 flex gap-2 items-center rounded-2xl border border-black/10 4x:p-2 md:p-1">
                        <img src={SearchIcon} alt="" srcSet="" className="w-5 h-5" />
                        <input type="search"
                            onChange={onChange}
                            placeholder="Search Users"
                            value={searchTerm ? searchTerm : ""}
                            name="search" id="search" className="w-full outline-none p-1 placeholder:md:text-sm placeholder:4xl:text-16px placeholder:xs:text-sm" />
                    </div>

                    {isDesktop && (
                        <div className="flex justify-end">
                            <button
                                onClick={() => {
                                    setRoomOptions([])
                                    setFormData(initialValues)
                                    setDisableForm(false);
                                    handleOpenModal('add');
                                }} className="bg-[#099309] cursor-pointer hover:bg-[#077c07] text-white px-6 py-3 rounded-xl font-medium transition">
                                + Add Member
                            </button>
                        </div>
                    )}
                </div>

                {/* Add Member Button */}


                {
                    !isDesktop && (
                        <div className="fixed  bottom-20 right-5  z-99">
                            <button
                                onClick={() => {
                                    setRoomOptions([])
                                    setFormData(initialValues)
                                    setDisableForm(false);
                                    handleOpenModal('add');
                                }} className="bg-[#099309] cursor-pointer hover:bg-[#077c07] text-3xl text-white px-4 py-2 rounded-full font-medium transition">
                                +
                            </button>
                        </div>
                    )
                }

                {isDesktop ? (
                    <DataTable
                        searchable={false}
                        onRowClick={handleRowClick}
                        columns={columns}
                        data={tableData}
                        pageSize={10}
                        pagination={true}
                        paginationData={paginationData}
                        setPaginationData={setPaginationData}
                        showCheckbox={false}
                        // tableHeight={
                        //     tableData > 9 ? "min-h[500px]" : ""
                        // }
                        showDot={false}

                    />
                ) : (
                    <>
                        <div
                            className={`grid gap-4 px-2 ${isTablet
                                ? tableData.length > 1
                                    ? "grid-cols-2"
                                    : "grid-cols-1"
                                : "grid-cols-1"
                                }`}
                        >
                            {tableData.map((user) => (
                                <UserCard
                                    key={user.id}
                                    {...user}

                                    onEdit={(e) => {
                                        e.stopPropagation();
                                        const data = user.originalData
                                        const buildingId = buildingOptions?.find(
                                            (option) =>
                                                option.value ===
                                                data?.member?.building_id
                                        );
                                        setDisableForm(false)
                                        setEditData(data);
                                        setRowId(user?.id);
                                        fetchRoomOptions(buildingId?.value);

                                    }}
                                    onClick={() => handleRowClick(user)}
                                    onDelete={(e) => {
                                        e.stopPropagation();
                                        setRowId(user?.originalData?.id);
                                        setIsDeleteModal(true)
                                    }}
                                />
                            ))}
                        </div>

                        {paginationData.totalPages > 0 && (
                            <div className="pb-[120px]">

                                <div className="flex items-center justify-center m-0 ">
                                    <p className="text-center font-regular text-sm  m-0">
                                        Showing {paginationData.totalData === 0 ? 0 : (paginationData.pageIndex * paginationData.pageSize) + 1} to {Math.min((paginationData.pageIndex + 1) * paginationData.pageSize, paginationData.totalData)} of {paginationData.totalData} entries
                                    </p>
                                </div>
                                <div className="flex justify-center ">

                                    <ReactPaginate
                                        breakLabel="..."
                                        nextLabel=">"
                                        previousLabel="<"
                                        pageCount={paginationData.totalPages}
                                        forcePage={paginationData.pageIndex}
                                        onPageChange={(selectedItem) => {
                                            setPaginationData((prev) => ({
                                                ...prev,
                                                pageIndex: selectedItem.selected,
                                            }));
                                        }}
                                        containerClassName="flex items-center gap-2"
                                        pageClassName="border rounded-full"
                                        pageLinkClassName="!w-[23px] h-[23px] flex items-center justify-center"
                                        activeClassName="bg-[#099309] text-white border-[#099309]"
                                        previousClassName=" rounded-lg"
                                        previousLinkClassName="px-3 py-2 block"
                                        nextClassName=" rounded-lg"
                                        nextLinkClassName="px-3 py-2 block"
                                        disabledClassName="opacity-50 cursor-not-allowed"
                                    />
                                </div>
                            </div>
                        )}
                    </>
                )}
            </div>
            <Modal
                title={modalState.type === "add" && disableForm ? " User Details" : modalState.type === "add" && rowId && !disableForm ? "Edit User" : "User Register"}
                isOpen={modalState.isOpen}
                status={"warning"} size={"medium"}
                onClose={handleCancelAddform}
                showCloseButton={true}
                width={`xs:w-[95%]  md:max-w-[600px] xxmd:max-w-[650px] ${modalState.type === "import" ? "lg:max-w-[650px]" : "lg:max-w-[600px]"}    max-h-[95vh] `}
                customClass='xs:px-5'
            >
                <NewUser
                    isDesktop={isDesktop}
                    formData={formData}
                    updateFieldData={updateFieldData}
                    errors={errors}
                    disableForm={disableForm}
                    rowId={rowId}
                    handleSubmit={(e) => {
                        e.preventDefault();
                        handleFinalSubmit();
                    }}
                    handleBuildingChange={handleBuildingChange}
                    buildingOptions={buildingOptions}
                    roomOptions={roomOptions}
                    options={options}
                    handleCancel={handleCancelAddform}
                    passIcon={passIcon}
                    passwordIcon={passwordIcon}
                    setIsPasswordVisible={setIsPasswordVisible}
                    isPasswordVisible={isPasswordVisible}
                    RegexValidations={RegexValidations}
                    handleToggleClick={handleToggleClick}
                    addDisabled={createPending}
                    handleRoomChange={handleRoomChange}
                    roleOptions={roleOptions}
                />
            </Modal>

            <Modal
                width={"xl:max-w-[370px]  max-h-[340px] p-2  max-w-[400px] w-[80%]"}
                isOpen={isDeleteModal}
                onClose={handleCancelDeleteModal}
                showCloseButton={true}
            >
                <DeleteModal
                    text="Are you sure you want to remove this user ?"
                    onConfirm={handleDeleteAPI}
                    onCancel={handleCancelDeleteModal}
                    onConfirmText={"Yes, Remove"}
                    onCancelText={"No, Go Back"}
                    showDeleteIcon={true}
                    showButtons={true}
                />
            </Modal>
            <SuccessModal
                isOpen={successOpen.isOpen}
                title={getSuccessTitle()}
                handleCloseModal={handleSuccessClose}
                message={"Participants have been notified"}
            />

            <Modal
                width={"xl:max-w-[370px] z-9999! max-h-[340px] p-2 max-w-[400px] w-[80%]"}
                isOpen={confirmStatusModal}
                onClose={handleConfirmNo}
                showCloseButton={true}
            >
                <DeleteModal
                    text="This room already has in-charge. Do you want to override ?"
                    onConfirm={handleConfirmYes}
                    onCancel={handleConfirmNo}
                    onConfirmText={"Confirm"}
                    onCancelText={"No, Go Back"}
                    showDeleteIcon={true}
                    showButtons={true}
                />
            </Modal>


        </div>
    );
};

export default Users;
