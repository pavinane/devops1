import React, { useState, useEffect } from "react";
import { useMediaQueryValues } from "../../components/commonComponents/MediaQueryContext";
import { useSelector } from "react-redux";
import { useReusableMutation } from "../../customHooks/useDataQuery";
import { useToast } from "../../components/ToastContext";
import PrimaryButton from "../../components/commonComponents/PrimaryButton";
import PageHeader from "../../components/commonComponents/PageHeader";

function getCurrentTime() {
  const now = new Date();
  return now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false });
}

function formatDisplayTime(time24) {
  if (!time24) return "";
  const [h, m] = time24?.split(":").map(Number);
  const period = h >= 12 ? "PM" : "AM";
  const hour = h % 12 || 12;
  return `${hour}:${String(m)?.padStart(2, "0")} ${period}`;
}

// function isBeforeCutoff(currentTime, cutoffTime) {
//   const [ch, cm] = currentTime?.split(":").map(Number);
//   const [kh, km] = cutoffTime?.split(":").map(Number);
//   return ch * 60 + cm < kh * 60 + km;
// }

function isBeforeCutoff(currentTime, cutoffTime) {
  if (!currentTime || !cutoffTime) return false;

  const currentParts = currentTime.split(":");
  const cutoffParts = cutoffTime.split(":");

  if (currentParts.length < 2 || cutoffParts.length < 2) {
    return false;
  }

  const [ch, cm] = currentParts.map(Number);
  const [kh, km] = cutoffParts.map(Number);

  return ch * 60 + cm < kh * 60 + km;
}

export default function MealSettings() {
  const [cutoffTime, setCutoffTime] = useState("19:00");
  const [savedCutoff, setSavedCutoff] = useState("");
  const [toggleOn, setToggleOn] = useState(true);
  const [saved, setSaved] = useState(false);
  const [currentTime, setCurrentTime] = useState(getCurrentTime());
  const { isMobile, isTablet } = useMediaQueryValues();
  const { token, role } = useSelector((state) => state.user);
  const { success, error } = useToast();

  const beforeCutoff = isBeforeCutoff(currentTime, savedCutoff);
  const tomorrowOpen = toggleOn ? true : toggleOn === false ? false : beforeCutoff;

  const toggleState = toggleOn === true ? "ON" : toggleOn === false ? "OFF" : "Schedule";


  const handleSave = () => {
  const formattedTime =
    cutoffTime?.length === 5
      ? `${cutoffTime}:00`
      : cutoffTime;

  setSavedCutoff(formattedTime);

  setSaved(true);

  setTimeout(() => {
    setSaved(false);
  }, 2000);

  handleFormSubmit(formattedTime);
};

  const handleToggle = () => {
    setToggleOn((prev) => !prev);
  };

  const tomorrowStatus = toggleOn ? "Open" : !beforeCutoff ? "Locked" : "Open";



  const { mutate: fetchMealSetting } = useReusableMutation({
    onSuccess: (data) => {

      const setting = data?.data;
      if (setting) {
        setCutoffTime(setting.cutoff_time_tomorrow?.slice(0, 5));
        setSavedCutoff(setting.cutoff_time_tomorrow);
        setToggleOn(setting.allow_member_cancellation === "1" ? true : false);
      }

    },
    onError: (err) => { },
  });


  function getMealSetting() {
    fetchMealSetting({
      endPoint: "api/admin/meal-settings",
      method: "GET",
      token,
    });
  }




  const { mutate: saveMealSetting } = useReusableMutation({
    onSuccess: () => {

      success("Meal settings updated!");
    },
    onError: (err) => {
      error("Failed to update meal settings. Please try again.");
    },
  });

  function handleFormSubmit(formattedTime) {

    const payload = {
      "cutoff_time_tomorrow": formattedTime,
      "advance_days": 7,
      "allow_member_cancellation": toggleOn ? "1" : "0"
    };

    saveMealSetting({
      endPoint: "api/admin/store-meal-settings",
      method: "POST",
      payload,
      token,
    });
  }

  useEffect(() => {
    getMealSetting();
  }, [])

  useEffect(() => {
    const interval = setInterval(() => setCurrentTime(getCurrentTime()), 30000);
    return () => clearInterval(interval);
  }, []);



  return (


    <div className={`w-full pt-[15px] font-sans ${isMobile ? "min-h-screen" : "h-full"}`}>
      <PageHeader title="Meal Settings" />

      <div className="mb-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-1">Member meal orders</h2>
        <p className="text-sm text-gray-500 leading-relaxed">
          <strong className="font-semibold text-gray-700">Today</strong> is always locked (preview).{" "}
          <strong className="font-semibold text-gray-700">Tomorrow</strong> uses the cutoff time below (+ toggle). Other future dates stay open for ordering anytime on the member app.
        </p>
      </div>


      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">


        <div className="bg-white border border-gray-200 rounded-xl p-6">
          <h3 className="text-base font-semibold text-gray-800 mb-4">Order cutoff time</h3>

          <label className="block text-sm text-gray-600 mb-2">
            Tomorrow's menu locks after (today)
          </label>

          <div className="relative mb-4">
            <input
              type="time"
              value={cutoffTime}
              onChange={(e) => setCutoffTime(e.target.value)}
              className="time-input w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm cursor-pointer
               text-gray-800 outline-none  transition-all"
            />
          </div>

          <div className="text-sm text-gray-500 space-y-1">
            <p>
              Current server time:{" "}
              <strong className="text-gray-800">{formatDisplayTime(currentTime)}</strong>. After the cutoff, tomorrow moves to{" "}
              <strong className="text-gray-800">locked</strong> (unless you unlock below).
            </p>
            <p>
              Right now: {beforeCutoff ? "before" : "after"}{" "}
              {formatDisplayTime(savedCutoff)} → tomorrow is{" "}
              {beforeCutoff ? "open (schedule)" : "locked (schedule)"}.
            </p>
          </div>
        </div>


        <div className="bg-white border border-gray-200 rounded-xl p-6">
          <h3 className="text-base font-semibold text-gray-800 mb-4">Tomorrow — lock / unlock</h3>


          <div className="border border-gray-200 rounded-xl px-4 py-3 flex items-center justify-between mb-4">
            <div>
              <div className="flex items-center gap-2 mb-0.5">
                <span className="text-sm font-medium text-gray-700">Tomorrow is</span>
                <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${tomorrowStatus === "Open"
                  ? "bg-teal-100 text-teal-700"
                  : "bg-red-100 text-red-600"
                  }`}>
                  {tomorrowStatus}
                </span>
              </div>
              <p className="text-xs text-gray-400">
                {toggleOn
                  ? "Override: unlocked for all members."
                  : `Schedule: ${beforeCutoff ? "open" : "locked"} — locks when current time passes ${formatDisplayTime(cutoffTime)}.`}
              </p>
            </div>
            {/* Toggle switch */}
            <button
              onClick={handleToggle}
              className={`w-12 h-6 rounded-full relative transition-colors duration-200 focus:outline-none cursor-pointer ${toggleOn ? "bg-[var(--fc-btn-bg)]" : "bg-gray-300"
                }`}
              aria-label="Toggle tomorrow lock"
            >
              <span
                className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all duration-200 ${toggleOn ? "left-[26px]" : "left-0.5"
                  }`}
              />
            </button>
          </div>


          {/* <button
            onClick={() => setToggleOn(null)}
            className={`text-sm font-medium px-4 py-2 rounded-lg border transition-colors ${toggleOn === null
              ? "border-teal-500 text-teal-700 bg-teal-50"
              : "border-gray-300 text-gray-600 hover:bg-gray-50"
              }`}
          >
            Use schedule only ({formatDisplayTime(savedCutoff)})
          </button> */}

          <PrimaryButton
            onClick={() => setToggleOn(null)}
            title={`Use schedule only (${formatDisplayTime(savedCutoff)})`}
            bgColor={toggleOn === null ? "bg-teal-50" : "bg-white"}
            textColor={toggleOn === null ? "text-teal-700" : "text-gray-600"}
            btnBorder={
              toggleOn === null
                ? "border border-teal-500"
                : "border border-gray-300"
            }
            textSize="text-sm"
            customClass="rounded-lg hover:bg-gray-50"
          />

          <p className="text-xs text-gray-400 mt-3 leading-relaxed">
            <span className="font-semibold text-gray-600">ON</span> = unlock for all ·{" "}
            <span className="font-semibold text-gray-600">OFF</span> = lock now ·{" "}
            <span className="font-semibold text-gray-600">Schedule</span> = follow cutoff time above
          </p>
        </div>
      </div>


      {/* <button
        onClick={handleSave}
        disabled={saved}
        className="btn-primary hover:.btn-primary:hover text-white text-sm font-semibold px-6 py-3 rounded-lg transition-colors flex items-center gap-2"
      >
        {saved ? (
          <>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="20 6 9 17 4 12" />
            </svg>
            Saved!
          </>
        ) : "Save settings"}
      </button> */}
      <div className={`${isMobile && "mb-10"}`}>
        <PrimaryButton
          onClick={handleSave}
          disable={saved}
          bgColor="btn-primary"
          btnBorder=""
          textColor="text-white"
          title={saved ? "Saved!" : "Save settings"}
          customClass="rounded-lg px-6 py-3 text-sm font-semibold"
        >
          {saved &&

            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <polyline points="20 6 9 17 4 12" />
            </svg>

          }
      </PrimaryButton>

      </div>

     

    </div>

  );
}
