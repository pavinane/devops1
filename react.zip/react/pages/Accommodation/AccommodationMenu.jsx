import React from "react";
import { useNavigate } from "react-router-dom";

const menuItems = [
  {
    label: "Order & Requests",
    description: "View and manage all accommodation orders",
    navigate: "/service-request",
    icon: (
      <svg width="22" height="22" fill="none" stroke="#16a34a" strokeWidth="1.8" viewBox="0 0 24 24">
        <rect x="3" y="3" width="7" height="7" rx="1" />
        <rect x="14" y="3" width="7" height="7" rx="1" />
        <rect x="3" y="14" width="7" height="7" rx="1" />
        <rect x="14" y="14" width="7" height="7" rx="1" />
      </svg>
    ),
  },
  {
    label: "Service Categories",
    description: "Manage accommodation service categories",
    navigate: "/service-categories",
    icon: (
      <svg width="22" height="22" fill="none" stroke="#16a34a" strokeWidth="1.8" viewBox="0 0 24 24">
        <path d="M4 6h16M4 12h16M4 18h10" strokeLinecap="round" />
      </svg>
    ),
  },
];

const AccommodationMenu = () => {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col gap-4 px-4 pt-4 max-w-lg mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 rounded-xl bg-green-50 flex items-center justify-center">
          <svg width="22" height="22" fill="none" stroke="#16a34a" strokeWidth="1.8" viewBox="0 0 24 24">
            <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
          </svg>
        </div>
        <div>
          <p className="text-base font-semibold text-gray-900">Accommodation</p>
          <p className="text-xs text-gray-400">Manage orders and services</p>
        </div>
      </div>

      {/* Menu Cards */}
      {menuItems.map((item) => (
        <button
          key={item.label}
          onClick={() => navigate(item.navigate)}
          className="w-full flex items-center gap-4 bg-white border border-gray-200 rounded-2xl px-4 py-4 hover:bg-green-50 transition text-left"
        >
          <div className="w-10 h-10 rounded-xl bg-green-50 flex items-center justify-center flex-shrink-0">
            {item.icon}
          </div>
          <div className="flex-1">
            <p className="text-sm font-semibold text-gray-900">{item.label}</p>
            <p className="text-xs text-gray-400 mt-0.5">{item.description}</p>
          </div>
          <svg width="16" height="16" fill="none" stroke="#9ca3af" strokeWidth="2" viewBox="0 0 24 24">
            <path d="M9 18l6-6-6-6" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
      ))}
    </div>
  );
};

export default AccommodationMenu;
