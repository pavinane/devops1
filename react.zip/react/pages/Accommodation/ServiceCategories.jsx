import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import Modal from "../../components/commonComponents/Modal";
import DataTable from "../../components/commonComponents/DataTable";
import ServiceCategoriesForm from "./ServiceCategoriesForm";
import useForm from "../../components/commonComponents/useForm";
import { useReusableMutation } from "../../customHooks/useDataQuery";
import Edit from "../../assets/images/Edit.svg";
import Delete from "../../assets/images/Delete.svg";
import { categoriesSchema } from "../../validation/categoriesSchhema";
import { useMediaQueryValues } from "../../components/commonComponents/MediaQueryContext";
import UserCard from "../../components/commonComponents/UserCard";
import { useToast } from "../../components/ToastContext";
import PageHeader from "../../components/commonComponents/PageHeader";
import SearchIcon from "../../assets/icons/search.svg";
import ReactPaginateModule from "react-paginate";

const initialValues = {
    name: "",
    description: "",
    status: "active",
};

const ServiceCategories = ({ showRoomBuilding, trucate }) => {
    const ReactPaginate = ReactPaginateModule.default;
    const { token } = useSelector((state) => state.user);
    const [showModal, setShowModal] = useState(false);
    const [isDeleteModal, setIsDeleteModal] = useState(false);
    const [categories, setCategories] = useState([]);
    const [rowId, setRowId] = useState(null);
    const [editData, setEditData] = useState(null);
    const { isDesktop } = useMediaQueryValues();
    const { success, error, warning, info, showToast } = useToast();
    const [searchTerm, setSearchTerm] = useState("");
    const [apiControl, setApiControl] = useState(true);
    const [disableForm, setDisableForm] = useState(false);
    const onChange = (e) => {
        setSearchTerm(e.target.value);
    };
    const [paginationData, setPaginationData] = useState({
        pageSize: 10,
        pageIndex: 0,
        totalPages: 0,
        totalData: 0,
    });

    const {
        formData,
        setFormData,
        errors,
        setErrors,
        updateFieldData,
        handleSubmit,
        handleReset,
    } = useForm(initialValues, categoriesSchema, handleFormSubmit);

    const normalizeStatus = (is_active) => (is_active ? "Active" : "Inactive");

    const { mutate: fetchCategories } = useReusableMutation({
        onSuccess: (data) => {
            const rows = (data?.data ?? []).map((item) => ({
                id: item.id,
                name: item.name,
                description: item.description,
                status: item.status === "active" ? "Active" : "Inactive",
                statusValue: item.is_active ? "active" : "inactive",
                original: item,
            }));
            setCategories(rows);
            setPaginationData((prev) => ({
                ...prev,
                totalPages: data?.pagination?.last_page,
                totalData: data?.pagination?.total,
            }));
        },
        onError: (err) => {
            error(err?.response?.data?.message);
        },
    });

    const { mutate: saveCategory } = useReusableMutation({
        onSuccess: () => {
            setShowModal(false);
            setEditData(null);
            setRowId(null);
            handleReset();
            setPaginationData((prev) => ({ ...prev, pageIndex: 0 }));
            loadCategories();
        },
        onError: (err) => {
            error(err?.response?.data?.message);
        },
    });

    const { mutate: deleteCategory } = useReusableMutation({
        onSuccess: () => {
            setIsDeleteModal(false);
            setRowId(null);
            setPaginationData((prev) => ({ ...prev, pageIndex: 0 }));
            loadCategories();
        },
        onError: (err) => {
            error(err?.response?.data?.message);
        },
    });

    function loadCategories() {
        fetchCategories({
            endPoint: "api/admin/thing-categories/index",
            method: "POST",
            payload: {
                per_page: paginationData.pageSize,
                page: paginationData.pageIndex + 1,
                search: searchTerm,
            },
            token,
        });
    }

    const handleRowClick = (row) => {


        setDisableForm(true);
        setEditData(row);
        setRowId(row.id);
        setErrors({});
        setFormData({
            name: row.name,
            description: row.description ?? "",
            status: row.status === "Active" ? "active" : "inactive",
        });
        setShowModal(true);
    };
    useEffect(() => {
        loadCategories();
        if (apiControl) setTimeout(() => setApiControl(false), 2000);
    }, []);

    useEffect(() => {
        if (!apiControl) loadCategories();
    }, [paginationData.pageIndex, paginationData.pageSize]);

    useEffect(() => {
        if (apiControl) return;
        if (searchTerm.length !== 0 && searchTerm.length < 3) return;
        const timerId = setTimeout(() => {
            setPaginationData((prev) => ({ ...prev, pageIndex: 0 }));
            loadCategories();
        }, 300);
        return () => clearTimeout(timerId);
    }, [searchTerm]);

    function openModal() {
        setEditData(null);
        setRowId(null);
        setFormData(initialValues);
        setErrors({});
        setDisableForm(false);
        setShowModal(true);
    }

    function handleFormSubmit() {
        const payload = {
            name: formData.name,
            description: formData.description || "",
            status: formData.status,
        };

        const endPoint = editData
            ? "api/admin/thing-categories/update"
            : "api/admin/thing-categories/store";
        if (editData) payload.id = rowId;

        saveCategory({ endPoint, method: "POST", payload, token });
    }

    function handleEdit(e, row) {
        e.stopPropagation();
        setEditData(row.original);
        setRowId(row.id);
        setFormData({
            name: row.name,
            description: row.description || "",
            status: row.status === "Active" ? "active" : "inactive",
        });
        setErrors({});
        setShowModal(true);
        setDisableForm(false);
    }

    function handleDelete(e, row) {
        e.stopPropagation();
        setRowId(row.id);
        setIsDeleteModal(true);
    }

    function confirmDelete() {
        deleteCategory({
            endPoint: "api/admin/thing-categories/delete",
            method: "DELETE",
            payload: { id: rowId },
            token,
        });
    }

    const columns = [
        { key: "name", label: "Name" },
        { key: "description", label: "DESCRIPTION" },
        {
            key: "status",
            label: "STATUS",
            render: (value) => (
                <span
                    className={`px-3 py-1 rounded-full text-xs font-medium ${value === "Active"
                        ? "bg-green-100 text-green-700"
                        : "bg-red-100 text-red-700"
                        }`}
                >
                    {value}
                </span>
            ),
        },
        {
            key: "action",
            label: "ACTIONS",
            render: (_, row) => (
                <div className="flex gap-3 justify-start">
                    <div
                        className="w-[30px] h-[30px] rounded-full flex items-center justify-center bg-[#F4F4F4] cursor-pointer"
                        onClick={(e) => handleEdit(e, row)}
                    >
                        <img src={Edit} alt="edit" />
                    </div>
                    <div
                        className="w-[30px] h-[30px] rounded-full flex items-center justify-center bg-[#F4F4F4] cursor-pointer"
                        onClick={(e) => handleDelete(e, row)}
                    >
                        <img src={Delete} alt="delete" />
                    </div>
                </div>
            ),
        },
    ];

    return (
        <div className="w-full pt-[15px]">
            <div className="w-full space-y-6">
                <PageHeader title="Service Categories" />

                <div className="bg-white border border-black/10 flex justify-between rounded-2xl shadow-sm p-6 text-gray-500">
                    <div className="xs:max-w-45  xsmm:w-[70%] xl:max-w-100 xsmm:max-w-75 flex gap-2 items-center rounded-2xl border border-black/10 4x:p-2 md:p-1">
                        <img
                            src={SearchIcon}
                            alt=""
                            srcSet=""
                            className="w-5 h-5"
                        />
                        <input
                            type="search"
                            onChange={onChange}
                            placeholder="Search Member"
                            value={searchTerm ? searchTerm : ""}
                            name="search"
                            id="search"
                            className="w-full outline-none p-1 placeholder:md:text-sm placeholder:4xl:text-16px placeholder:xs:text-sm"
                        />
                    </div>
                    {isDesktop && (
                        <button
                            onClick={openModal}
                            className="flex items-center gap-2 bg-[#0aad0a] hover:bg-[#089408]  text-white text-sm font-semibold px-4 py-2.5 rounded-lg transition-colors cursor-pointer"
                        >
                            <svg
                                width="16"
                                height="16"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                            >
                                <line x1="12" y1="5" x2="12" y2="19" />
                                <line x1="5" y1="12" x2="19" y2="12" />
                            </svg>
                            Add Categories
                        </button>
                    )}
                    {
                        !isDesktop && (
                            <div className="fixed  bottom-20 right-5  z-99">
                                <button
                                    onClick={openModal} className="bg-[#099309] cursor-pointer hover:bg-[#077c07] text-3xl text-white px-4 py-2 rounded-full font-medium transition">
                                    +
                                </button>
                            </div>
                        )
                    }
                </div>

                <div>
                    {isDesktop ? (
                        <DataTable
                            columns={columns}
                            data={categories}
                            pageSize={10}
                            pageSizeOptions={[10, 30, 50]}
                            searchable={false}
                            searchPlaceholder="Search categories..."
                            tableHeight={480}
                            showCheckbox={false}
                            onRowClick={handleRowClick}
                            pagination={true}
                            paginationData={paginationData}
                            setPaginationData={setPaginationData}
                        />
                    ) : (
                        <>
                            <div className="grid grid-cols-1 gap-5">
                                {categories.map((row) => (
                                    <UserCard
                                        key={row.id}
                                        name={row.name}
                                        onClick={() => handleRowClick(row)} 
                                        email={row.description || "-"}
                                        showRoomBuilding={false}
                                        trucate={false}
                                        status={row.status}
                                        onEdit={(e) => handleEdit(e, row)}
                                        onDelete={(e) => handleDelete(e, row)}
                                    />
                                ))}
                            </div>
                            {paginationData.totalPages > 0 && (
                                <div className="pb-[120px]">
                                    <div className="flex items-center justify-center m-0 ">
                                        <p className="text-center font-regular text-sm  m-0">
                                            Showing{" "}
                                            {paginationData.totalData === 0
                                                ? 0
                                                : paginationData.pageIndex *
                                                paginationData.pageSize +
                                                1}{" "}
                                            to{" "}
                                            {Math.min(
                                                (paginationData.pageIndex + 1) *
                                                paginationData.pageSize,
                                                paginationData.totalData,
                                            )}{" "}
                                            of {paginationData.totalData}{" "}
                                            entries
                                        </p>
                                    </div>
                                    <div className="flex justify-center ">
                                        <ReactPaginate
                                            breakLabel="..."
                                            nextLabel=">"
                                            previousLabel="<"
                                            pageCount={
                                                paginationData.totalPages
                                            }
                                            forcePage={paginationData.pageIndex}
                                            onPageChange={(selectedItem) => {
                                                setPaginationData((prev) => ({
                                                    ...prev,
                                                    pageIndex:
                                                        selectedItem.selected,
                                                }));
                                            }}
                                            containerClassName="flex items-center gap-2"
                                            pageClassName="border rounded-full"
                                            pageLinkClassName="!w-[23px] h-[23px] flex items-center justify-center"
                                            activeClassName="bg-[#099309] text-white border-[#099309]"
                                            previousClassName=" rounded-lg"
                                            previousLinkClassName="px-3 py-2 block"
                                            nextClassName=" rounded-lg"
                                            nextLinkClassName="px-3 py-2 block"
                                            disabledClassName="opacity-50 cursor-not-allowed"
                                        />
                                    </div>
                                </div>
                            )}
                        </>
                    )}
                </div>

            </div>
            <Modal
                isOpen={showModal}
                onClose={() => {
                    setShowModal(false);
                    setEditData(null);
                    setRowId(null);
                    setDisableForm(false);
                }}
                title={disableForm ? "Service Categories Details" : editData ? "Edit Category" : "Add Category"}
                showCloseButton
                outSideClick
                size="medium"
                width="w-full max-w-md"
            >
                <div className="mt-4">
                    <ServiceCategoriesForm
                        formData={formData}
                        errors={errors}
                        updateFieldData={updateFieldData}
                        setFormData={setFormData}
                        handleCancel={() => {
                            setShowModal(false);
                            setEditData(null);
                            setRowId(null);
                            setDisableForm(false);
                            handleReset();
                        }}
                        handleSubmit={handleSubmit}
                        addDisabled={false}
                        rowId={rowId}
                        disableForm={disableForm}
                    />
                </div>
            </Modal>

            <Modal
                isOpen={isDeleteModal}
                onClose={() => setIsDeleteModal(false)}
                title="Delete Category"
                showCloseButton
                outSideClick
                size="medium"
                width="w-full max-w-sm"
            >
                <div className="mt-4">
                    <p className="text-sm text-gray-500 mb-6">
                        Are you sure you want to delete this category? This
                        action cannot be undone.
                    </p>
                    <div className="flex justify-end gap-3">
                        <button
                            onClick={() => setIsDeleteModal(false)}
                            className="px-4 py-2 rounded-lg border border-gray-300 text-sm font-medium text-gray-700 hover:bg-gray-50 cursor-pointer"
                        >
                            Cancel
                        </button>
                        <button
                            onClick={confirmDelete}
                            className="px-4 py-2 rounded-lg bg-red-500 hover:bg-red-600 text-white text-sm font-medium cursor-pointer"
                        >
                            Delete
                        </button>
                    </div>
                </div>
            </Modal>
        </div>
    );
};

export default ServiceCategories;
