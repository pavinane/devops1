import React from "react";
import TextInput from "../../components/commonComponents/TextInput";
import { useMediaQueryValues } from "../../components/commonComponents/MediaQueryContext";
import PrimaryButton from "../../components/commonComponents/PrimaryButton";
import SelectInput from "../../components/commonComponents/SelectInput";
import RadioButton from "../../components/commonComponents/RadioButton";

const statusOptions = [
    { value: "active", label: "Active" },
    { value: "inactive", label: "Inactive" },
];

const ServiceCategoriesForm = ({
    formData,
    errors,
    disableForm,
    handleCancel,
    addDisabled,
    rowId,
    handleSubmit,
    updateFieldData,
}) => {
    const { isDesktop } = useMediaQueryValues();

    return (
        <div>
            <div
                autoComplete="off"
                className={`relative flex mt-3 flex-col ${!isDesktop && "max-h-[70vh] "} overflow-y-auto`}
            >
                <TextInput
                    maxLength={151}
                    label="Name"
                    name="name"
                    placeholder="Enter category name"
                    value={formData?.name}
                    onChange={(value, name) => {
                        updateFieldData(value, name);
                    }}
                    error={errors?.name}
                    disabled={disableForm}
                    width={"!mb-0"}
                    required
                />
                <TextInput
                    maxLength={255}
                    label="Description"
                    name="description"
                    placeholder="Enter category description"
                    value={formData?.description}
                    onChange={(value, name) => {
                        updateFieldData(value, name);
                    }}
                    error={errors?.description}
                    disabled={disableForm}
                    width={"!mb-0"}
                    required
                />
                <RadioButton
                    label={"Status"}
                    options={statusOptions}
                    selectedOption={formData?.status}
                    name="status"
                    onSelect={(value, name) => updateFieldData(value, name)}
                    disabled={disableForm}
                />
            </div>
            <div className={`flex p-4`}>
                {!disableForm && (
                    <div className={`flex gap-4 justify-end w-full`}>
                        <PrimaryButton
                            title="Cancel"
                            onClick={handleCancel}
                            buttonType="button"
                            customClass="w-[100px] bg-transparent text-black! hover:bg-[#cbf5cb] hover:border-[#black] hover:text-black transition-colors duration-500"
                            disable={disableForm}
                        />
                        <PrimaryButton
                            title={
                                addDisabled
                                    ? "Loading..."
                                    : rowId
                                      ? "Update"
                                      : "Create"
                            }
                            onClick={handleSubmit}
                            buttonType="submit"
                            customClass="w-[100px] hover:bg-[#077c07] transition-colors duration-500"
                            disable={disableForm || addDisabled}
                            btnBorder={"border-none"}
                        />
                    </div>
                )}
            </div>
        </div>
    );
};

export default ServiceCategoriesForm;
