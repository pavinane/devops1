import React, { useState, useEffect } from "react";
import { Check, X } from "lucide-react";
import Modal from "../../components/commonComponents/Modal";
import ServiceCard from "../../components/commonComponents/ServiceCard";
import SelectInput from "../../components/commonComponents/SelectInput";
import CommonDatePicker from "../../components/commonComponents/CommonDatePicker";
import DataTable from "../../components/commonComponents/DataTable";
import useForm from "../../components/commonComponents/useForm";
import FoodReportIcon from "../food-report/FoodReportIcon";
import { useReusableMutation } from "../../customHooks/useDataQuery";
import { useSelector } from "react-redux";
import PageHeader from "../../components/commonComponents/PageHeader";
import { useToast } from "../../components/ToastContext";
import SearchIcon from "../../assets/icons/search.svg";
import { useMediaQueryValues } from "../../components/commonComponents/MediaQueryContext";
import MobileTableCard from "../../components/commonComponents/MobileTableCard";
import ReactPaginateModule from "react-paginate";

const BASE_URL = `${import.meta.env.AWS_IMAGE_URL}/`;

const capitalizeFirst = (str) =>
    str ? str.charAt(0).toUpperCase() + str.slice(1) : "";

const ServiceRequest = ({ onExport }) => {
    const ReactPaginate = ReactPaginateModule.default;
    const [date, setDate] = useState("");
    const [dashboardData, setDashboardData] = useState([]);
    const { token } = useSelector((state) => state.user);
    const [buildingOptions, setBuildingOptions] = useState([]);
    const [showApproveModal, setShowApproveModal] = useState(false);
    const [showRejectModal, setShowRejectModal] = useState(false);
    const [selectedRequest, setSelectedRequest] = useState(null);
    const [adminNotes, setAdminNotes] = useState("");
    const [apiControl, setApiControl] = useState(true);
    const [searchTerm, setSearchTerm] = useState("");
    const { success, error, warning, info, showToast } = useToast();
    const [deliveredRows, setDeliveredRows] = useState([]);
    const { isDesktop } = useMediaQueryValues();
    const [previewImage, setPreviewImage] = useState(null);
    const [dashboardCardData, setDashboardCardData] = useState({
        pending: 0,
        approved: 0,
        rejected: 0,
        fulfilled: 0,
    });
    const statusOptions = [
        { label: "All Status", value: "" },
        { label: "Pending", value: "pending" },
        { label: "Approved", value: "approved" },
        { label: "Rejected", value: "rejected" },
        { label: "Fulfilled", value: "fulfilled" },
    ];
    const [paginationData, setPaginationData] = useState({
        pageSize: 10,
        pageIndex: 0,
        totalPages: 0,
        totalData: 0,
    });
    const initialForm = { building: "", status: "" };
    const { formData, errors, updateFieldData } = useForm(initialForm, {});

    const { mutate: buildingList } = useReusableMutation({
        onSuccess: (data) => {
            const opts = [
                { label: "All Buildings", value: "" },
                ...(data?.data ?? [])
                    .filter((item) => item.id)
                    .map((item) => ({ label: item.name, value: item.id })),
            ];
            setBuildingOptions(opts);
        },
        onError: (err) => {
            error(err?.response?.data?.message);
        },
    });

    const fetchBuildings = () => {
        buildingList({
            endPoint: "api/buildings/list",
            method: "GET",
            payload: {
                is_building: "true",
            },
            token,
        });
    };

    const { mutate: fetchRequests } = useReusableMutation({
        onSuccess: (data) => {
            const rows = (data?.data ?? []).map((req) => ({
                id: req?.id,
                room: req?.room_number,
                building: req?.building_name,
                item: req?.items,
                qty: req?.quantity,
                description:req?.description,
                requestedBy: req?.request_by,
                date: new Date(req?.requested_date)
                    .toLocaleDateString("en-GB")
                    .replace(/\//g, "-"),
                notes: req?.notes,
                status: capitalizeFirst(req?.status),
                attachment_path: req?.attachment_path
                    ? req?.attachment_path 
                    : null,
            }));
            setDashboardData(rows);
            setDashboardCardData(data?.counts || {});
            setPaginationData((prev) => ({
                ...prev,
                totalPages: data?.pagination?.last_page,
                totalData: data?.pagination?.total,
            }));
        },
        onError: (err) => {
            error(err?.response?.data?.message);
        },
    });

    const loadRequests = () => {
        fetchRequests({
            endPoint: "api/admin/thing-requests/index",
            method: "POST",
            payload: {
                status: formData.status?.value || undefined,
                building_id: formData.building?.value || undefined,
                date: date || undefined,
                per_page: paginationData.pageSize,
                page: paginationData.pageIndex + 1,
                search: searchTerm,
            },
            token,
        });
    };

    React.useEffect(() => {
        fetchBuildings();
    }, []);

    React.useEffect(() => {
        if (token) {
            loadRequests();
            if (apiControl) setTimeout(() => setApiControl(false), 2000);
        }
    }, [token]);

    React.useEffect(() => {
        if (!apiControl) loadRequests();
    }, [paginationData.pageIndex, paginationData.pageSize]);

    React.useEffect(() => {
        if (apiControl) return;
        setPaginationData((prev) => ({ ...prev, pageIndex: 0 }));
        loadRequests();
    }, [formData.status, formData.building, date]);

    React.useEffect(() => {
        if (apiControl) return;
        if (searchTerm.length !== 0 && searchTerm.length < 3) return;
        const timerId = setTimeout(() => {
            setPaginationData((prev) => ({ ...prev, pageIndex: 0 }));
            loadRequests();
        }, 300);
        return () => clearTimeout(timerId);
    }, [searchTerm]);

   
    const handleApprove = (e, row) => {
        e.stopPropagation();
        setSelectedRequest(row);
        setAdminNotes("");
        setShowApproveModal(true);
    };

    const handleReject = (e, row) => {
        e.stopPropagation();
        setSelectedRequest(row);
        setAdminNotes("");
        setShowRejectModal(true);
    };

    const handleDeliver = (e, row) => {
        e.stopPropagation();
        setDeliveredRows((prev) => [...prev, row.id]);
    };

    const columns = [
        {
            key: "room",
            label: "ROOM",
        },
        {
            key: "building",
            label: "BUILDING",
        },
        {
            key: "item",
            label: "ITEM",
        },
        {
            key: "qty",
            label: "QTY",
        },
        {
            key: "requestedBy",
            label: "REQUEST BY",
        },
        {
            key: "date",
            label: "DATE",
        },
        {
            key: "description",
            label: "DESCRIPTION",
        },
        {
            key: "status",
            label: "STATUS",
            render: (value) => (
                <span
                    className={`px-3 py-1 rounded-full text-xs font-medium ${
                        value === "Approved"
                            ? "bg-green-100 text-green-700"
                            : "bg-red-100 text-red-700"
                    }`}
                >
                    {value}
                </span>
            ),
        },
        {
            key: "notes",
            label: "NOTES",
            render: (value) => (
                <span
                    className="text-sm text-gray-600 truncate max-w-xs"
                    title={value}
                >
                    {value || "-"}
                </span>
            ),
        },
        {
            key: "actions",
            label: "ACTIONS",
            render: (_, row) => {
                if (
                    deliveredRows.includes(row.id) ||
                    row.status === "Fulfilled"
                ) {
                    return (
                        <span className="px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-700">
                            Delivered
                        </span>
                    );
                }

                if (row.status === "Approved") {
                    return (
                        <button
                            type="button"
                            onClick={(e) => handleDeliver(e, row)}
                            className="px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700 hover:bg-green-200 cursor-pointer transition"
                        >
                            Approved
                        </button>
                    );
                }

                if (row.status === "Rejected") {
                    return (
                        <span className="px-3 py-1 rounded-full text-xs font-medium bg-red-100 text-red-700">
                            Rejected
                        </span>
                    );
                }

                return (
                    <div className="flex items-center gap-2">
                        <button
                            type="button"
                            onClick={(e) => handleApprove(e, row)}
                            className="w-[34px] h-[34px] rounded-full bg-green-50 border border-green-200 flex items-center justify-center hover:bg-green-100 transition cursor-pointer"
                        >
                            <Check size={16} className="text-green-600" />
                        </button>
                        <button
                            type="button"
                            onClick={(e) => handleReject(e, row)}
                            className="w-[34px] h-[34px] rounded-full bg-red-50 border border-red-200 flex items-center justify-center hover:bg-red-100 transition cursor-pointer"
                        >
                            <X size={16} className="text-red-600" />
                        </button>
                    </div>
                );
            },
        },
          {
    key: "attachment_path",
    label: "ATTACHMENT",
    render: (value) =>
        value ? (
            <span
                onClick={(e) => {
                    e.stopPropagation();
                    setPreviewImage(value);
                }}
                className="text-sm text-blue-600 underline cursor-pointer hover:text-blue-800"
            >
                Preview
            </span>
        ) : (
            <span className="text-sm text-gray-400">-</span>
        ),
},
    ];

    const { mutate: approveRequest } = useReusableMutation({
        onSuccess: () => {
            setShowApproveModal(false);
            setSelectedRequest(null);
            setAdminNotes("");
            loadRequests();
        },
        onError: (err) => {
            error(err?.response?.data?.message);
        },
    });

    const { mutate: rejectRequest } = useReusableMutation({
        onSuccess: () => {
            setShowRejectModal(false);
            setSelectedRequest(null);
            setAdminNotes("");
            loadRequests();
        },
        onError: (err) => {
            error(err?.response?.data?.message);
        },
    });

    const handleConfirmApprove = () => {
        if (!selectedRequest) return;
        approveRequest({
            endPoint: "api/admin/thing-requests/approve",
            method: "POST",
            payload: {
                id: selectedRequest.id,
                remarks: adminNotes,
            },
            token,
        });
    };

    const handleConfirmReject = () => {
        if (!selectedRequest) return;
        rejectRequest({
            endPoint: "api/admin/thing-requests/reject",
            method: "POST",
            payload: {
                id: selectedRequest.id,
                remarks: adminNotes,
            },
            token,
        });
    };

    const { mutate: exportExcel, isPending: exportingExcel } =
        useReusableMutation({
            onSuccess: (data) => {
                const url = window.URL.createObjectURL(new Blob([data]));
                const a = document.createElement("a");
                a.href = url;
                a.download = "thing-requests.xlsx";
                a.click();
                window.URL.revokeObjectURL(url);
            },
            onError: (err) => {
                error(err?.response?.data?.message);
            },
        });

    const { mutate: exportPdf, isPending: exportingPdf } = useReusableMutation({
        onSuccess: (data) => {
            const url = window.URL.createObjectURL(new Blob([data]));
            const a = document.createElement("a");
            a.href = url;
            a.download = "thing-requests.pdf";
            a.click();
            window.URL.revokeObjectURL(url);
        },
        onError: (err) => {
            error(err?.response?.data?.message);
        },
    });

    const handleExcelExport = () => {
        exportExcel({
            endPoint: "api/admin/thing-requests/export",
            method: "POST",
            payload: { format: "xlsx" },
            token,
            responseType: "blob",
        });
    };

    const handlePdfExport = () => {
        exportPdf({
            endPoint: "api/admin/thing-requests/export",
            method: "POST",
            payload: { format: "pdf" },
            token,
            responseType: "blob",
        });
    };

    return (
        <>
            <div className="flex w-full flex-col gap-6 pt-[15px]">
                <PageHeader title="Order & Requests" />
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                    <ServiceCard
                        title="Pending"
                        count={dashboardCardData?.pending}
                    />
                    <ServiceCard
                        title="Approved"
                        count={dashboardCardData?.approved}
                        badgeBg="#D1FAE5"
                        badgeColor="#047857"
                    />
                    <ServiceCard
                        title="Rejected"
                        count={dashboardCardData?.rejected}
                    />
                    <ServiceCard
                        title="Fulfilled"
                        count={dashboardCardData?.fulfilled}
                        badgeBg="#D1FAE5"
                        badgeColor="#047857"
                    />
                </div>

                <div className="bg-white border border-gray-200 rounded-2xl p-4 sm:p-6 flex flex-col gap-3">
                    <div className="flex items-center gap-2 rounded-2xl border border-black/10 px-2 py-1 max-w-xs">
                        <img src={SearchIcon} alt="" className="w-5 h-5" />
                        <input
                            type="search"
                            onChange={(e) => setSearchTerm(e.target.value)}
                            placeholder="Search requests"
                            value={searchTerm}
                            className="w-full outline-none p-1 text-sm"
                        />
                    </div>
                    <div className="flex flex-col lg:flex-row gap-3 sm:gap-6">
                        <div className="flex-1 min-w-0">
                            <SelectInput
                                label="Status"
                                name="status"
                                value={formData?.status}
                                options={statusOptions}
                                placeholder="All Status"
                                errors={errors?.status}
                                onChange={updateFieldData}
                            />
                        </div>
                        <div className="flex-1 min-w-0">
                            <SelectInput
                                label="Building"
                                name="building"
                                value={formData?.building}
                                options={buildingOptions}
                                placeholder="All Buildings"
                                errors={errors?.building}
                                onChange={updateFieldData}
                            />
                        </div>
                        <div className="flex-1 min-w-0">
                            <CommonDatePicker
                                label="Date"
                                name="date"
                                value={date}
                                onChange={(e) => setDate(e.target.value)}
                                min={new Date().toISOString().split("T")[0]}
                            />
                        </div>
                        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 pb-0 sm:pb-1">
                            <button
                                onClick={handleExcelExport}
                                disabled={exportingExcel}
                                className="items-center gap-1.5 px-3 py-2 border border-[#0aad0a] rounded-lg text-sm font-semibold text-[#0aad0a] hover:bg-gray-50 transition cursor-pointer flex justify-center disabled:opacity-60"
                            >
                                <FoodReportIcon name="excel" />{" "}
                                {exportingExcel ? "Exporting…" : "Excel"}
                            </button>
                            <button
                                onClick={handlePdfExport}
                                disabled={exportingPdf}
                                className="items-center gap-1.5 px-3 py-2 border border-red-200 rounded-lg text-sm font-semibold text-red-600 hover:bg-red-50 transition cursor-pointer flex justify-center disabled:opacity-60"
                            >
                                <FoodReportIcon name="picture_as_pdf" />{" "}
                                {exportingPdf ? "Exporting…" : "PDF"}
                            </button>
                        </div>
                    </div>
                </div>

                <div>
                    {isDesktop ? (
                        <DataTable
                            columns={columns}
                            data={dashboardData}
                            pageSize={10}
                            searchable={false}
                            pageSizeOptions={[10, 30, 50]}
                            showCheckbox={false}
                            pagination={true}
                            paginationData={paginationData}
                            setPaginationData={setPaginationData}
                        />
                    ) : (
                        <>
                            <div className="grid grid-cols-1 gap-4 px-2">
                                {dashboardData.map((row) => (
                                    <MobileTableCard
                                        key={row.id}
                                        fields={[
                                            { label: "Room", value: row?.room },
                                            {
                                                label: "Building",
                                                value: row?.building,
                                            },
                                            { label: "Item", value: row?.item },
                                            { label: "Qty", value: row?.qty },
                                            {
                                                label: "Request By",
                                                value: row?.requestedBy,
                                            },
                                            { label: "Date", value: row?.date },
                                            {
                                                label: "Notes",
                                                value: row?.notes,
                                            },
                                            {
                                                label: "Description",
                                                value: row?.description,
                                            },
                                        ]}
                                        status={
                                            <span
                                                className={`px-3 py-1 rounded-full text-xs font-medium ${
                                                    row.status === "Approved"
                                                        ? "bg-green-100 text-green-700"
                                                        : row.status ===
                                                            "Rejected"
                                                          ? "bg-red-100 text-red-700"
                                                          : "bg-red-100 text-red-700"
                                                }`}
                                            >
                                                {row.status}
                                            </span>
                                        }
                                      customContent={
  row?.attachment_path ? (
    <div className="pt-2 border-t border-gray-100">
      <p className="text-xs text-gray-400 mb-1">
        Attachment
      </p>
      <span
        onClick={(e) => {
          e.stopPropagation();
          setPreviewImage(row.attachment_path);
        }}
        className="text-sm text-blue-600 underline cursor-pointer hover:text-blue-800"
      >
        Preview
      </span>
    </div>
  ) : (
    <span className="text-sm text-gray-400">-</span>
  )
}
                                        actions={
                                            deliveredRows.includes(row.id) ||
                                            row.status === "Fulfilled" ? (
                                                <span className="px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-700">
                                                    Delivered
                                                </span>
                                            ) : row.status === "Approved" ? (
                                                <button
                                                    type="button"
                                                    onClick={(e) =>
                                                        handleDeliver(e, row)
                                                    }
                                                    className="px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700 hover:bg-green-200 cursor-pointer transition"
                                                >
                                                    Approved
                                                </button>
                                            ) : row.status === "Rejected" ? (
                                                <span className="px-3 py-1 rounded-full text-xs font-medium bg-red-100 text-red-700">
                                                    Rejected
                                                </span>
                                            ) : (
                                                <div className="flex gap-2">
                                                    <button
                                                        type="button"
                                                        onClick={(e) =>
                                                            handleApprove(
                                                                e,
                                                                row,
                                                            )
                                                        }
                                                        className="w-[34px] h-[34px] rounded-full bg-green-50 border border-green-200 flex items-center justify-center hover:bg-green-100 transition cursor-pointer"
                                                    >
                                                        <Check
                                                            size={16}
                                                            className="text-green-600"
                                                        />
                                                    </button>
                                                    <button
                                                        type="button"
                                                        onClick={(e) =>
                                                            handleReject(e, row)
                                                        }
                                                        className="w-[34px] h-[34px] rounded-full bg-red-50 border border-red-200 flex items-center justify-center hover:bg-red-100 transition cursor-pointer"
                                                    >
                                                        <X
                                                            size={16}
                                                            className="text-red-600"
                                                        />
                                                    </button>
                                                </div>
                                            )
                                        }
                                    />
                                ))}
                            </div>
                            {paginationData.totalPages > 0 && (
                                <div className="pb-[120px]">
                                    <div className="flex items-center justify-center m-0">
                                        <p className="text-center font-regular text-sm m-0">
                                            Showing{" "}
                                            {paginationData.totalData === 0
                                                ? 0
                                                : paginationData.pageIndex *
                                                      paginationData.pageSize +
                                                  1}{" "}
                                            to{" "}
                                            {Math.min(
                                                (paginationData.pageIndex + 1) *
                                                    paginationData.pageSize,
                                                paginationData.totalData,
                                            )}{" "}
                                            of {paginationData.totalData}{" "}
                                            entries
                                        </p>
                                    </div>
                                    <div className="flex justify-center">
                                        <ReactPaginate
                                            breakLabel="..."
                                            nextLabel=">"
                                            previousLabel="<"
                                            pageCount={
                                                paginationData.totalPages
                                            }
                                            forcePage={paginationData.pageIndex}
                                            onPageChange={(selectedItem) => {
                                                setPaginationData((prev) => ({
                                                    ...prev,
                                                    pageIndex:
                                                        selectedItem.selected,
                                                }));
                                            }}
                                            containerClassName="flex items-center gap-2"
                                            pageClassName="border rounded-full"
                                            pageLinkClassName="!w-[23px] h-[23px] flex items-center justify-center"
                                            activeClassName="bg-[#099309] text-white border-[#099309]"
                                            previousClassName="rounded-lg"
                                            previousLinkClassName="px-3 py-2 block"
                                            nextClassName="rounded-lg"
                                            nextLinkClassName="px-3 py-2 block"
                                            disabledClassName="opacity-50 cursor-not-allowed"
                                        />
                                    </div>
                                </div>
                            )}
                        </>
                    )}
                </div>
            </div>

            {/* Approve Modal */}
            <Modal
                isOpen={showApproveModal}
                onClose={() => setShowApproveModal(false)}
                title="Approve Request"
                showCloseButton
                outSideClick
                size="medium"
                width="w-full max-w-md"
            >
                <div className="mt-4">
                    <textarea
                        rows={4}
                        value={adminNotes}
                        onChange={(e) => setAdminNotes(e.target.value)}
                        placeholder="Admin notes (optional)"
                        className="w-full rounded-xl border border-gray-300 p-3 text-sm text-gray-700 focus:outline-none"
                    />
                    <div className="flex justify-end gap-3 mt-5">
                        <button
                            type="button"
                            onClick={() => setShowApproveModal(false)}
                            className="px-4 py-2 rounded-lg border border-gray-300 text-sm font-medium text-gray-700 hover:bg-gray-50 cursor-pointer"
                        >
                            Cancel
                        </button>
                        <button
                            type="button"
                            onClick={handleConfirmApprove}
                            className="px-4 py-2 rounded-lg bg-green-600 text-white text-sm font-medium hover:bg-green-700 cursor-pointer"
                        >
                            Approve
                        </button>
                    </div>
                </div>
            </Modal>

            {/* Reject Modal */}
            <Modal
                isOpen={showRejectModal}
                onClose={() => setShowRejectModal(false)}
                title="Reject Request"
                showCloseButton
                outSideClick
                size="medium"
                width="w-full max-w-md"
            >
                <div className="mt-4">
                    <textarea
                        rows={4}
                        value={adminNotes}
                        onChange={(e) => setAdminNotes(e.target.value)}
                        placeholder="Admin notes (optional)"
                        className="w-full rounded-xl border border-gray-300 p-3 text-sm text-gray-700  focus:outline-none"
                    />
                    <div className="flex justify-end gap-3 mt-5">
                        <button
                            type="button"
                            onClick={() => setShowRejectModal(false)}
                            className="px-4 py-2 rounded-lg border border-gray-300 text-sm font-medium text-gray-700 hover:bg-gray-50 cursor-pointer"
                        >
                            Cancel
                        </button>
                        <button
                            type="button"
                            onClick={handleConfirmReject}
                            className="px-4 py-2 rounded-lg bg-red-600 text-white text-sm font-medium hover:bg-red-700 cursor-pointer"
                        >
                            Reject
                        </button>
                    </div>
                </div>
            </Modal>

            <Modal
                isOpen={!!previewImage}
                onClose={() => setPreviewImage(null)}
                showCloseButton={true}
                size="large"
                width="w-full max-w-4xl"
                //   title="Attachment Preview"
            >
                <div className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4">
                    <button
                        onClick={() => setPreviewImage(null)}
                        className="absolute top-4 right-4 w-9 h-9 cursor-pointer rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors"
                    >
                        <svg
                            width="18"
                            height="18"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="white"
                            strokeWidth="2.5"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                        >
                            <line x1="18" y1="6" x2="6" y2="18" />
                            <line x1="6" y1="6" x2="18" y2="18" />
                        </svg>
                    </button>
                    <img
                        src={previewImage}
                        alt="Full preview"
                        width={"50%"}
                        height={"50%"}
                        onClick={(e) => e.stopPropagation()}
                        className="max-w-full max-h-[90vh] object-contain rounded-lg"
                    />
                </div>
            </Modal>
        </>
    );
};

export default ServiceRequest;