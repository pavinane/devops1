import React from 'react';


const Building = () => (
  <>
  
    <main>
      <section>
        <h1>Welcome to the Building Page</h1>
  
     
      </section>
    </main>
  </>
);

export default Building;
