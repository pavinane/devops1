import React from "react";
import ErrorTemplate from "./ErrorTemplate";
function PageNotFound() {
    return (
        <div>
            <ErrorTemplate
                svg={                  //error page svg from errors folder
                    <img src="/404-bg.png" style={{ width: "70vw", height: "auto", aspectRatio: "2/1", objectFit: "cover" }} alt="Page Not Found" />
                }
                errorTitle={"Page Not Found"}
                errorContent={" Page not found. Check the URL."}
                navigateLink={-1}
            />
        </div>
    );
}

export default PageNotFound;
