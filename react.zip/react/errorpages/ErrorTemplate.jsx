import React from "react";
// import PrimaryButton from '../../components/button/PrimaryButton';
import { useSelector } from "react-redux";
import PrimaryButton from "../components/PrimaryButton";


function ErrorTemplate({ errorTitle = "", errorContent = "We are sorry but the page you are looking for does not exist.", buttonText = "Back to Home", navigateLink = "", svg = "" }) {

    const handleClick = () => {
        if (typeof navigateLink === "number") {
            window.history.go(navigateLink);
            return;
        }

        window.location.assign(navigateLink || "/");
    };
    const { theme } = useSelector((state) => state.theme);

    return (
        <div>
            <section
                className={`w-full min-h-screen px-4 py-8 sm:px-6 sm:py-10 md:p-10 flex flex-col justify-center items-center overflow-hidden rounded-[10px] ${theme === "dark" ? "bg-background-light" : "bg-background-dark"
                    }`}
            >
                <div className="w-full max-w-[70vw] sm:max-w-[75vw] pt-0 flex flex-col justify-center items-center ">
                    {svg}
                </div>
                <div className="text-center max-w-[90vw] sm:max-w-[700px]">
                    <p className="text-[clamp(1.5rem,1vw,2rem)] text-gray-600 font-medium leading-tight">
                        {errorTitle}
                    </p>
                    <p
                        className={`text-[clamp(0.95rem,2.2vw,1.1rem)] font-medium py-2 px-2 sm:px-0 leading-relaxed ${theme === "dark"
                                ? "text-white"
                                : "text-gray-500"
                            } `}
                    >
                        {errorContent}
                    </p>
                </div>
                <div className="w-full max-w-[450px] pt-6 flex flex-col justify-center items-center ">
                    <PrimaryButton
                        title={buttonText}
                        onClick={handleClick}
                        width="w-full sm:w-[410px]"
                        bgColor="bg-primary"
                        btnBorder="border border-primary"
                        textColor="text-black"
                        customClass=""
                        disable={false}
                        type="button"
                    />
                </div>
            </section>
        </div>
    );
}
export default ErrorTemplate;
