import React, { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { Provider } from "react-redux";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { store } from "./redux/store/store";
import Routes from "./Routes";
import { ToastProvider } from "./components/ToastContext";
import "./index.css";
import { MediaQueryProvider } from "./components/commonComponents/MediaQueryContext";

const queryClient = new QueryClient();

function Main() {
  return (
    // <StrictMode>
    <QueryClientProvider client={queryClient}>
      <Provider store={store}>
        <MediaQueryProvider>
          <ToastProvider>
            <Routes />
          </ToastProvider>
        </MediaQueryProvider>
      </Provider>
    </QueryClientProvider>
    // </StrictMode>
  );
}
export default Main;
