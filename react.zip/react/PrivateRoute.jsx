import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useSelector } from "react-redux";

const PrivateRoute = ({ allowedRoles = [] }) => {
  const { isAuthenticated, roles } = useSelector((state) => state.user);
  const location = useLocation();

  const userRole = Array.isArray(roles) ? roles[0] : roles?.trim();


  if (!isAuthenticated) {
    return <Navigate to="/" state={{ from: location }} replace />;
  }


  if (allowedRoles.length > 0 && !allowedRoles.includes(userRole)) {

    const fallback = "/unauthorized";
    return <Navigate to={fallback} replace />;
  }

  return <Outlet />;
};

export default PrivateRoute;