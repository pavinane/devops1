import { configureStore } from "@reduxjs/toolkit";

import userSlice from "../slice/userSlice";
import themeSlice from "../slice/themeSlice";
import SideMenuSlice from "../slice/sideMenuSlice";
import BuildingSlice from "../slice/buildingSlice";

export const store = configureStore({
    reducer: {
        user: userSlice,
        theme: themeSlice,
        sideMenu: SideMenuSlice,
        building: BuildingSlice,
    },
});

store.subscribe(() => {
    const { theme, activeTab } = store.getState();
    localStorage.setItem("theme", JSON.stringify(theme.theme));
});
