import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    sideMenuActiveText: "Calendar",
};

const sideMenuSlice = createSlice({
    name: "sideMenu",
    initialState,
    reducers: {
        setActiveMenuSlice: (state, action) => {
            const updates = action.payload; return { ...state, ...updates, };
        },

        resetFormSideMenu: () => initialState,

        setRateFormData: (state, action) => {
            state.formRateData = action.payload
        },
    },
});

export const { setActiveMenuSlice, resetFormSideMenu, setRateFormData, } = sideMenuSlice.actions;
export default sideMenuSlice.reducer;
