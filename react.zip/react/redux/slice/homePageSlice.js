import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    stage: "Calendar",
};

const homepageSlice = createSlice({
    name: "homepageSlice",
    initialState,
    reducers: {
        setStageSlice: (state, action) => {
            const updates = action.payload; return { ...state, ...updates, };
        },
        resetHomepageSlice: () => ({ ...initialState }),


    },
});

export const { setStageSlice, resetHomepageSlice, } = homepageSlice.actions;
export default homepageSlice.reducer;
