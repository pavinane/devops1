import { createSlice } from "@reduxjs/toolkit";

const storedAuth = localStorage.getItem("authUser");
const session = storedAuth ? JSON.parse(storedAuth) : null;

// Check if session is expired
const isExpired = session?.expiresAt && Date.now() > session.expiresAt;
const validSession = session && !isExpired ? session : null;

if (isExpired) {
    localStorage.removeItem("authUser");
}

const initialState = {

    userName: validSession ? validSession?.userName : "",
    token: validSession ? validSession?.token : "",
    email: validSession ? validSession?.email : "",
    user_id: validSession ? validSession?.user_id : "",
    isAuthenticated: validSession ? validSession?.isAuthenticated : false,
    login_id: validSession ? validSession?.login_id : "",
    forgetEmail: validSession ? validSession?.forgetEmail : "",
    roles: validSession ? validSession?.roles : "",
    headerTitle: validSession ? validSession?.title : "",
    activeTab: validSession ? validSession?.activeTab : false,
    expiresAt: validSession ? validSession.expiresAt : "",
    timezone: validSession ? validSession?.timezone : "",
    selectedAvailability: validSession?.selectedAvailability ? validSession?.selectedAvailability : "Available for next 7 days",

};

const userSlice = createSlice({
    name: "user",
    initialState,
    reducers: {
        setUserState: (state, action) => {
            const updates = action.payload;
            if (updates) {
                localStorage.setItem(
                    "authUser",
                    JSON.stringify({ ...state, ...updates })
                );
                return {
                    ...state,
                    ...updates,
                };
            }
            return state;
        },

        setLogout: (state, action) => {
            localStorage.removeItem("authUser");

            return {
                userName: "",
                token: "",
                email: "",
                user_id: "",
                isAuthenticated: false,
                login_id: "",
                forgetEmail: "",
                roles: "",
                headerTitle: "",
                activeTab: false,
                timezone: "",
                selectedAvailability: "Available for next 7 days",
            };
            // Reset the state to the initial state on logout
        },
    },
});

export const { setLogout, setUserState } = userSlice.actions;
export default userSlice.reducer;
