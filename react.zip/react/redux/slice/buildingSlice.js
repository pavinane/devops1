import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    buildingId: null,
    roomId: null,
};

const buildingSlice = createSlice({
    name: "building",
    initialState,
    reducers: {
        setBuildingSlice: (state, action) => {
            const updates = action.payload;
            return { ...state, ...updates };
        },
        resetBuildingSlice: () => ({ ...initialState }),
    },
});

export const { setBuildingSlice, resetBuildingSlice } = buildingSlice.actions;
export default buildingSlice.reducer;