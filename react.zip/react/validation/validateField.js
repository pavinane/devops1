// utils/validation.js
import * as Yup from "yup";

export const createValidationSchema = (schemaDefinition) => {
    return Yup.object().shape(schemaDefinition);
};

export const validateFields = async (formData, data, schemaDefinition) => {
    const validationSchema = createValidationSchema(schemaDefinition);

    try {
        await validationSchema.validate(data, {
            context: formData,
            abortEarly: false,
        });
        return { isValid: true, errorData: [] };
    } catch (err) {
        return { isValid: false, errorData: err.inner };
    }
};
