import * as Yup from "yup";

export const ForgetPasswordSchema = {
    forgetusername: Yup.string().required("Email is required"),
};
