import * as Yup from "yup";

export const buildingSchema = {
    name: Yup.string().required("name is required"),
    location: Yup.string().required("location is required")
};