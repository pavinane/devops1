import * as Yup from "yup";

export const changePasswordSchema = {
    currentPassword: Yup.string()
        .required("Current Password is required")
        .min(8, "Current password should've at least 8 characters")
        .max(16, "Current password should not exceed 16 characters")
    ,

    newPassword: Yup.string()
        .required("New Password is required")

        .min(8, "New password should've at least 8 characters")
        .max(16, "New password should not exceed 16 characters")

        .test(
            "not-same-as-current",
            "New password cannot be the same as your old password. Please choose a different password.",
            function (value) {
                const { currentPassword } = this.parent;

                // 🔑 IMPORTANT GUARD
                if (!value || !currentPassword) return true;

                return value !== currentPassword;
            }
        )

        .matches(
            /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{8,}$/,
            "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character."
        ),

    confirmPassword: Yup.string()
        .required("Confirm Password is required")
        .min(8, "Confirm password should've at least 8 characters")
        .max(16, "Confirm password should not exceed 16 characters")
    // .oneOf(
    //     [Yup.ref('newPassword')],
    //     "Confirm password and New password must be same"
    // )
};
