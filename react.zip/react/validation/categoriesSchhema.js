import * as Yup from "yup";

export const categoriesSchema = {
    name: Yup.string().required("Name is required"),
    description: Yup.string().required("Description is required")
};