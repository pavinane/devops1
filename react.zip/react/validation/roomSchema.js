import * as Yup from "yup";

export const roomSchema = {
    room_number: Yup.string().required("Room number is required"),
    members_count:Yup.string().required("Members count is required"),
    capacity: Yup.string().required("Capacity is required"),
    floor: Yup.string().required("Floor is required"),
    
};