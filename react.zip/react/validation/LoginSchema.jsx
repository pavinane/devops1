import * as Yup from "yup";

export const LoginSchema = {
    username: Yup.string().required("Email is required"),
    password: Yup.string()
        .required("Password is required")
};


//  // set password schema

//     // forgetpassword
//    




export const OtpSchema = {
    otp: Yup.string()
        .required("OTP is required")
        .length(6, "OTP must be 6 digits"),
};
