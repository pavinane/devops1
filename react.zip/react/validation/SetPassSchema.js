import * as Yup from "yup";

export const SetPass = {
    newPass: Yup.string()
        .required("New Password is required")
        .min(8, "New password should've at least 8 characters")
        .max(16, "New password should not exceed 16 characters")
        .matches(
            /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{8,}$/,
            {
                message:
                    "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character.",
            },
        ),


    confirmPass: Yup.string()
        .required("Confirm Password is required")
        .min(8, "Confirm password should've at least 8 characters")
        .max(16, "Confirm password should not exceed 16 characters")
        .oneOf([Yup.ref("newPass")], "Confirm password and New password must be same"),

};

