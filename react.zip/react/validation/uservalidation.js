import * as Yup from "yup";

export const user_validation = (rowId) => (
    {
        user_name: Yup.string()
            .trim()
            .required("User Name is required")
            .min(3, "User Name should've at least 3 characters")
            .max(150, "User Name should not exceed 150 characters")
            .matches(
                /^(?!.*\s{2,})(?!\s)[A-Za-z0-9!@#$%^&*()_\-+=.,/?:;'\"[\]{}|\\`~ ]*(?<!\s)$/,
                "May include letters, numbers, special characters, and single spaces only"
            ),
        phone: Yup.string()
            .nullable()
            .required("Phone Number is required")
            .test(
                "phone-validation",
                "Enter a valid phone number. It should contain 6–15 digits",
                (value) => {
                    if (!value) return true;
                    return /^\+?[1-9]\d{5,14}$/.test(value);
                }
            ),
        building:
            Yup.object()
                .shape({
                    label: Yup.string().required("Building is required"),
                })
                .test(
                    "is-valid-document-type-object",
                    "Building is required",
                    (relation) => {
                        return (
                            relation &&
                            typeof relation.label === "string" &&
                            relation.label.trim().length > 0
                        );
                    },
                ),
        role:
            Yup.object()
                .shape({
                    label: Yup.string().required("Role is required"),
                })
                .test(
                    "is-valid-document-type-object",
                    "Role is required",
                    (relation) => {
                        return (
                            relation &&
                            typeof relation.label === "string" &&
                            relation.label.trim().length > 0
                        );
                    },
                ),
        room:
            Yup.object()
                .shape({
                    label: Yup.string().required("Room is required"),
                })
                .test(
                    "is-valid-document-type-object",
                    "Room is required",
                    (relation) => {
                        return (
                            relation &&
                            typeof relation.label === "string" &&
                            relation.label.trim().length > 0
                        );
                    },
                ),

        user_email: Yup.string()
            .required("Email  is required")
            .min(5, "Email ID should've at least 5 characters")
            .max(254, "Email ID should not exceed 254 characters")
            .email("Enter a valid email address")
            .matches(
                /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,6}$/,
                "Enter a valid email address"
            ),

        // user_password: rowId
        //     ? Yup.string()
        //     : Yup.string()
        //         .required("Password is required")
        //         .min(8, "Password should've at least 8 characters")
        //         .max(16, "Password should not exceed 16 characters")
        //         .matches(
        //             /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{8,}$/,
        //             "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character."
        //         ),
    }
);
