import React from "react";
import { Outlet, useLocation } from "react-router-dom";
import loginImg from "../assets/Buttons/login.webp";
import forgetImg from "../assets/Buttons/fp.webp";

const LoginLayout = () => {
    const appName = import.meta.env.VITE_APP_NAME;
    const location = useLocation();

    const image =
        location.pathname === "/forgetpassword"
            ? forgetImg
            : loginImg;

    return (
        <section className="h-screen overflow-hidden bg-white">
            <header className="fixed top-0 left-0 right-0 h-16 border-[0.5] shadow-sm bg-white z-50 px-4 sm:px-8 lg:px-12">
                <div className="h-full flex items-center justify-between">
                    <h1 className="text-2xl font-bold text-slate-800">
                        {appName || "CloudGate Accommodation System"}
                    </h1>
                </div>
            </header>

            <main className="h-screen pt-16 overflow-hidden">
                <div className="h-full flex flex-col lg:flex-row">
                    <div className="hidden lg:flex lg:w-1/2 items-center justify-center p-10">
                        <img
                            src={image}
                            alt="Auth"
                            className="max-w-md w-full object-contain"
                        />
                    </div>

                    <div className="w-full h-full lg:w-1/2 flex items-center justify-center px-6">
                        <div className="w-full max-w-md">
                            <Outlet />
                        </div>
                    </div>
                </div>
            </main>
        </section>
    );
};

export default LoginLayout;