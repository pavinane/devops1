import React from 'react'
import { Link, Outlet } from "react-router-dom";
// import Sidebar from '../../components/commonComponents/sidebar';


export default function WebLayout() {


    // const menuItems = [
    //     { label: "Calendar", icon: "Home", ActiveIcon: "Home1", navigate: "/calendar", },
    //     { label: "Request", icon: "Request", ActiveIcon: "Request1", navigate: "/request" },
    //     { label: "Audit", icon: "Audit", ActiveIcon: "Audit1", navigate: "/audit" },
    //     { label: "Ledger", icon: "Ledger", ActiveIcon: "Ledger1", navigate: "/ledger" },
    //     { label: "Forecast", icon: "Forecast", ActiveIcon: "Forecast1", navigate: "/forecast" },
    //     { label: "User", icon: "User", ActiveIcon: "User1", navigate: "/user", },
    //     {
    //         label: "Setup",
    //         icon: "Access",
    //         ActiveIcon: "Access1",
    //         subMenu: [
    //             { label: "Company", icon: "Ledger", navigate: "/company" },
    //             { label: "Roles & Control", icon: "RollsControl", navigate: "/rolepermission" },
    //             { label: "Users", icon: "AddUsers", navigate: "/user" },
    //             { label: "Expense Category", icon: "Category", navigate: "/category" },
    //         ],
    //     },


    // ];

    return (
        <>
            <div className={` sm:max-sm-md:p-0  ${false ? "p-0" : "p-[24px]"} bg-[#F2EDDA] h-screen flex flex-row gap-5`}>
                {/* <Sidebar menuItems={menuItems} /> */}
                <div className={`${(true) ? "w-[80%]" : "w-full"} flex flex-col m-[0_auto] items-start`}>
                    <Header />
                    <div className={`w-full overflow-y-auto scrollbar-hide  sm:max-sm-md:mt-20  sm:max-sm-md:h-[calc(100vh-20%)]  "sm:max-sm-md:p-2"  `}>
                        <Outlet />
                    </div>
                </div>
            </div>

        </>
    )
}
