import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Outlet, useNavigate, useLocation } from "react-router-dom";
import useIdle from "../customHooks/useIdle";
import { useReusableMutation } from "../customHooks/useDataQuery";

import { setUserState, setLogout } from "../redux/slice/userSlice";
import { useMediaQueryValues } from "../components/commonComponents/MediaQueryContext";
import axios from "axios";
import { useToast } from '../components/ToastContext';
import Header from "../pages/header/Header.jsx";
import Modal from "../components/commonComponents/Modal.jsx";
import LogoutPopUp from "../components/commonComponents/LogoutPopUp.jsx";
import Sidebar from "../components/commonComponents/Sidebar.jsx";

function DashboardLayout() {
  const { token, roles, expiresAt } = useSelector((state) => state.user);
  const { isMobile, isTablet, isDesktop } = useMediaQueryValues();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const location = useLocation();
  const { isIdle } = useIdle();
  const [showLogoutModal, setShowLogoutModal] = useState(false);

  const { mutate: userLogout, isPending } = useReusableMutation({
    onSuccess: () => {
      navigate("/");
      dispatch(setLogout());
    },
    onError: () => {
      navigate("/");
      dispatch(setLogout());
    },
  });

  const { error } = useToast();
  const openLogoutModal = () => {
    setShowLogoutModal(true)
  }

  const handleSessionLogOut = () => {
    userLogout({ endPoint: `api/auth/logout`, method: "GET" });
  };

  useEffect(() => {
    const interceptor = axios.interceptors.response.use(
      res => res,
      err => {
        if (err.response?.status === 401) {
          dispatch(setLogout());
          sessionStorage.clear();
          localStorage.clear();
          navigate("/");
        }
        return Promise.reject(err);
      }
    );
    return () => axios.interceptors.response.eject(interceptor);
  }, []);

  useEffect(() => {
    if (!expiresAt) return;

    let timerRef = null;
    const currentTime = Date.now();
    const timeout = expiresAt - currentTime;

    if (timeout > 0) {
      timerRef = setTimeout(() => {
        sessionStorage.clear();
        localStorage.clear();
        dispatch(setLogout());
        navigate("/");
        error("Token Expired");
      }, timeout);
    } else {
      sessionStorage.clear();
      localStorage.clear();
      dispatch(setLogout());
      navigate("/");
    }

    return () => {
      if (timerRef) clearTimeout(timerRef);
    };
  }, [expiresAt]);

  useEffect(() => {
    if (isIdle) {
      handleSessionLogOut();
    }
  }, [isIdle]);


  return (

    <>
      <section className={`w-full h-[100dvh] md:h-screen overflow-hidden grid grid-cols-1 md:grid-cols-[200px_1fr] lg:grid-cols-[230px_1fr] gap-0 md:gap-5 lg:gap-0 p-0 font-display relative`}>
        <Sidebar />

        <main className="flex flex-col md:rounded-tr-xl md:rounded-br-xl md:rounded-bl-xl overflow-hidden h-full md:min-h-0">
          <Header onLogout={openLogoutModal} />
          <section className="w-full h-full relative flex-1 min-h-0 md:rounded-tr-xl md:rounded-br-xl md:rounded-bl-xl overflow-hidden " >
            <div className={`absolute top-4 left-0 right-0 bottom-0 z-2 overflow-y-auto [scrollbar-gutter:stable] ${isMobile && "mb-16"}`}>

              <div className="w-full h-full px-4 py-4 sm:px-5 md:px-6 lg:px-8">
                <div className="w-full max-w-[1320px] min-h-full mx-auto">
                  <Outlet />
                </div>
              </div>
            </div>

          </section>
        </main>
      </section>

      <Modal
        width={"w-[90%] sm:w-[80%] md:w-[40%] max-w-[400px] h-[290px]"}
        isOpen={showLogoutModal}
        onClose={() => setShowLogoutModal(false)}
        showCloseButton={true}
        outSideClick={false}
      >
        <LogoutPopUp
          text="Are you sure you want to logout?"
          onConfirm={() => {
            if (!isPending) handleSessionLogOut();
          }}
          onCancel={() => setShowLogoutModal(false)}
          onConfirmText={isPending ? "Logging out..." : "Yes, Logout"}
          onCancelText="No, Go Back"
          showDeleteIcon={true}
          showButtons={true}
          isPending={isPending}
        />
      </Modal>

    </>
  );
}

export default DashboardLayout;
